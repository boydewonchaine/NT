# NEAT

Minimal, QR-first, self-custodial payments on **NEAR Testnet**. Create a wallet with a personal sentence, get a real `name.testnet` account, and pay or get paid by scanning a QR. No wallet-connect, no copy-and-paste of addresses or links, no custodian.

It is a zero-dependency static PWA (vanilla TypeScript, bundled by esbuild) plus one small serverless function that registers names.

> **Testnet only.** Testnet tokens have no monetary value. Nothing here is audited. Do not point it at mainnet.

---

## Read this first: what is and isn't verified

NEAT was built in a sandbox that could not reach NEAR, so **everything below was tested against a simulated NEAR chain** (`tests/mock-chain.ts`). That chain decodes and signature-checks real Borsh transactions and speaks the same JSON-RPC shapes, so it proves NEAT is internally consistent. It cannot prove NEAT matches the real network. Closing that gap takes one command, described under [Verify against the real testnet](#verify-against-the-real-testnet). Since then the owner has used a live Vercel deployment on testnet (2026-11-09, reported with screenshots): the rows marked *Confirmed live* below come from that, not from the sandbox.

| Area | Status |
| --- | --- |
| Wallet creation, sentence unlock, encrypted backup and restore, lockout, erase | Tested (unit and browser) |
| QR payloads: encode, scan, signature, expiry, tamper and wrong-network rejection | Tested; encoder and decoder cross-checked against OpenCV and the QR spec tables |
| Ed25519 keys and signatures | Byte-identical to an independent implementation (tweetnacl), including the way validators verify a NEAR transaction |
| Borsh transaction layout | Checked against bytes assembled by hand from the protocol specification, and accepted by the simulated chain. **Confirmed live:** a payment signed by NEAT reached `FINAL` on real testnet |
| Fee estimate from live protocol parameters, balance check, estimate-versus-actual reconciliation | Tested against the simulated chain's parameters |
| Payment lifecycle (signed, submitted, processing, completed or failed), timeouts, safe resend of identical bytes | Tested, including drops, timeouts, reloads, revoked keys and drained balances |
| Incoming payments (index hint, every fact re-read over RPC) | Tested against a NearBlocks-shaped fixture |
| PWA: manifest, installability audit, offline shell, CSP, reduced motion, light and dark, 320 px | Tested in Chromium |
| `name.testnet` registration through the real `testnet.create_account` call | **Confirmed live:** names were registered through the deployed funder function. The simulated registrar still stands in for the automated tests |
| Real RPC providers (availability, CORS, API keys), real fee schedule | **Confirmed live** from a phone browser: the receipt showed the network-reported amount, and the fee actually charged matched the estimate |
| The real NearBlocks index (incoming-payment discovery) | **Not confirmed.** Run `live-check` |
| Real phone cameras; iOS Safari and Android | **Not systematically tested.** The app has been used on an iPhone (registration and a payment), but camera scanning specifically hasn't been reported on. In the automated tests scanning is exercised with a synthetic camera feed and with uploaded images |
| The Vercel function on Vercel itself | **Confirmed live:** it registered names once the funder variables were set and the funder was funded. Use the [readiness check](#check-that-registration-is-ready) after any change |

Nothing in the app shows a success the network has not confirmed: a name is shown as registered only after the chain shows your key on the account, and a payment is shown as complete only when the network reports it final and successful.

---

## Quick start

Needs Node 20 or newer. Developed and tested on Linux with Node 22; the npm scripts use POSIX shell globbing, so on Windows use WSL.

```bash
npm install
npm run typecheck        # tsc, strict, no unused code
npm test                 # unit tests (about 15 seconds)
npm run build            # → dist/  (the static site)
npx playwright install chromium
npm run e2e              # builds a test bundle and runs the three browser suites (several minutes)
```

To try the app locally, serve `dist/` over `http://localhost` (a secure context is required for WebCrypto, the camera and the service worker):

```bash
npx --yes serve dist -l 4173
```

Without a funder configured, creating a name stops with an honest "registration isn't set up" message that names what is missing. See [Deploy](#deploy).

## Verify against the real testnet

Run this from any machine with internet access. It uses NEAT's own code paths.

```bash
npm run live-check                    # read-only: RPC reachable, testnet, CORS, fee schedule, index shape, funder balance
npm run live-check -- --spend         # also registers two throw-away names, pays between them, verifies, returns the funds
```

Useful settings: `NEAT_RPC`, `NEAT_INDEX`, `NEAT_ORIGIN` (the origin you will serve from, for the CORS checks), `NEAT_FUNDER_ID`, `NEAT_FUNDER_KEY`. The script prints PASS, WARN or FAIL for each finding and exits non-zero on a FAIL. `--spend` only spends testnet tokens, and sends nearly all of them back to the funder at the end.

What it checks that the sandbox could not: that your RPC endpoints answer as `testnet` and allow browser requests (CORS); that the fee schedule parses and the numbers are sane; that the payment index returns the shape NEAT reads and its hashes resolve over RPC; that the funder key is a full-access key with enough balance; and, with `--spend`, that `testnet.create_account` works, that a payment reaches FINAL, that the network-reported amount and fee match, and that the recipient's device discovers it through the index.

---

## Deploy

**Vercel (what the repo is set up for)**

1. Import the repository. Framework preset: *Other*. `vercel.json` already sets the build command (`node scripts/build.mjs`) and output directory (`dist`).
2. Create the registration funder (the account that pays for new names):
   ```bash
   npm run funder-keygen
   ```
   It prints `NEAT_FUNDER_ID` (a 64-hex testnet account) and `NEAT_FUNDER_KEY` (its secret key). **Never put them in the repository or the app.**
3. Fund the account. A 64-hex (implicit) account does not exist on the network until it first receives NEAR, and until then NEAT reports "the funder hasn't been given any testnet tokens". NEAR's documentation describes funding one by sending NEAR to it from any account that already has testnet tokens, for example with near-cli (`near tokens "$SENDER_ID" send-near "$NEAT_FUNDER_ID" '5 NEAR' network-config testnet sign-with-keychain send`). The [NEAR testnet faucet](https://docs.near.org/getting-started/faucet) may accept the id directly, but its documentation doesn't say whether it accepts 64-hex ids, so if it refuses, fund a named testnet account first (near-cli can have the faucet service create one: `near account create-account sponsor-by-faucet-service your-name.testnet autogenerate-new-keypair save-to-keychain network-config testnet create`) and send from that.
   Each new name costs `NEAT_STARTING_BALANCE` (default 1 NEAR) plus a few thousandths of a NEAR in gas, and faucet grants are small, so for a faucet-funded funder set `NEAT_STARTING_BALANCE` lower (for example `0.5`). The readiness check below and `live-check` report the balance.
4. In the Vercel project open **Settings → Environment Variables**. In the newer dashboard that is **Settings → Environments → Production → Project** (not the *Shared* tab, which is for team-wide variables). Add `NEAT_FUNDER_ID`, `NEAT_FUNDER_KEY` (type *Secret*, called *Sensitive* in older dashboards) and, if you lowered it, `NEAT_STARTING_BALANCE`. Make sure **Production** is ticked, and add them to the project that serves the address you actually test (an account can have several projects). Enter each value on its own, exactly as printed and without the `NAME=` part (stray quotes, spaces and a leading `NAME=` are tolerated, but anything else is not).
5. **Redeploy.** Vercel applies environment variables only to deployments made after they were added: open **Deployments**, the three dots on the latest one, **Redeploy**.
6. Open the [readiness check](#check-that-registration-is-ready). When it says `"ready": true`, register a name in the app.
7. Choose RPC providers if you don't want the defaults (see [Configuration](#configuration)), then run `NEAT_ORIGIN=https://your-site npm run live-check -- --spend` to verify everything end to end on the real network.

Serve over HTTPS. The camera, WebCrypto Ed25519 and the service worker all require a secure context.

#### Check that registration is ready

Open `https://your-site/api/register` in any browser (a plain visit, no app needed). It registers nothing and shows no secret. It checks the funder settings and the funder account on the network, and says what to fix:

```json
{ "ready": true, "network": "testnet", "funder": "…", "balance": "4.9 NEAR", "perName": "1 NEAR" }
```

If `ready` is `false`, `code` says which of these it is, and `detail` says what to do. The registration screen in the app shows the same words.

| `code` | Meaning | Fix |
| --- | --- | --- |
| `unconfigured` | `NEAT_FUNDER_ID` and/or `NEAT_FUNDER_KEY` aren't set for this deployment (`missing` lists which) | Add them under Settings → Environment Variables (newer dashboards: Settings → Environments → Production → Project) of the project that serves this address, with **Production** ticked, then redeploy |
| `funder_config` | They are set but a value is malformed: not an account id, not a whole `ed25519:…` key, a key whose two halves don't match (a character was lost), or a `NEAT_STARTING_BALANCE` that isn't a plain number | Enter the value again exactly as `npm run funder-keygen` printed it |
| `funder_unfunded` | The settings are fine, but the funder account has never been given any testnet NEAR, so it doesn't exist yet | Send it testnet NEAR (step 3) |
| `funder_key` | The account exists, but `NEAT_FUNDER_KEY` isn't one of its full-access keys | Use the id and key that were printed together |
| `funder_empty` | The account holds less than one name costs (`balance` and `perName` show the numbers) | Send it more testnet NEAR, or lower `NEAT_STARTING_BALANCE` |
| `network` | The function couldn't reach NEAR Testnet; `detail` says why (for example `RPC 429` or `RPC 401` means the RPC provider refused it) | Set `NEAT_RPC` and `NEAT_RPC_KEY` (see [Configuration](#configuration)) |

The check confirms the funder is in working order; it can't prove `testnet.create_account` accepts the call, which only a real registration (or `live-check -- --spend`) shows.

**Other hosts.** `dist/` is a plain static site, so any static host works. The only server code is `handleRegister(body, env, ip, rpc)` in `src/server/register.ts`, which has no framework dependency; wrap it in whatever function runtime you use and point `NEAT_REGISTER` at it.

### Configuration

Set in the environment of the build (`NEAT_RPC`, `NEAT_REGISTER`, `NEAT_INDEX`, `NEAT_SW`, `NEAT_OUT`) and of the function (`NEAT_FUNDER_*`, `NEAT_STARTING_BALANCE`, `NEAT_RPC`, `NEAT_RPC_KEY`). `.env.example` lists them all.

| Variable | Where | Meaning |
| --- | --- | --- |
| `NEAT_FUNDER_ID`, `NEAT_FUNDER_KEY` | function only | Funder account and its secret key. Required for name registration |
| `NEAT_STARTING_BALANCE` | function only | NEAR given to each new account (default `1`) |
| `NEAT_RPC` | build and function | Comma-separated JSON-RPC URLs, tried in order. Also sets the Content-Security-Policy `connect-src`. Default: FastNEAR, then `rpc.testnet.near.org` |
| `NEAT_RPC_KEY` | function only | Optional key the function sends as `Authorization: Bearer` |
| `NEAT_REGISTER` | build | Registration endpoint (default `/api/register`) |
| `NEAT_INDEX` | build | Payment-index base URL (default `https://api-testnet.nearblocks.io`) |
| `NEAT_SW` | build | `0` turns the service worker off (not recommended) |
| `NEAT_OUT` | build | Output directory, relative to the project (default `dist`) |

**Notes on the network services (checked against their documentation in October 2026; none could be called from the sandbox):**

- *RPC.* FastNEAR (`rpc.testnet.fastnear.com`) is the default. Its documentation says to send an API key as `Authorization: Bearer` or `?apiKey=`; whether the free tier works without one for your traffic is something `live-check` will tell you. `rpc.testnet.near.org` is documented as deprecated and limited to about 30 requests a minute, so it is only a last-resort fallback. Other providers are listed at <https://docs.near.org/api/rpc/providers>; verify CORS with `live-check` before choosing one. **A key placed in a `NEAT_RPC` URL is baked into the public bundle**, so use one restricted to your domain.
- *Payment index.* NearBlocks' free tier is documented as about 6 calls a minute, 333 a day and 10,000 a month, with attribution required and personal use only. NEAT is built around that: it reads your balance from RPC, and asks the index only when you open a screen that lists payments, after your balance has risen, and on a slow safety timer. It backs off after a 429. A production deployment should use a paid plan through a small proxy that keeps the key server-side (`NEAT_INDEX` then points at the proxy).

---

## How it works

**Identity and keys.** On the first run NEAT generates an Ed25519 key with the browser's CSPRNG. Your personal sentence (up to 100 characters, at least 20 characters and 4 words) is *not* the key. It is run through PBKDF2-HMAC-SHA256 (600,000 iterations, random 16-byte salt) and used with AES-256-GCM to encrypt the key. The additional authenticated data binds the ciphertext to the public key. Only the ciphertext, salt, IV and public key are stored. The sentence, the derived key and the private key are never stored in plaintext, never logged, and never sent anywhere. While unlocked, the key is held as a non-extractable WebCrypto signing key.

**Names.** A NEAT name is a real NEAR account, `<label>.testnet`, controlled only by your key. When you confirm a name, the browser sends the label and your *public* key to `/api/register`. The function calls the registrar contract (`testnet.create_account`) from the funder account, attaching the starting balance. The app then polls the chain and shows the name as yours only when it sees your key as a full-access key on that account; at that moment it opens your dashboard (there is no interim screen). If the network rejects it, the screen says so and shows the failed transaction. If it is slow, the screen says it is still waiting, and a reload resumes the wait without ever submitting twice.

**Receiving.** *My QR* is a standing code for your account. *Request amount* makes a single-use request with an amount, an optional note and an expiry. Each code is signed by your account key. There is no copy button for an address or link, anywhere.

**Paying.** *Scan* reads a code with the native `BarcodeDetector` where the browser has one, and a bundled software decoder otherwise (or you can upload a photo of a code). Before showing an amount the app checks the expiry, the signature, and that the signing key is a full-access key on the named account on the network. Then: amount, review, authorize, send.

**Fees.** People see one fee line, the *stamp fee*. Today it is the NEAR network fee, computed from the live protocol configuration (`EXPERIMENTAL_protocol_config`) and the current gas price. NEAT adds no charge of its own yet and none is invented: a NEAT fee has been asked for, and when it is built it will be folded into this same line (it needs a fraction, a destination account and a mechanism to be decided first). The Review screen shows the stamp fee (estimated), the total, and what the recipient gets. Your balance must cover the amount plus the amount the network holds up front. The receipt shows the fee the network actually charged.

**Transactions.** The transaction is signed on your device and the signed bytes are written to storage *before* they are sent, so a refresh, crash or timeout can only ever re-send the identical transaction (same hash, so it executes at most once). The app tracks it over RPC and shows distinct states: signed, submitted, processing, completed, failed. The receipt is a small printed slip in a plain typewriter face, with the date and time printed on it, the names in bold, the stamp fee, the network's evidence, and a boxed status stamp. It says "completed" only when the network reports the transaction successful, all receipts executed, and finality `FINAL`; the amount shown as received is the amount the *network* reports. A transaction that fails on-chain is shown as failed, with the fee that was still charged.

**Incoming payments.** NEAR RPC cannot list an account's history, so a NearBlocks-compatible index nominates candidate transaction hashes. Every fact shown (who, how much, whether it succeeded, whether it is final) is re-read from the network; anything that is not exactly one plain transfer to you is discarded. A request is marked Paid only by a verified incoming transfer, at least the requested amount, made after the request. Coverage is recent activity, not full history, and the screen says so.

**PWA.** Web manifest, maskable icons, a service worker that precaches the shell (the app opens offline; payments need a connection and are never signed or submitted offline), a strict CSP (`default-src 'none'`, scripts and styles from the app's own origin only, `connect-src` limited to your RPC, index and registration origins), and no third-party scripts or analytics. There is no fake install button: install uses the browser's own prompt.

**Design.** Monochrome, derived from the logo (ink `#292a2f` on paper `#eee`, with a dark theme). The chevron in `public/logo.svg` is a vector traced from the logo image you supplied; if you have the original vector, replace that file (and the path in `scripts/make-icons.mjs`, then `npm i -D sharp && npm run icons`). Splash animation honours *reduce motion*. WCAG AA contrast is enforced by tests in both themes.

## Security and recovery: the honest version

- **Nobody can reset your sentence**, including us. It never leaves your device, and the server holds nothing that could recover it.
- **The sentence alone cannot restore a wallet on another device.** To move or survive device loss, download the **encrypted backup** (Settings) and keep it somewhere safe. With the file and the sentence you can restore anywhere. Without a backup, losing the device means losing access to the wallet.
- **Browsers can delete site data.** Safari clears storage for sites unused for about a week unless they are installed to the home screen; any browser clears it if you clear site data. Install the app and download a backup.
- **A weak sentence is the weak point.** If someone gets your backup file (or your browser profile) they can guess sentences offline, and 600,000 PBKDF2 iterations only slow that down. Four or more unrelated words are far safer than one clever phrase. The wrong-attempt delay in the app (it grows to 15 minutes) is a client-side deterrent, not a defence against someone who has the stored data.
- **A failed unlock never creates a new wallet.** The only path is an explicit, typed-confirmation *Erase this wallet* that says funds will become unreachable.
- **What the funder sees:** the label you chose and your public key, and your IP address (a function-local, in-memory rate limit is applied per address; on serverless hosting this is best-effort only). It has no authority over your account after creation.
- **What third parties see:** RPC providers and the payment index see your account name and IP address when the app asks about it. Nothing is sent to any analytics service because there is none.
- **A QR proves who issued it, not who you meant to pay.** The signature shows the code was made by the owner of the named account. Always check the name on the Amount screen.

## Known limits

- One key per wallet and one wallet per browser profile; no multi-device sync, no key rotation, no social recovery.
- Incoming history is "recent activity" from the index. NEAR transfers carry no memo, so two open requests for the same amount at the same time cannot be told apart (the oldest is matched first).
- "Single-use" requests and *Cancel request* are enforced by the app on your own device. A QR is only a QR: anyone who has it can pay it until it expires.
- JavaScript timers pause in background tabs, so auto-lock also checks the elapsed time when you return.
- Native camera scanning depends on the browser's `BarcodeDetector`; the software fallback is slower and less tolerant of poor light and glare.
- The in-memory rate limiter on the registration function resets whenever the function instance does.

## Tests

| Suite | What it covers | Run with |
| --- | --- | --- |
| Unit (`tests/*.test.ts`) | Crypto and vault, Borsh and signing (cross-checked with tweetnacl), QR encoder and decoder (cross-checked with OpenCV), payload signing, fees, transaction lifecycle and recovery, registration, index rationing, accessibility tokens (WCAG AA), code-hygiene rules enforced on the source tree (nothing is logged, no clipboard or text sharing, no dynamic code, storage only through the store, network only through the sanctioned modules, testnet only), the live-check script, the funder key generator, each way the funder can be misconfigured and its readiness check, "no secrets in the build" | `npm test` |
| `tests/e2e.mts` | The core journey in a real browser: create, name, receive, scan, review, authorize, receipt, restore, offline | `npm run e2e` |
| `tests/e2e-failures.mts` | Cancelled authorization, revoked key, drained balance, on-chain failure, double clicks, ten kinds of bad QR, registration failure and retry (including each funder problem in turn, ending in a successful registration), lockout, erase, plus a real-DOM accessibility audit of every screen | `npm run e2e` |
| `tests/e2e-platform.mts` | Installability, CSP enforcement, camera (including denial), auto-lock on a fake clock, reduced motion, and a search of everything sent or stored for secrets | `npm run e2e` |

All of these run against the simulated chain (`tests/mock-chain.ts`, `tests/e2e-server.ts`). They are the evidence for NEAT's own logic, and `live-check` is the evidence for the network.

## Project layout

```
src/core/     chain-agnostic logic: vault, near (Borsh, signing), rpc, fees, pay, identity, history, payload, qr, qrdecode, store
src/ui/       the app: app shell and routing, views, dom helpers, scanner, styles.css
src/server/   register.ts: the only server logic (framework-free)
api/          register.ts: Vercel adapter, with its own tsconfig (CommonJS)
public/       index.html, manifest, icons, service-worker template
scripts/      build.mjs, e2e.mjs, live-check.ts, funder-keygen.mjs, make-icons.mjs
tests/        unit tests, the simulated chain, and the browser suites
```

## Troubleshooting

| You see | Cause and fix |
| --- | --- |
| "Name registration isn't set up on this deployment yet" | `NEAT_FUNDER_ID` or `NEAT_FUNDER_KEY` is missing from the function's environment (the line under the message names which). If you just added them, redeploy: a running deployment never sees variables added afterwards. Then open `/api/register` ([readiness check](#check-that-registration-is-ready)) |
| "Name registration is set up incorrectly on this deployment" | A funder setting is malformed, or the key isn't a full-access key of the funder account. The line under the message says which; the [readiness check](#check-that-registration-is-ready) lists each case |
| "…the funder account hasn't been given any testnet tokens" | The funder account doesn't exist on the network yet. Send it testnet NEAR |
| "NEAT's testnet funder has run out of tokens" | Fund the funder again, or lower `NEAT_STARTING_BALANCE` |
| "The NEAT registration service didn't answer properly (HTTP …)" | The reply wasn't from the registration function (a missing `api` folder, a platform error page). Check the deployment's Functions tab and that `api/register.ts` was deployed |
| Balance and names never load; the console shows a CORS error | An RPC endpoint doesn't allow browser requests. Run `live-check` and choose providers that pass |
| Incoming payments are slow to appear, or Activity says it couldn't load them | The payment index is rate limited (HTTP 429). Your balance still updates from RPC; use a paid plan through a proxy for real use |
| Camera doesn't start | The page isn't served over HTTPS (or `localhost`), or camera permission was denied. Use *Upload QR image* |
| `npm run e2e` can't find Chromium | `npx playwright install chromium` |
