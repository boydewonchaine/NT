// Per-screen audit run against the REAL rendered DOM (not against the CSS tokens): contrast of every piece of
// text as actually composited, headings/labels/names, overflow, tap-target size, placeholder or debug text, emoji,
// and controls that have no click handler at all ("dead buttons").
import { writeFileSync } from "node:fs";
import { OUT, type Page, type Suite } from "./e2e-lib.mts";

// Runs inside the page. Plain JS in a string on purpose: it must not be touched by the TypeScript transpiler.
// Hard problems fail the run; "notes" are softer findings that are written to audit-notes.json for review.
const PAGE_AUDIT = String.raw`(() => {
  const problems = [], notes = [];
  const all = (s) => Array.prototype.slice.call(document.querySelectorAll(s));
  const hiddenByAria = (e) => { for (let n = e; n && n.nodeType === 1; n = n.parentElement) if (n.getAttribute("aria-hidden") === "true") return true; return false; };
  const shown = (e) => { for (let n = e; n && n.nodeType === 1; n = n.parentElement) { const cs = getComputedStyle(n); if (cs.display === "none" || cs.visibility === "hidden") return false; } const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const isSr = (e) => !!e.closest(".sr");
  const label = (e) => { const t = (e.getAttribute("aria-label") || e.textContent || "").replace(/\s+/g, " ").trim().slice(0, 32); return e.tagName.toLowerCase() + (typeof e.className === "string" && e.className ? "." + e.className.trim().split(/\s+/)[0] : "") + " “" + t + "”"; };

  // ---- colour maths (WCAG 2.x relative luminance), on computed colours composited over what is really behind them
  const parse = (c) => { const m = /rgba?\(([^)]+)\)/.exec(c); if (!m) return null; const p = m[1].split(/[\s,\/]+/).filter(Boolean).map(Number); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
  const over = (f, b) => ({ r: f.r * f.a + b.r * (1 - f.a), g: f.g * f.a + b.g * (1 - f.a), b: f.b * f.a + b.b * (1 - f.a), a: 1 });
  const lin = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
  const lum = (c) => 0.2126 * lin(c.r) + 0.7152 * lin(c.g) + 0.0722 * lin(c.b);
  const ratio = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05); };
  const bgOf = (el) => { const layers = []; for (let e = el; e && e.nodeType === 1; e = e.parentElement) { const bg = parse(getComputedStyle(e).backgroundColor); if (bg && bg.a > 0) { layers.push(bg); if (bg.a >= 1) break; } } let base = { r: 255, g: 255, b: 255, a: 1 }; for (let i = layers.length - 1; i >= 0; i--) base = over(layers[i], base); return base; };
  const opacityOf = (el) => { let o = 1; for (let e = el; e && e.nodeType === 1; e = e.parentElement) o *= parseFloat(getComputedStyle(e).opacity); return o; };
  const contrastOf = (el, css) => { const fg = parse(css); if (!fg) return null; fg.a *= opacityOf(el); const bg = bgOf(el); return ratio(over(fg, bg), bg); };

  // ---- text contrast
  const seen = new Set();
  const modal = !!document.querySelector(".sheet"); // a modal dialog is the only thing a person can use while it is open
  all(modal ? ".sheet, .sheet *" : "main *, header *, .banner, .toast").forEach((el) => {
    if (seen.has(el) || isSr(el) || hiddenByAria(el) || !shown(el) || el.disabled) return;
    seen.add(el);
    if (!Array.prototype.some.call(el.childNodes, (n) => n.nodeType === 3 && n.textContent.trim().length > 0)) return;
    const cs = getComputedStyle(el);
    const fs = parseFloat(cs.fontSize), fw = parseInt(cs.fontWeight, 10) || 400;
    const need = fs >= 24 || (fs >= 18.66 && fw >= 700) ? 3 : 4.5;
    const r = contrastOf(el, cs.color);
    if (r !== null && r + 0.005 < need) problems.push("contrast " + r.toFixed(2) + ":1 (needs " + need + ") on " + label(el));
  });
  all("input:not([type=file]):not([type=checkbox]):not([type=hidden]), textarea, select").forEach((el) => {
    if (isSr(el) || !shown(el) || el.disabled) return;
    const r = contrastOf(el, getComputedStyle(el).color);
    if (r !== null && r < 4.5) problems.push("typed-text contrast " + r.toFixed(2) + ":1 on " + label(el));
    if (el.placeholder && !el.value) { const pr = contrastOf(el, getComputedStyle(el, "::placeholder").color); if (pr !== null && pr < 4.5) problems.push("placeholder contrast " + pr.toFixed(2) + ":1 on " + label(el)); }
  });

  // ---- names, labels, structure
  all("button, a[href], [role=button], [role=tab]").forEach((el) => {
    if (isSr(el) || !shown(el)) return;
    if (!(el.getAttribute("aria-label") || el.textContent || el.getAttribute("title") || "").trim()) problems.push("no accessible name: " + label(el));
  });
  all("input:not([type=hidden]), select, textarea").forEach((el) => {
    if (!shown(el) && !isSr(el)) return;
    if (!(el.getAttribute("aria-label") || el.getAttribute("aria-labelledby") || (el.labels && el.labels.length))) problems.push("form field without a label: " + label(el));
  });
  all("svg").forEach((s) => {
    if (hiddenByAria(s) || s.closest(".qrcard") || !shown(s)) return;
    if (!s.getAttribute("role") && !s.querySelector("title")) notes.push("svg neither hidden from assistive tech nor labelled, inside " + label(s.parentElement));
  });
  const h1s = all("h1").filter((e) => shown(e) && !isSr(e));
  if (h1s.length !== 1) problems.push("expected exactly one visible <h1>, found " + h1s.length);
  if (!document.documentElement.lang) problems.push("<html> has no lang");
  if (!document.title || document.title.trim().length < 3) problems.push("empty document title");
  if (!document.querySelector("main")) problems.push("no <main> landmark");

  // ---- layout
  const de = document.documentElement;
  if (de.scrollWidth > innerWidth + 1) problems.push("horizontal overflow: page is " + de.scrollWidth + "px wide in a " + innerWidth + "px viewport");
  let off = 0;
  all("main *").forEach((el) => {
    if (isSr(el) || hiddenByAria(el) || !shown(el) || off >= 5) return;
    const r = el.getBoundingClientRect();
    if (r.right > innerWidth + 1 || r.left < -1) { off++; problems.push("off-screen: " + label(el) + " spans " + Math.round(r.left) + ".." + Math.round(r.right) + " in " + innerWidth + "px"); }
  });
  all("button, a[href], [role=tab], select, input:not([type=hidden]):not([type=file]):not([type=checkbox]), label.btn").forEach((el) => {
    if (isSr(el) || !shown(el) || el.disabled) return;
    const r = el.getBoundingClientRect(), m = Math.min(r.width, r.height);
    const inlineLink = el.tagName === "A" && !!el.closest("p, .prose, .row, .card");
    const desc = Math.round(r.width) + "x" + Math.round(r.height) + ": " + label(el);
    if (m < 24 && !inlineLink) problems.push("tap target under 24px (" + desc + ")");
    else if (m < 44) notes.push("tap target under 44px (" + desc + ")");
  });

  // ---- words that must never ship
  const t = document.body.innerText;
  const bad = /\b(lorem|ipsum|todo|tbd|fixme|coming soon|placeholder|undefined|NaN|null)\b|\[object /i.exec(t);
  if (bad) problems.push("placeholder/debug text on screen: “" + bad[0] + "”");
  if (/\p{Extended_Pictographic}/u.test(t)) problems.push("emoji in the UI text");
  return { problems, notes };
})()`;

/** Interactive elements with no click listener anywhere on them: buttons that exist but do nothing. */
export async function deadControls(page: Page, ctx: any): Promise<string[]> {
  const cdp = await ctx.newCDPSession(page);
  try {
    const { result } = await cdp.send("Runtime.evaluate", {
      expression: `Array.from(document.querySelectorAll('button:not([disabled]), [role=button]:not([aria-disabled=true]), [role=tab]')).filter(function (e) { var r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; })`,
    });
    const props = await cdp.send("Runtime.getProperties", { objectId: result.objectId, ownProperties: true });
    const dead: string[] = [];
    for (const p of props.result) {
      if (!/^\d+$/.test(p.name) || !p.value?.objectId) continue;
      const { listeners } = await cdp.send("DOMDebugger.getEventListeners", { objectId: p.value.objectId });
      if (!listeners.some((l: any) => ["click", "pointerup", "pointerdown", "mousedown", "mouseup", "touchend"].includes(l.type))) {
        const d = await cdp.send("Runtime.callFunctionOn", { objectId: p.value.objectId, functionDeclaration: "function(){ return (this.getAttribute('aria-label') || this.textContent || '').trim().slice(0, 40); }", returnByValue: true });
        dead.push(String(d.result.value));
      }
    }
    return dead;
  } finally {
    await cdp.detach().catch(() => {});
  }
}

const softNotes: { screen: string; note: string }[] = [];

/** Audit the screen currently showing in `page`; one check line per screen. */
export async function audit(S: Suite, page: Page, ctx: any, screen: string) {
  await S.settle(page);
  const { problems, notes } = (await page.evaluate(PAGE_AUDIT)) as { problems: string[]; notes: string[] };
  for (const d of await deadControls(page, ctx)) problems.push("control with no click handler: " + d);
  for (const n of notes) softNotes.push({ screen, note: n });
  S.check(`audit · ${screen}`, problems.length === 0, problems.slice(0, 6).join(" ; "));
  return problems;
}

/** The keyboard focus ring must actually render on the first Tab stop. */
export async function focusRing(S: Suite, page: Page, screen: string) {
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur?.());
  await page.keyboard.press("Tab");
  const ring = await page.evaluate(() => {
    const e = document.activeElement as HTMLElement | null;
    if (!e || e === document.body) return null;
    const cs = getComputedStyle(e);
    return { tag: e.tagName + (e.getAttribute("aria-label") ? `[${e.getAttribute("aria-label")}]` : ""), outline: `${cs.outlineStyle} ${cs.outlineWidth}`, shadow: cs.boxShadow };
  });
  S.check(`keyboard focus ring is visible · ${screen}`, !!ring && !/^none /.test(ring.outline) && ring.outline !== "none 0px", JSON.stringify(ring));
}

export function writeAuditNotes() {
  writeFileSync(`${OUT}/audit-notes.json`, JSON.stringify(softNotes, null, 1));
  return softNotes.length;
}
