// The live-check script is how a person verifies NEAT against the REAL testnet, so the script itself must be
// trustworthy. These tests run it end to end against the simulated chain (this proves the script and the app code it
// drives agree with each other; it cannot prove anything about the real network, which is the script's job).
import test from "node:test";
import assert from "node:assert/strict";
import { MockChain } from "./mock-chain";
import { runLiveCheck, type Level, type LiveOptions } from "../scripts/live-check";
import { generateKeypair } from "../src/core/near";
import { base58Encode } from "../src/core/encoding";
import * as store from "../src/core/store";
import { resetIndexState } from "../src/core/history";

type Line = { level: Level; text: string };

async function harness(opts: { cors?: boolean; chainId?: string; funded?: boolean } = {}) {
  const chain = new MockChain();
  const funder = await generateKeypair();
  chain.addAccount("neat-funder.testnet", 50n, funder.publicKey);
  chain.addAccount("testnet", 1_000_000n);
  const calls: string[] = [];
  const fetchImpl = (async (url: any, init: any = {}) => {
    const u = String(url);
    calls.push(`${init.method ?? "GET"} ${u}`);
    const cors: Record<string, string> = opts.cors === false ? {} : { "access-control-allow-origin": "*", "access-control-allow-headers": "content-type" };
    if (u.startsWith("http://mock-rpc")) {
      if (init.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
      const { method, params, id } = JSON.parse(init.body);
      const out: any = await chain.handle(method, params);
      if (method === "status" && opts.chainId) out.result.chain_id = opts.chainId;
      return new Response(JSON.stringify({ jsonrpc: "2.0", id, ...out }), { status: 200, headers: { "content-type": "application/json", ...cors } });
    }
    const m = /\/v1\/account\/([^/?]+)\/txns/.exec(u);
    if (m) return new Response(JSON.stringify(chain.indexFor(decodeURIComponent(m[1]))), { status: 200, headers: { "content-type": "application/json", ...cors } });
    throw new TypeError("unexpected url " + u);
  }) as any as typeof fetch;
  const env = opts.funded === false ? {} : { NEAT_FUNDER_ID: "neat-funder.testnet", NEAT_FUNDER_KEY: "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey])), NEAT_STARTING_BALANCE: "2" };
  const base: LiveOptions = { rpcUrls: ["http://mock-rpc.example/a", "http://mock-rpc.example/b"], indexBase: "http://mock-index.example", origin: "https://neat.example", checkAccount: "testnet", env, spend: false, amount: "0.25", fetchImpl, sleep: async () => {} };
  const run = async (over: Partial<LiveOptions> = {}) => {
    const lines: Line[] = [];
    const tally = await runLiveCheck({ ...base, ...over }, (level, text) => lines.push({ level, text }));
    return { lines, tally };
  };
  return { chain, run, calls };
}

const show = (lines: Line[]) => lines.map((l) => `${l.level.toUpperCase()} ${l.text}`).join("\n");

test("live check, read-only: a healthy network and index produce no failures and no registration or payment", async () => {
  store.useStorage(null);
  const h = await harness();
  const { lines, tally } = await h.run();
  assert.equal(tally.fail, 0, show(lines));
  assert.equal(h.chain.broadcasts, 1, "only the deliberately malformed probe was broadcast, and the node refused it");
  assert.ok(lines.some((l) => /fee schedule read/.test(l.text)));
  assert.ok(lines.some((l) => /estimated transfer fee/.test(l.text) && l.level === "info"));
  assert.ok(lines.some((l) => /funder neat-funder\.testnet holds/.test(l.text) && l.level === "pass"), show(lines));
  assert.ok(lines.some((l) => /Read-only run/.test(l.text)));
});

test("live check, --spend: registers two names on-chain, pays between them through NEAT's own code, verifies the evidence and returns the funds", async () => {
  store.useStorage(null);
  resetIndexState();
  const h = await harness();
  const before = h.chain.accounts.get("neat-funder.testnet")!.amount;
  const { lines, tally } = await h.run({ spend: true });
  assert.equal(tally.fail, 0, show(lines));
  assert.ok(lines.filter((l) => l.level === "warn").every((l) => /returned no transactions/.test(l.text)), "the only warning is that the simulated index has nothing listed for the probe account:\n" + show(lines));
  const names = [...h.chain.accounts.keys()].filter((k) => k.startsWith("neat-live-"));
  assert.equal(names.length, 2, "two throw-away names exist on the chain");
  assert.ok(lines.some((l) => l.level === "pass" && /payment completed with network finality FINAL/.test(l.text)), show(lines));
  assert.ok(lines.some((l) => l.level === "pass" && /recipient's balance rose by exactly 0\.25/.test(l.text)), show(lines));
  assert.ok(lines.some((l) => l.level === "pass" && /discovered the payment through the index/.test(l.text)), show(lines));
  assert.ok(lines.filter((l) => /^returned/.test(l.text)).length === 2, "both accounts hand their tokens back");
  const after = h.chain.accounts.get("neat-funder.testnet")!.amount;
  const spent = before - after;
  assert.ok(spent > 0n && spent < 2n * 10n ** 22n, `the whole exercise cost the funder only fees (${spent} yocto)`);
  for (const n of names) assert.ok(h.chain.accounts.get(n)!.amount < 10n ** 22n, `${n} was drained back to the funder`);
});

test("live check reports real problems as FAIL, not as a pass", async () => {
  store.useStorage(null);
  // a node that does not allow browser origins
  let h = await harness({ cors: false });
  let r = await h.run();
  assert.ok(r.tally.fail >= 1 && r.lines.some((l) => l.level === "fail" && /CORS/.test(l.text)), show(r.lines));
  // the wrong network
  h = await harness({ chainId: "mainnet" });
  r = await h.run();
  assert.ok(r.lines.some((l) => l.level === "fail" && /not "testnet"/.test(l.text)), show(r.lines));
  assert.equal(h.chain.broadcasts, 0, "nothing is sent to a network that is not testnet");
  // --spend without a funder must not spend or pretend
  h = await harness({ funded: false });
  r = await h.run({ spend: true });
  assert.ok(r.lines.some((l) => l.level === "fail" && /--spend needs a working funder/.test(l.text)), show(r.lines));
  assert.equal([...h.chain.accounts.keys()].filter((k) => k.startsWith("neat-live-")).length, 0);
  // an unreachable endpoint
  h = await harness();
  r = await h.run({ rpcUrls: ["http://down.example/rpc"] });
  assert.ok(r.lines.some((l) => l.level === "fail" && /unreachable/.test(l.text)), show(r.lines));
  assert.ok(r.lines.some((l) => /No RPC endpoint passed/.test(l.text)));
});
