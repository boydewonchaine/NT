import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import { MockChain } from "./mock-chain";
import { Rpc } from "../src/core/rpc";
import { generateKeypair, keyToString, signerFromSeed, signTransaction, Signer } from "../src/core/near";
import { estimateTransferFee, maxSendable, stampFee } from "../src/core/fees";
import { authorizeAndSend, refreshTx, resendStored, alreadyPaid, PayError } from "../src/core/pay";
import { createRequest, parseRequest, verifyRequest, encodeRequest } from "../src/core/payload";
import { awaitRegistration, checkAvailability, checkRegistration, confirmRegistered, describeRegistrationFailure, requestRegistration } from "../src/core/identity";
import { handleRegister } from "../src/server/register";
import { parseNear, YOCTO_PER_NEAR } from "../src/core/units";
import { expectIncoming, parseIndexTxns, reconcileRequests, resetIndexState, syncIncoming } from "../src/core/history";
import { transferOf } from "../src/core/rpc";
import { costsFromConfig, parseRatio } from "../src/core/fees";
import * as store from "../src/core/store";
import { base58Encode, toBase64Url, utf8 } from "../src/core/encoding";

const mem = () => { const m = new Map<string, string>(); return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v), m }; };

let chain: MockChain, rpc: Rpc, shim: ReturnType<typeof mem>;
let alice: { id: string; signer: Signer; pk: Uint8Array; seed: Uint8Array }, bob: typeof alice;

async function actor(id: string, near: bigint) {
  const { seed, publicKey } = await generateKeypair();
  chain.addAccount(id, near, publicKey);
  return { id, pk: publicKey, seed, signer: await signerFromSeed(seed, publicKey) };
}

beforeEach(async () => {
  chain = new MockChain();
  rpc = new Rpc({ endpoints: ["http://mock"], fetchImpl: chain.fetchImpl as any, timeoutMs: 2000 });
  shim = mem(); store.useStorage(shim);
  alice = await actor("alice.testnet", 10n);
  bob = await actor("bob.testnet", 1n);
});

const send = async (amount: bigint, extra: any = {}) => {
  const est = await estimateTransferFee(rpc, alice.id, bob.id);
  return authorizeAndSend({ rpc, signer: alice.signer, fromId: alice.id, toId: bob.id, amount, estimate: est, ...extra });
};

test("fee estimate derives from protocol config × live gas price and exposes reserve + spendable", async () => {
  const e = await estimateTransferFee(rpc, alice.id, bob.id);
  // fixture: 2 × (send_not_sir + execution) = 2 × 230e9 gas, price 1e8 yocto
  assert.equal(e.gasUnits, 460_000_000_000n);
  assert.equal(e.fee, 460_000_000_000n * 100_000_000n);
  assert.ok(e.reserve > e.fee);
  assert.ok(e.receiverExists);
  assert.ok(maxSendable(e) < e.spendable);
  assert.ok(e.spendable < 10n * YOCTO_PER_NEAR); // storage stake is held back
});

test("real-flow send: persisted before broadcast, completes only at FINAL, fee reconciled", async () => {
  chain.finalizeAfter = 1;
  const amt = parseNear("2.5")!;
  const before = chain.accounts.get(bob.id)!.amount;
  const rec = await send(amt);
  assert.equal(rec.status, "submitted");
  assert.ok(rec.signed, "signed bytes stored for safe recovery");
  assert.ok(store.getTx(rec.id));
  let t = await refreshTx(rpc, rec.id);
  assert.equal(t.tx.status, "processing"); assert.equal(t.settled, false); // optimistic ≠ complete
  t = await refreshTx(rpc, rec.id);
  assert.equal(t.tx.status, "completed"); assert.ok(t.settled);
  assert.equal(chain.accounts.get(bob.id)!.amount - before, amt);
  assert.ok(BigInt(t.tx.feeActual!) > 0n);
  assert.equal(t.tx.signed, undefined);
  assert.equal(t.tx.feeActual, t.tx.feeEstimate); // fixture burns exactly the estimate
});

test("stamp fee: the estimate (flagged) until the network reports, then the fee it actually charged; nothing when neither exists", async () => {
  chain.finalizeAfter = 1;
  const rec = await send(parseNear("1")!);
  const early = stampFee(rec);
  assert.ok(early && early.actual === false && early.yocto > 0n, "before reconciliation it is the estimate, and says so");
  assert.equal(early.yocto, BigInt(rec.feeEstimate!));
  await refreshTx(rpc, rec.id);
  const t = await refreshTx(rpc, rec.id);
  const late = stampFee(t.tx);
  assert.ok(late && late.actual === true, "after FINAL it is the real fee");
  assert.equal(late.yocto, BigInt(t.tx.feeActual!));
  assert.equal(stampFee({}), null, "no fee data means no invented number");
});

test("insufficient balance for amount + fee is refused before anything is signed", async () => {
  const before = chain.broadcasts;
  await assert.rejects(send(parseNear("9.9999")!), (e: any) => e instanceof PayError && e.code === "insufficient");
  assert.equal(chain.broadcasts, before);
  assert.equal(store.load().txs.length, 0);
  const est = await estimateTransferFee(rpc, alice.id, bob.id);
  await send(maxSendable(est)); // exactly the max works
});

test("a lost submission stays 'signed'; resend re-sends the IDENTICAL tx and it executes once", async () => {
  chain.dropNext = 1;
  const rec = await send(parseNear("1")!);
  assert.equal(rec.status, "submitted"); // node acked
  const t = await refreshTx(rpc, rec.id);
  assert.equal(t.tx.status, "submitted"); assert.equal(t.settled, false); // unknown to the network: not failed, not complete
  const bobBefore = chain.accounts.get(bob.id)!.amount;
  await resendStored(rpc, rec.id);
  await resendStored(rpc, rec.id); // second call must not double-submit (network now knows the hash)
  const done = await refreshTx(rpc, rec.id);
  assert.equal(done.tx.status, "completed");
  assert.equal(chain.accounts.get(bob.id)!.amount - bobBefore, parseNear("1")!);
});

test("network error at broadcast leaves a recoverable 'signed' record, never a second payment", async () => {
  const est = await estimateTransferFee(rpc, alice.id, bob.id);
  const origBroadcast = rpc.broadcast.bind(rpc);
  rpc.broadcast = async () => { throw new Error("offline"); };
  const rec = await authorizeAndSend({ rpc, signer: alice.signer, fromId: alice.id, toId: bob.id, amount: parseNear("1")!, estimate: est });
  assert.equal(rec.status, "signed");
  rpc.broadcast = origBroadcast;
  // simulate an app reload: in-memory state dropped, storage kept
  store.useStorage(shim);
  assert.equal(store.getTx(rec.id)!.status, "signed");
  await resendStored(rpc, rec.id);
  assert.equal((await refreshTx(rpc, rec.id)).tx.status, "completed");
  assert.equal(chain.log.length, 1);
});

test("rejected by network → failed with explanation, funds untouched", async () => {
  const est = await estimateTransferFee(rpc, alice.id, bob.id);
  // drain alice behind the app's back so the node rejects
  chain.accounts.get(alice.id)!.amount = 10n ** 20n;
  const rec = await authorizeAndSend({ rpc, signer: alice.signer, fromId: alice.id, toId: bob.id, amount: parseNear("1")!, estimate: { ...est, spendable: 10n * YOCTO_PER_NEAR } }).catch((e) => e);
  assert.ok(rec instanceof PayError && rec.code === "rejected");
  assert.equal(store.load().txs[0].status, "failed");
  assert.match(store.load().txs[0].failure!, /balance/i);
});

test("on-chain execution failure (unknown recipient) is reported as failed, not success", async () => {
  chain.accounts.delete(bob.id);
  const est = await estimateTransferFee(rpc, alice.id, "ghost.testnet").catch(() => null);
  assert.ok(est);
  const rec = await authorizeAndSend({ rpc, signer: alice.signer, fromId: alice.id, toId: "ghost.testnet", amount: parseNear("1")!, estimate: est! });
  const t = await refreshTx(rpc, rec.id);
  assert.equal(t.tx.status, "failed"); assert.match(t.tx.failure!, /doesn't exist/);
});

test("payment request QR: roundtrip, authentic, no secrets", async () => {
  const { request, qrText } = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("3")!, fixed: true, note: "lunch", expiresInSec: 600 });
  const p = parseRequest(qrText);
  assert.ok(p.ok);
  assert.deepEqual(p.ok && p.request, request);
  assert.deepEqual(await verifyRequest(request, rpc), { ok: true });
  assert.ok(qrText.length < 260, `qr text ${qrText.length}`);
  const raw = Buffer.from(qrText.slice(6), "base64url");
  // only public material: no 32-byte seed can be present (the QR holds the public key + a signature)
  assert.ok(!raw.includes(Buffer.from(bob.seed)));
  assert.ok(raw.includes(Buffer.from(bob.pk)));
});

test("payment request QR: rejects tampering, wrong key, expiry, wrong network, junk", async () => {
  const { request } = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("3")!, expiresInSec: 600 });
  // attacker edits the amount
  const tampered = { ...request, amt: parseNear("300")!.toString() };
  const r1 = await verifyRequest(tampered, rpc); assert.ok(!r1.ok && r1.reason === "bad_signature");
  // attacker re-targets to their own account with their own valid signature: key not on the named account
  const mallory = await generateKeypair(); const ms = await signerFromSeed(mallory.seed, mallory.publicKey);
  const forged = await createRequest(ms, bob.id, { amountYocto: 1n });
  const r2 = await verifyRequest(forged.request, rpc); assert.ok(!r2.ok && r2.reason === "key_mismatch");
  // unknown account
  const ghost = await createRequest(ms, "ghost.testnet", {}); const r3 = await verifyRequest(ghost.request, rpc); assert.ok(!r3.ok && r3.reason === "unknown_account");
  // expired
  const old = await createRequest(bob.signer, bob.id, { expiresInSec: 60, now: Date.now() - 3600_000 }); const r4 = await verifyRequest(old.request, rpc); assert.ok(!r4.ok && r4.reason === "expired");
  // offline
  chain.failNext = 5; const r5 = await verifyRequest(request, rpc); assert.ok(!r5.ok && r5.reason === "offline");
  chain.failNext = 0;
  // structural rejects
  for (const bad of ["hello", "NEAT1.!!!", "NEAT1." + toBase64Url(new TextEncoder().encode("{}")), "https://evil.example/pay?to=x"]) assert.equal(parseRequest(bad).ok, false);
  const raw = Buffer.from(encodeRequest(request).slice(6), "base64url"); raw[0] = 2; // future version / other network or asset
  const pm = parseRequest("NEAT1." + raw.toString("base64url")); assert.ok(!pm.ok && /Testnet only/.test(pm.error));
  const trunc = encodeRequest(request).slice(0, 60); assert.equal(parseRequest(trunc).ok, false);
  const flip = Buffer.from(encodeRequest(request).slice(6), "base64url"); flip[flip.length - 1] ^= 1; // corrupt signature byte
  const rf = parseRequest("NEAT1." + flip.toString("base64url")); assert.ok(rf.ok); assert.equal((await verifyRequest(rf.ok ? rf.request : (null as any), rpc)).ok, false);
  const open = await createRequest(bob.signer, bob.id, {}); const po = parseRequest(open.qrText); assert.ok(po.ok && po.request.amt === undefined); assert.deepEqual(await verifyRequest(open.request, rpc), { ok: true });
});

test("already-paid detection by request id", async () => {
  const { request } = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("1")!, fixed: true });
  const rec = await send(parseNear("1")!, { request });
  assert.equal(alreadyPaid(request.id)?.id, rec.id);
  await assert.rejects(send(parseNear("1")!, { request }), (e: any) => e.code === "duplicate");
  assert.equal(chain.broadcasts, 1);
});

test("an open QR (no amount) can be paid again and again; an amount request is single-use; a failed attempt doesn't burn it", async () => {
  const open = await createRequest(bob.signer, bob.id, {});
  const a = await send(parseNear("0.1")!, { request: open.request });
  const b = await send(parseNear("0.2")!, { request: open.request });
  assert.notEqual(a.id, b.id);
  assert.equal(alreadyPaid(open.request.id), undefined, "a standing QR is never 'already paid'");
  assert.equal(chain.broadcasts, 2);

  const invoice = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("0.3")!, fixed: false }); // amount suggested, still an invoice
  const first = await send(parseNear("0.3")!, { request: invoice.request });
  await assert.rejects(send(parseNear("0.3")!, { request: invoice.request }), (e: any) => e.code === "duplicate");
  assert.equal(alreadyPaid(invoice.request.id)?.id, first.id);

  const retry = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("0.4")!, fixed: true });
  const est = await estimateTransferFee(rpc, alice.id, bob.id);
  const saved = chain.accounts.get(bob.id)!;
  chain.accounts.delete(bob.id); // the recipient vanishes: the transfer will fail on chain
  const r1 = await authorizeAndSend({ rpc, signer: alice.signer, fromId: alice.id, toId: bob.id, amount: parseNear("0.4")!, estimate: est, request: retry.request });
  assert.equal((await refreshTx(rpc, r1.id)).tx.status, "failed");
  chain.accounts.set(bob.id, saved);
  const r2 = await send(parseNear("0.4")!, { request: retry.request });
  assert.notEqual(r2.id, r1.id);
  assert.equal((await refreshTx(rpc, r2.id)).tx.status, "completed");
});

test("a name that already belongs to this wallet's key is reported as yours (crash recovery), and never for another key", async () => {
  const me = await generateKeypair(), other = await generateKeypair();
  chain.addAccount("mine.testnet", 1n, me.publicKey);
  assert.deepEqual(await checkAvailability(rpc, "mine", me.publicKey), { state: "yours" });
  assert.deepEqual(await checkAvailability(rpc, "mine", other.publicKey), { state: "taken" });
  assert.deepEqual(await checkAvailability(rpc, "mine"), { state: "taken" });
  assert.deepEqual(await checkAvailability(rpc, "free", me.publicKey), { state: "available" });
  const limited = await generateKeypair(); // a function-call-only key does not own the account
  chain.accounts.get("mine.testnet")!.keys.set(keyToString(limited.publicKey), { nonce: 0n, full: false });
  assert.deepEqual(await checkAvailability(rpc, "mine", limited.publicKey), { state: "taken" });
  chain.failNext = 10; // trouble reaching the network is "unknown", not "taken"
  assert.equal((await checkAvailability(rpc, "mine", me.publicKey)).state, "unknown");
  chain.failNext = 0;
});

test("name availability + registration end to end (funder pays, user key controls)", async () => {
  const funder = await generateKeypair();
  chain.addAccount("neat-funder.testnet", 100n, funder.publicKey);
  const secret = "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey]));
  const env = { NEAT_FUNDER_ID: "neat-funder.testnet", NEAT_FUNDER_KEY: secret, NEAT_STARTING_BALANCE: "0.5" };
  const user = await generateKeypair();

  assert.deepEqual(await checkAvailability(rpc, "dimeji"), { state: "available" });
  assert.equal((await checkAvailability(rpc, "bob")).state, "taken");
  assert.equal((await checkAvailability(rpc, "Bad Name")).state, "invalid");

  // service guards
  assert.equal((await handleRegister({ label: "dimeji", publicKey: keyToString(user.publicKey) }, {}, "9.9.9.9", rpc)).status, 503);
  assert.equal((await handleRegister({ label: "x", publicKey: keyToString(user.publicKey) }, env, "1.1.1.1", rpc)).status, 422);
  assert.equal((await handleRegister({ label: "dimeji", publicKey: "nope" }, env, "1.1.1.2", rpc)).status, 422);
  assert.equal((await handleRegister({ label: "bob", publicKey: keyToString(user.publicKey) }, env, "1.1.1.3", rpc)).status, 409);

  const r = await handleRegister({ label: "dimeji", publicKey: keyToString(user.publicKey) }, env, "1.1.1.4", rpc);
  assert.equal(r.status, 200);
  const acct = chain.accounts.get("dimeji.testnet")!;
  assert.equal(acct.amount, parseNear("0.5")!);
  assert.ok(acct.keys.get(keyToString(user.publicKey))?.full);
  assert.equal(chain.accounts.get("neat-funder.testnet")!.keys.size, 1);
  assert.equal(await confirmRegistered(rpc, "dimeji.testnet", user.publicKey, { timeoutMs: 50, intervalMs: 5 }), true);
  // a name is NOT confirmed for the wrong key, or for an account that does not exist
  const other = await generateKeypair();
  assert.equal(await confirmRegistered(rpc, "dimeji.testnet", other.publicKey, { timeoutMs: 30, intervalMs: 5 }), false);
  assert.equal(await confirmRegistered(rpc, "nobody.testnet", user.publicKey, { timeoutMs: 30, intervalMs: 5 }), false);
  assert.equal((await handleRegister({ label: "dimeji", publicKey: keyToString(user.publicKey) }, env, "1.1.1.5", rpc)).status, 409);
  // the funder service never learns any user secret: its request/response carry only public data
  const secretNeedle = Buffer.from(user.seed).toString("base64");
  assert.ok(!JSON.stringify(r).includes(secretNeedle));
});

test("registration status: registered only on chain evidence; an on-chain failure is reported with its reason", async () => {
  const funder = await generateKeypair();
  chain.addAccount("neat-funder.testnet", 100n, funder.publicKey);
  const env = { NEAT_FUNDER_ID: "neat-funder.testnet", NEAT_FUNDER_KEY: "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey])), NEAT_STARTING_BALANCE: "1" };
  const me = await generateKeypair();
  const reg = await handleRegister({ label: "zed", publicKey: keyToString(me.publicKey) }, env, "8.8.8.1", rpc);
  assert.equal(reg.status, 200);
  assert.equal(reg.body.signerId, "neat-funder.testnet"); // lets the client look the transaction up
  const tx = { hash: String(reg.body.txHash), signerId: String(reg.body.signerId) };
  assert.deepEqual(await checkRegistration(rpc, "zed.testnet", me.publicKey, tx), { state: "registered" });
  // not yet on chain: pending (never "registered")
  const ghostTx = { hash: base58Encode(new Uint8Array(32).fill(9)), signerId: "neat-funder.testnet" };
  assert.deepEqual(await checkRegistration(rpc, "later.testnet", me.publicKey, ghostTx), { state: "pending" });
  assert.deepEqual(await awaitRegistration(rpc, "later.testnet", me.publicKey, ghostTx, { timeoutMs: 20, intervalMs: 5 }), { state: "pending" });
  // someone else's key on the same name is not "registered" for us, and a second create_account for a taken name fails on chain
  const intruder = await generateKeypair();
  const fSigner = await signerFromSeed(funder.seed, funder.publicKey);
  const key = await rpc.viewAccessKey("neat-funder.testnet", keyToString(funder.publicKey));
  const block = await rpc.finalBlock();
  const bad = await signTransaction({ signerId: "neat-funder.testnet", publicKey: funder.publicKey, nonce: key!.nonce + 1n, receiverId: "testnet", blockHash: block.hash, actions: [{ type: "functionCall", method: "create_account", args: utf8.enc(JSON.stringify({ new_account_id: "zed.testnet", new_public_key: keyToString(intruder.publicKey) })), gas: 100_000_000_000_000n, deposit: 10n ** 24n }] }, fSigner);
  await rpc.broadcast(bad.bytes);
  const r = await checkRegistration(rpc, "zed.testnet", intruder.publicKey, { hash: bad.hash, signerId: "neat-funder.testnet" });
  assert.equal(r.state, "failed");
  assert.ok(r.state === "failed" && r.nameTaken && /another/i.test(r.reason));
  assert.equal(await confirmRegistered(rpc, "zed.testnet", intruder.publicKey, { timeoutMs: 20, intervalMs: 5 }), false);
  // reasons are human, never raw JSON
  assert.match(describeRegistrationFailure('{"NotEnoughBalance":{}}').reason, /funder has run out/);
  assert.equal(describeRegistrationFailure("whatever").nameTaken, false);
  assert.ok(!/[{}"]/.test(describeRegistrationFailure('{"ActionError":{}}').reason));
});

test("an empty funder is reported as the funder's problem, not the user's", async () => {
  const funder = await generateKeypair();
  const fa = chain.addAccount("neat-funder.testnet", 0n, funder.publicKey);
  fa.amount = 10n ** 20n; // far less than the starting balance
  const env = { NEAT_FUNDER_ID: "neat-funder.testnet", NEAT_FUNDER_KEY: "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey])), NEAT_STARTING_BALANCE: "1" };
  const user = await generateKeypair();
  const r = await handleRegister({ label: "newbie", publicKey: keyToString(user.publicKey) }, env, "6.6.6.6", rpc);
  assert.equal(r.status, 503);
  assert.equal(r.body.code, "funder_empty");
  assert.equal(chain.accounts.has("newbie.testnet"), false);
});

test("client registration surfaces service failures honestly", async () => {
  const f = (status: number, body: any) => (async () => new Response(JSON.stringify(body), { status })) as any;
  const k = new Uint8Array(32);
  assert.equal((await requestRegistration("abc", k, "/x", f(503, {}))).ok, false);
  const taken = await requestRegistration("abc", k, "/x", f(409, {})); assert.ok(!taken.ok && taken.code === "taken");
  // a bare 503 says nothing about why: it must not be dressed up as "not configured" (funder.test.ts covers the real codes)
  const un = await requestRegistration("abc", k, "/x", f(503, {})); assert.ok(!un.ok && un.code === "failed");
  const unc = await requestRegistration("abc", k, "/x", f(503, { code: "unconfigured" })); assert.ok(!unc.ok && unc.code === "unconfigured" && /isn't set up on this deployment/.test(unc.message));
  const empty = await requestRegistration("abc", k, "/x", f(503, { code: "funder_empty" })); assert.ok(!empty.ok && empty.code === "funder_empty" && /run out/.test(empty.message));
  const rate = await requestRegistration("abc", k, "/x", f(429, { code: "rate" })); assert.ok(!rate.ok && rate.code === "rate");
  const net = await requestRegistration("abc", k, "/x", (async () => { throw new Error("x"); }) as any); assert.ok(!net.ok && net.code === "network");
  const ok = await requestRegistration("abc", k, "/x", f(200, { txHash: "H" })); assert.ok(ok.ok && ok.accountId === "abc.testnet");
});

test("fee config: rationals are read from the [n, d] array NEAR actually serves, and from an object form", async () => {
  assert.deepEqual(parseRatio([103, 100]), { num: 103n, den: 100n });
  assert.deepEqual(parseRatio({ numerator: 11, denominator: 10 }), { num: 11n, den: 10n });
  for (const bad of [null, undefined, [103], [1, 0], [99, 100], "103/100", {}, [1, "x"]]) assert.equal(parseRatio(bad), null, JSON.stringify(bad));
  const cfg = await rpc.protocolConfig();
  assert.deepEqual(cfg.runtime_config.transaction_costs.pessimistic_gas_price_inflation_ratio, [103, 100]); // fixture uses the real shape
  assert.deepEqual(costsFromConfig(cfg).ratio, { num: 103n, den: 100n });
  const e = await estimateTransferFee(rpc, alice.id, bob.id);
  assert.equal(e.reserve, (e.fee * 103n) / 100n + 1n);
  // a different live ratio changes the reserve (so it is really read, not assumed)
  const bent = JSON.parse(JSON.stringify(cfg)); bent.runtime_config.transaction_costs.pessimistic_gas_price_inflation_ratio = [2, 1];
  const rpc2 = new Rpc({ endpoints: ["x"], fetchImpl: (async (_u: any, init: any) => { const j = JSON.parse(init.body); return new Response(JSON.stringify({ jsonrpc: "2.0", id: j.id, ...(j.method === "EXPERIMENTAL_protocol_config" ? { result: bent } : await chain.handle(j.method, j.params)) })); }) as any });
  const e2 = await estimateTransferFee(rpc2, alice.id, bob.id);
  assert.equal(e2.reserve, e2.fee * 2n + 1n);
  // an unreadable fee schedule refuses to quote rather than guessing
  assert.throws(() => costsFromConfig({ runtime_config: {} }), /fee schedule/);
});

test("transferOf reads only plain single-Transfer transactions", () => {
  const base = { signer_id: "a.testnet", receiver_id: "b.testnet" };
  assert.deepEqual(transferOf({ transaction: { ...base, actions: [{ Transfer: { deposit: "5" } }] } }), { from: "a.testnet", to: "b.testnet", amount: 5n });
  for (const raw of [null, {}, { transaction: { ...base, actions: [] } }, { transaction: { ...base, actions: [{ Transfer: { deposit: "5" } }, { Transfer: { deposit: "5" } }] } }, { transaction: { ...base, actions: [{ FunctionCall: { method_name: "x", deposit: "5" } }] } }, { transaction: { ...base, actions: ["CreateAccount"] } }, { transaction: { ...base, actions: [{ Transfer: { deposit: "0" } }] } }, { transaction: { ...base, actions: [{ Transfer: { deposit: "x" } }] } }]) assert.equal(transferOf(raw), null, JSON.stringify(raw));
});

const H1 = base58Encode(new Uint8Array(32).fill(1)), H2 = base58Encode(new Uint8Array(32).fill(2));

test("index parsing takes only candidates (hash, sender hint, time) and ignores everything else it claims", () => {
  const me = "bob.testnet";
  const good = { transaction_hash: H1, predecessor_account_id: "alice.testnet", receiver_account_id: me, block_timestamp: "1700000000000000000", actions: [{ action: "TRANSFER", method: null }], actions_agg: { deposit: 999 } };
  const junk = [{ ...good, transaction_hash: H2, receiver_account_id: "carol.testnet" }, { ...good, predecessor_account_id: me, transaction_hash: H2 }, { ...good, transaction_hash: "short" }, { ...good, transaction_hash: undefined }, "garbage", null, { ...good }]; // last one duplicates the good hash
  const hits = parseIndexTxns({ txns: [good, ...junk] }, me);
  assert.deepEqual(hits, [{ hash: H1, sender: "alice.testnet", tsMs: 1700000000000 }]);
  assert.deepEqual(parseIndexTxns({ txns: [{ ...good, signer_account_id: "dave.testnet" }] }, me)[0].sender, "dave.testnet"); // either schema works
  assert.equal(parseIndexTxns({ nonsense: 1 }, me).length, 0);
  assert.equal(parseIndexTxns(null, me).length, 0);
});

const indexFetch = (account: string, status = 200) => (async () => new Response(JSON.stringify(chain.indexFor(account)), { status })) as any;

test("incoming payments: facts come from the RPC; the index only nominates hashes; contract calls and creations are ignored", async () => {
  resetIndexState();
  const funder = await generateKeypair();
  chain.addAccount("neat-funder.testnet", 100n, funder.publicKey);
  const env = { NEAT_FUNDER_ID: "neat-funder.testnet", NEAT_FUNDER_KEY: "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey])), NEAT_STARTING_BALANCE: "1" };
  const carol = await generateKeypair();
  const reg = await handleRegister({ label: "carol", publicKey: keyToString(carol.publicKey) }, env, "7.7.7.7", rpc);
  assert.equal(reg.status, 200); // creates a receipt addressed to carol.testnet that is NOT a transfer
  const r = await send(parseNear("2")!); // alice → bob, recorded in ALICE's store
  // now act as Bob's device: a clean store, discovering the payment through the index
  store.useStorage(mem());
  const inc = await syncIncoming(rpc, bob.id, indexFetch(bob.id), { force: true });
  assert.equal(inc.added, 1);
  const t = store.getTx(r.id)!;
  assert.deepEqual([t.dir, t.from, t.to, t.amount, t.status], ["in", alice.id, bob.id, parseNear("2")!.toString(), "completed"]);
  assert.equal(t.onchainAmount, parseNear("2")!.toString());
  // the registration receipt (a function call to `testnet`, which the real index lists under carol) is not a payment
  const hash = String(reg.body.txHash);
  const listing = { txns: [{ transaction_hash: hash, predecessor_account_id: "testnet", receiver_account_id: "carol.testnet", receipt_kind: "ACTION", block_timestamp: "1700000000000000000" }] };
  const feed = (async () => new Response(JSON.stringify(listing))) as any;
  const none = await syncIncoming(rpc, "carol.testnet", feed, { force: true });
  assert.deepEqual(none, { added: 0, indexOk: true });
  assert.equal(store.load().txs.filter((x) => x.to === "carol.testnet").length, 0);
  const asked = chain.txs.get(hash)!.queries;
  assert.ok(asked >= 1, "the network was asked about it");
  await syncIncoming(rpc, "carol.testnet", feed, { force: true });
  assert.equal(chain.txs.get(hash)!.queries, asked, "a rejected hash is not looked up again");
});

test("incoming sync is throttled and backs off on rate limiting; failures are reported, not hidden", async () => {
  resetIndexState();
  let calls = 0;
  const f = (async () => { calls++; return new Response("{}", { status: 429 }); }) as any;
  const t0 = 1_000_000;
  assert.deepEqual(await syncIncoming(rpc, bob.id, f, { now: t0 }), { added: 0, indexOk: false });
  assert.deepEqual(await syncIncoming(rpc, bob.id, f, { now: t0 + 20_000 }), { added: 0, indexOk: false }); // still backing off (60s after a 429)
  assert.equal(calls, 1);
  await syncIncoming(rpc, bob.id, f, { now: t0 + 61_000 });
  assert.equal(calls, 2);
  resetIndexState();
  const ok = (async () => { calls++; return new Response(JSON.stringify({ txns: [] }), { status: 200 }); }) as any;
  const before = calls;
  assert.equal((await syncIncoming(rpc, bob.id, ok, { now: t0 })).indexOk, true);
  await syncIncoming(rpc, bob.id, ok, { now: t0 + 1000 }); // inside the 15 s gap: no second request
  assert.equal(calls, before + 1);
  const down = (async () => { throw new Error("offline"); }) as any;
  resetIndexState();
  assert.equal((await syncIncoming(rpc, bob.id, down, { now: t0 })).indexOk, false);
});

test("the payment index is rationed: background polling is rare until the balance rises, then normal for a while", async () => {
  resetIndexState();
  let calls = 0;
  const ok = (async () => { calls++; return new Response(JSON.stringify({ txns: [] })); }) as any;
  const t0 = 5_000_000;
  const bg = (now: number) => syncIncoming(rpc, bob.id, ok, { now, background: true });
  await syncIncoming(rpc, bob.id, ok, { now: t0 }); // opening a screen that shows payments always asks
  assert.equal(calls, 1);
  await bg(t0 + 20_000);
  await bg(t0 + 4 * 60_000); // 4 minutes on: still inside the idle gap
  assert.equal(calls, 1, "idle background polling does not ask");
  await bg(t0 + 5 * 60_000); // the slow safety net
  assert.equal(calls, 2);
  const T = t0 + 5 * 60_000;
  expectIncoming(T + 1000); // the balance rose
  await bg(T + 10_000);
  assert.equal(calls, 2, "still inside the normal 15 s gap");
  await bg(T + 20_000);
  await bg(T + 40_000);
  assert.equal(calls, 4, "while a payment is expected, lookups run at the normal pace");
  await bg(T + 200_000); // the 3 minute window has lapsed and the last lookup was 160 s ago
  assert.equal(calls, 4, "back to idle pace once the window lapses");
  await bg(T + 40_000 + 300_000);
  assert.equal(calls, 5);
});

test("a 429 backs off 1, 2, 4… minutes up to a cap, a success resets it, and 'force' is the only way around it", async () => {
  resetIndexState();
  let n = 0;
  const limited = (async () => { n++; return new Response("{}", { status: 429 }); }) as any;
  const waits = [1, 2, 4, 8, 16, 30, 30].map((m) => m * 60_000);
  let now = 9_000_000;
  for (const [i, wait] of waits.entries()) {
    await syncIncoming(rpc, bob.id, limited, { now });
    assert.equal(n, i + 1, `strike ${i + 1} asks once`);
    await syncIncoming(rpc, bob.id, limited, { now: now + wait - 1 });
    assert.equal(n, i + 1, `still backing off ${wait / 60_000} min after strike ${i + 1}`);
    now += wait;
  }
  await syncIncoming(rpc, bob.id, limited, { now: now - 1_000, force: true });
  assert.equal(n, waits.length + 1, "force asks regardless");
  const good = (async () => { n++; return new Response(JSON.stringify({ txns: [] })); }) as any;
  const base = n;
  assert.equal((await syncIncoming(rpc, bob.id, good, { now, force: true })).indexOk, true);
  await syncIncoming(rpc, bob.id, limited, { now: now + 20_000 }); // a fresh 429 starts the ladder again at one minute
  await syncIncoming(rpc, bob.id, limited, { now: now + 20_000 + 60_000 });
  assert.equal(n, base + 3, "after a success the first backoff is one minute, not the capped 30");
});

test("a requested amount is marked Paid only by a chain-verified, completed incoming transfer of at least that amount", async () => {
  const me = "bob.testnet";
  const { request } = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("3")!, fixed: true, now: 1700000000_000 - 1000 });
  store.update((s) => s.requests.push({ request, kind: "amount", state: "open", createdAt: 1700000000_000 - 1000 }));
  const inTx = (over: any) => ({ id: "H1", dir: "in" as const, from: "alice.testnet", to: me, amount: parseNear("3")!.toString(), status: "processing" as const, createdAt: 1700000000_000, updatedAt: 1, source: "index" as const, ...over });
  store.upsertTx(inTx({}));
  assert.equal(reconcileRequests(1700000100_000), 0); // not completed yet ⇒ not paid
  store.upsertTx(inTx({ status: "completed" }));
  assert.equal(reconcileRequests(1700000100_000), 0); // completed but no network-reported amount ⇒ still not paid
  store.upsertTx(inTx({ status: "completed", onchainAmount: parseNear("3")!.toString() }));
  assert.equal(reconcileRequests(1700000100_000), 1);
  assert.equal(store.load().requests[0].state, "paid");
  // an under-payment never satisfies a fixed amount
  const r2 = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("5")!, fixed: true, now: 1700000000_000 });
  store.update((s) => s.requests.push({ request: r2.request, kind: "amount", state: "open", createdAt: 1700000000_000 }));
  assert.equal(reconcileRequests(1700000100_000), 0);
  // a payment made before the request existed can't pay it
  const r4 = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("1")!, fixed: true, now: 1700001000_000 });
  store.update((s) => s.requests.push({ request: r4.request, kind: "amount", state: "open", createdAt: 1700001000_000 }));
  store.upsertTx(inTx({ id: "H9", status: "completed", onchainAmount: parseNear("1")!.toString(), createdAt: 1700000000_000 }));
  assert.equal(reconcileRequests(1700001100_000), 0);
  // expiry
  const r3 = await createRequest(bob.signer, bob.id, { amountYocto: parseNear("5")!, expiresInSec: 10, now: 1700000000_000 });
  store.update((s) => s.requests.push({ request: r3.request, kind: "amount", state: "open", createdAt: 1700000000_000 }));
  reconcileRequests(1800000000_000);
  assert.equal(store.load().requests.find((r) => r.request.id === r3.request.id)!.state, "expired");
});

test("a completed outgoing payment records the amount the NETWORK reports (evidence for 'received')", async () => {
  const rec = await send(parseNear("1.25")!);
  const t = await refreshTx(rpc, rec.id);
  assert.equal(t.tx.status, "completed");
  assert.equal(t.tx.onchainAmount, parseNear("1.25")!.toString());
  // a payment that only reached "processing" carries no verified amount yet
  chain.finalizeAfter = 5;
  const r2 = await send(parseNear("0.5")!);
  const p = await refreshTx(rpc, r2.id);
  assert.equal(p.tx.status, "processing"); assert.equal(p.tx.onchainAmount, undefined);
});

test("state survives reload and corrupt state is preserved, never silently replaced", () => {
  store.update((s) => (s.prefs.autoLockMin = 9));
  store.useStorage(shim);
  assert.equal(store.load().prefs.autoLockMin, 9);
  shim.setItem("neat.state.v1", "{not json");
  store.useStorage(shim);
  assert.equal(store.load().vault, null);
  assert.ok([...shim.m.keys()].some((k) => k.startsWith("neat.state.v1.corrupt.")));
});
