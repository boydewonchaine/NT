#!/usr/bin/env python3
"""Optional QR cross-check against OpenCV (driven by tests/qr.test.ts when python3 + OpenCV are installed).

  decode <dir>   decode the matrices NEAT's encoder wrote (<dir>/cases.json + <name>.txt, '1' = dark module,
                 4-module quiet zone included) with OpenCV; prints {name: decoded text | null}
  encode <dir>   encode <dir>/texts.json [{name, text, ecl}] with OpenCV's encoder and write
                 <dir>/<name>.pgm (8-bit grey, 6 px per module, 4-module quiet zone); prints [name, ...]
"""
import json
import sys

import cv2
import numpy as np


def decode_cases(d):
    cases = json.load(open(f"{d}/cases.json"))
    detectors = [cv2.QRCodeDetectorAruco(), cv2.QRCodeDetector()]
    out = {}
    for c in cases:
        rows = open(f"{d}/{c['name']}.txt").read().split("\n")
        m = np.array([[1 if ch == "1" else 0 for ch in r] for r in rows], dtype=np.uint8)
        img = np.where(m == 1, 0, 255).astype(np.uint8)
        got = None
        for scale in (6, 8, 4, 10):
            big = cv2.resize(img, (img.shape[1] * scale, img.shape[0] * scale), interpolation=cv2.INTER_NEAREST)
            for det in detectors:
                try:
                    text, _, _ = det.detectAndDecode(big)
                except cv2.error:
                    text = ""
                if text:
                    got = text
                    break
            if got:
                break
        out[c["name"]] = got
    print(json.dumps(out))


def encode_cases(d):
    texts = json.load(open(f"{d}/texts.json"))
    names = []
    for t in texts:
        p = cv2.QRCodeEncoder_Params()
        p.correction_level = cv2.QRCodeEncoder_CORRECT_LEVEL_L if t["ecl"] == "L" else cv2.QRCodeEncoder_CORRECT_LEVEL_M
        p.mode = cv2.QRCodeEncoder_MODE_BYTE
        enc = cv2.QRCodeEncoder.create(p)
        try:
            img = enc.encode(t["text"])
        except cv2.error:
            continue  # OpenCV's encoder can't make every size; skip rather than fail the comparison
        img = cv2.copyMakeBorder(img, 4, 4, 4, 4, cv2.BORDER_CONSTANT, value=255)
        img = cv2.resize(img, (img.shape[1] * 6, img.shape[0] * 6), interpolation=cv2.INTER_NEAREST)
        h, w = img.shape
        with open(f"{d}/{t['name']}.pgm", "wb") as f:
            f.write(f"P5\n{w} {h}\n255\n".encode() + img.astype(np.uint8).tobytes())
        names.append(t["name"])
    print(json.dumps(names))


if __name__ == "__main__":
    {"decode": decode_cases, "encode": encode_cases}[sys.argv[1]](sys.argv[2])
