// TEST-ONLY server for end-to-end runs: serves the built app + a mock NEAR chain + the real
// registration handler + a NearBlocks-shaped index. Nothing here ships to production.
import { createServer } from "node:http";
import { readFileSync, existsSync, statSync } from "node:fs";
import { extname, join } from "node:path";
import { MockChain } from "./mock-chain";
import { Rpc } from "../src/core/rpc";
import { funderStatus, handleRegister } from "../src/server/register";
import { generateKeypair } from "../src/core/near";
import { base58Encode } from "../src/core/encoding";

const TYPES: Record<string, string> = { ".html": "text/html; charset=utf-8", ".js": "text/javascript", ".css": "text/css", ".svg": "image/svg+xml", ".png": "image/png", ".webmanifest": "application/manifest+json", ".json": "application/json" };

export async function startServer(dist: string, port: number, opts: { funded?: boolean } = {}) {
  const chain = new MockChain();
  const funder = await generateKeypair();
  chain.addAccount("neat-funder.testnet", 10_000n, funder.publicKey);
  const envFull: Record<string, string> = {
    NEAT_FUNDER_ID: "neat-funder.testnet",
    NEAT_FUNDER_KEY: "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...funder.publicKey])),
    NEAT_STARTING_BALANCE: "5",
  };
  const env: Record<string, string> = opts.funded === false ? {} : { ...envFull };
  const savedKeys = new Map<string, Map<string, any>>();
  const hidden = new Map<string, any>();
  const rpc = new Rpc({ endpoints: ["http://mock"], fetchImpl: chain.fetchImpl as any });
  const stats = { registerCalls: 0, rpcCalls: 0 };
  let regIp = 0, statusIp = 0;

  const server = createServer(async (req, res) => {
    const url = new URL(req.url!, `http://127.0.0.1:${port}`);
    const body = await new Promise<string>((r) => { let b = ""; req.on("data", (c) => (b += c)); req.on("end", () => r(b)); });
    const json = (status: number, obj: any, extra: Record<string, string> = {}) => { res.writeHead(status, { "content-type": "application/json", "access-control-allow-origin": "*", ...extra }); res.end(JSON.stringify(obj)); };
    if (req.method === "OPTIONS") { res.writeHead(204, { "access-control-allow-origin": "*", "access-control-allow-headers": "content-type, authorization" }); return res.end(); }
    if (url.pathname === "/rpc") {
      stats.rpcCalls++;
      const j = JSON.parse(body);
      return json(200, { jsonrpc: "2.0", id: j.id, ...(await chain.handle(j.method, j.params)) });
    }
    if (url.pathname === "/api/register") {
      if (req.method === "GET") {
        const out = await funderStatus(env, rpc, "10.1.0." + (statusIp++ % 250)); // the "is registration ready?" check; registers nothing
        return json(out.status, out.body);
      }
      stats.registerCalls++;
      const out = await handleRegister(JSON.parse(body || "{}"), env, "10.0.0." + (regIp++ % 250), rpc);
      return json(out.status, out.body);
    }
    const m = /^\/index\/v1\/account\/([^/]+)\/txns$/.exec(url.pathname);
    if (m) return json(200, chain.indexFor(decodeURIComponent(m[1])));
    if (url.pathname.startsWith("/__test/")) {
      const j = body ? JSON.parse(body) : {};
      switch (url.pathname.slice(8)) {
        case "set": Object.assign(chain, j); return json(200, { ok: true });
        case "balance": return json(200, { amount: (chain.accounts.get(j.id)?.amount ?? 0n).toString() });
        case "fund": { const a = chain.accounts.get(j.id)!; a.amount += BigInt(j.yocto); return json(200, { ok: true }); }
        case "echo": return json(200, { headers: req.headers }); // what the server saw, to observe the page's real referrer behaviour
        case "setbalance": { chain.accounts.get(j.id)!.amount = BigInt(j.yocto); return json(200, { ok: true }); }
        case "stats": return json(200, { ...stats, broadcasts: chain.broadcasts, log: chain.log });
        // simulate the world changing under the app: a revoked key, a deleted recipient, an unconfigured/out-of-gas funder
        case "delkey": { const a = chain.accounts.get(j.id)!; savedKeys.set(j.id, new Map(a.keys)); a.keys.clear(); return json(200, { ok: true }); }
        case "addkey": { const a = chain.accounts.get(j.id)!; for (const [k, v] of savedKeys.get(j.id) ?? []) a.keys.set(k, v); savedKeys.delete(j.id); return json(200, { ok: true }); }
        case "hide": { hidden.set(j.id, chain.accounts.get(j.id)); chain.accounts.delete(j.id); return json(200, { ok: true }); }
        case "unhide": { chain.accounts.set(j.id, hidden.get(j.id)); hidden.delete(j.id); return json(200, { ok: true }); }
        case "funder": { for (const k of Object.keys(env)) delete env[k]; if (j.on) Object.assign(env, envFull); return json(200, { ok: true }); }
        // change single settings, the way a half-finished dashboard setup would: { unset: ["NEAT_FUNDER_KEY"], set: { NEAT_FUNDER_KEY: "x" } }
        case "env": { for (const k of j.unset ?? []) delete env[k]; Object.assign(env, j.set ?? {}); return json(200, { ok: true }); }
        case "drain-funder": { const a = chain.accounts.get("neat-funder.testnet")!; if (j.restore !== undefined) a.amount = BigInt(j.restore); else { const was = a.amount; a.amount = 10n ** 20n; return json(200, { was: was.toString() }); } return json(200, { ok: true }); }
      }
    }
    let path = join(dist, url.pathname === "/" ? "index.html" : url.pathname);
    if (!existsSync(path) || statSync(path).isDirectory()) path = join(dist, "index.html");
    res.writeHead(200, { "content-type": TYPES[extname(path)] ?? "application/octet-stream", "cache-control": "no-cache" });
    res.end(readFileSync(path));
  });
  await new Promise<void>((r) => server.listen(port, "127.0.0.1", r));
  return { server, chain, stats, close: () => new Promise<void>((r) => server.close(() => r())) };
}

if (process.argv[1]?.endsWith("e2e-server.ts")) {
  const dist = process.argv[2], port = Number(process.argv[3] ?? 4173);
  startServer(dist, port).then(() => console.log("e2e server on", port));
}
