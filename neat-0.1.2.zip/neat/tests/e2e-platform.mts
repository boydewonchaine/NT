// End-to-end, suite 3 of 3: the platform and privacy claims, checked against the real browser.
//   · installable PWA (manifest, icons, installability errors from Chrome itself, offline shell, honest install UI)
//   · the Content-Security-Policy is actually enforced
//   · the LIVE camera path (Chromium fake device streaming a video of a real NEAT QR), and what happens when it isn't available
//   · auto-lock (timers, activity, backgrounding) on a controlled clock
//   · splash + reduced motion
//   · secrets: the sentence, the key and the encryption key are searched for, in every encoding, in everything the app
//     sends, stores, logs, caches, shares or shows in a URL.
import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { join } from "node:path";
import { pbkdf2Sync } from "node:crypto";
import { OUT, ORIGIN, NEAR, VIEW, chromium, createWallet, openSuite, prep, qrImage, scanUpload, unlock } from "./e2e-lib.mts";
import { createRequest, encodeRequest } from "../src/core/payload";
import { generateKeypair, keyFromString, signerFromSeed } from "../src/core/near";
import { normalizeSentence, open as openVault } from "../src/core/vault";
import { base58Encode, fromBase64, fromBase64Url } from "../src/core/encoding";

const S = await openSuite("platform");
const { chain, post, browser, newCtx, watch, check, shot, state, finish, logs, allowConsole } = S;
const here = import.meta.dirname as string;
const SENT_PAYER = "cobalt kites drift above quiet harbours";
const stat = () => post("stats") as Promise<{ broadcasts: number; registerCalls: number }>;
const NOTES: string[] = [];
const note = (s: string) => { NOTES.push(s); console.log("NOTE  " + s); };

// =====================================================================================
// 1. PWA: manifest, icons, installability, service worker, install UI
// =====================================================================================
const ctx1 = await newCtx();
const p1 = await ctx1.newPage();
watch(p1, "pwa");
await p1.goto(ORIGIN + "/");
await p1.waitForSelector('input[aria-label="Personal sentence"]');
{
  const manifest = await (await fetch(ORIGIN + "/manifest.webmanifest")).json();
  check("manifest has id, name, start_url, scope, standalone display, theme/background colours, lang", manifest.id === "/" && manifest.name === "NEAT" && manifest.start_url === "/" && manifest.scope === "/" && manifest.display === "standalone" && /^#[0-9a-f]{6}$/i.test(manifest.theme_color) && /^#[0-9a-f]{6}$/i.test(manifest.background_color) && manifest.lang === "en");
  const sizeOf = (b: Buffer) => ({ w: b.readUInt32BE(16), h: b.readUInt32BE(20), png: b.subarray(1, 4).toString() === "PNG" });
  const bad: string[] = [];
  for (const icon of manifest.icons) {
    const r = await fetch(new URL(icon.src, ORIGIN));
    const buf = Buffer.from(await r.arrayBuffer());
    if (!r.ok) { bad.push(`${icon.src}: HTTP ${r.status}`); continue; }
    if (icon.type === "image/png") {
      const d = sizeOf(buf);
      if (!d.png || `${d.w}x${d.h}` !== icon.sizes) bad.push(`${icon.src}: file is ${d.w}x${d.h}, manifest says ${icon.sizes}`);
    } else if (!/image\/svg\+xml/.test(r.headers.get("content-type") ?? "")) bad.push(`${icon.src}: content-type ${r.headers.get("content-type")}`);
  }
  check("every manifest icon exists and its real pixel size matches what the manifest declares", bad.length === 0, bad.join(" ; "));

  // icon artwork: the maskable icon must be full-bleed with the mark inside the safe zone; the Apple icon must be opaque
  const probe = (url: string) => p1.evaluate(async (u: string) => {
    const img = new Image(); img.src = u; await img.decode();
    const c = document.createElement("canvas"); c.width = img.naturalWidth; c.height = img.naturalHeight;
    const g = c.getContext("2d")!; g.drawImage(img, 0, 0);
    const S = c.width, px = g.getImageData(0, 0, S, S).data;
    const at = (x: number, y: number) => Array.from(px.slice((y * S + x) * 4, (y * S + x) * 4 + 4));
    let far = 0, dark = 0;
    for (let y = 0; y < S; y++) for (let x = 0; x < S; x++) {
      const i = (y * S + x) * 4;
      if (px[i + 3] > 200 && px[i] < 110 && px[i + 1] < 110 && px[i + 2] < 110) { dark++; far = Math.max(far, Math.hypot(x - S / 2, y - S / 2)); }
    }
    return { S, corners: [at(0, 0), at(S - 1, 0), at(0, S - 1), at(S - 1, S - 1)], dark, safe: far / S };
  }, url);
  const mk = await probe("/icons/maskable-512.png");
  check("maskable icon: opaque in all four corners (full bleed) and the mark lies inside the 40% safe-zone radius", mk.corners.every((c: number[]) => c[3] === 255) && mk.dark > 500 && mk.safe <= 0.4, JSON.stringify({ safe: mk.safe.toFixed(3), dark: mk.dark }));
  const ap = await probe("/icons/apple-touch-icon.png");
  check("Apple touch icon is 180×180 and opaque (iOS paints transparency black)", ap.S === 180 && ap.corners.every((c: number[]) => c[3] === 255) && ap.dark > 100);
  const any = await probe("/icons/icon-512.png");
  check("the 512 icon actually contains the dark chevron mark", any.dark > 500);

  // Chrome's own verdict
  const cdp = await ctx1.newCDPSession(p1);
  await cdp.send("Page.enable");
  const m = await cdp.send("Page.getAppManifest");
  const inst = await cdp.send("Page.getInstallabilityErrors");
  const errs = (inst.installabilityErrors ?? []).map((e: any) => e.errorId + (e.errorArguments?.length ? ` ${JSON.stringify(e.errorArguments)}` : ""));
  check("Chrome parses the manifest with no errors", (m.errors ?? []).length === 0, JSON.stringify(m.errors));
  check("Chrome reports NO installability errors for the page", errs.length === 0, errs.join(" ; "));
  await cdp.detach();
  note(`Chrome installability errors: ${errs.length ? errs.join(", ") : "none"}; manifest warnings: ${(m.errors ?? []).length}`);

  const hasMeta = await p1.evaluate(() => ({
    viewport: document.querySelector('meta[name="viewport"]')?.getAttribute("content") ?? "",
    themes: [...document.querySelectorAll('meta[name="theme-color"]')].map((e) => e.getAttribute("media")),
    manifest: !!document.querySelector('link[rel="manifest"]'),
    touch: !!document.querySelector('link[rel="apple-touch-icon"]'),
    lang: document.documentElement.lang,
    title: document.title,
  }));
  check("viewport allows zoom (no user-scalable=no / maximum-scale), has light+dark theme colours, apple-touch-icon, lang", !/user-scalable\s*=\s*(no|0)|maximum-scale\s*=\s*1(\.0)?\b/.test(hasMeta.viewport) && hasMeta.themes.length === 2 && hasMeta.touch && hasMeta.manifest && hasMeta.lang === "en", JSON.stringify(hasMeta));
}

// service worker
{
  const sw = await p1.evaluate(async () => { const r = await navigator.serviceWorker.ready; return { scope: r.scope, state: r.active?.state, script: r.active?.scriptURL }; });
  check("service worker is active with scope '/'", sw.state === "activated" && sw.scope === ORIGIN + "/", JSON.stringify(sw));
  const cached = await p1.evaluate(async () => { const out: string[] = []; for (const k of await caches.keys()) for (const r of await (await caches.open(k)).keys()) out.push(new URL(r.url).pathname); return out; });
  check("the cache holds the app shell (page, script, style, manifest, icons)", ["/index.html", "/manifest.webmanifest"].every((x) => cached.includes(x)) && cached.some((x) => /^\/assets\/.*\.js$/.test(x)) && cached.some((x) => /^\/assets\/.*\.css$/.test(x)) && cached.some((x) => x.startsWith("/icons/")), cached.join(","));
}

// Content-Security-Policy: not just present, enforced
{
  const cp = await ctx1.newPage(); // not watched: the probes below intentionally provoke CSP console errors
  await cp.goto(ORIGIN + "/");
  await cp.waitForSelector('input[aria-label="Personal sentence"]');
  // DevTools-evaluated code is exempt from 'unsafe-eval' restrictions, so eval / new Function are attempted from TIMER
  // callbacks, which run as ordinary page code and are subject to the policy exactly as the app's own code is.
  const csp = await cp.evaluate(async () => {
    const violations: { dir: string; blocked: string }[] = [];
    document.addEventListener("securitypolicyviolation", (e) => violations.push({ dir: e.violatedDirective, blocked: e.blockedURI }));
    const w = window as any;
    setTimeout(() => { try { new Function("window.__fn = 1")(); } catch { /* blocked */ } }, 0);
    setTimeout("window.__evalString = 1" as any, 0); // string argument = eval sink
    setTimeout(() => { try { (0, eval)("window.__eval = 1"); } catch { /* blocked */ } }, 0);
    const inline = document.createElement("script"); inline.textContent = "window.__inline = 1"; document.head.append(inline);
    const remote = document.createElement("script"); remote.src = "https://example.com/x.js"; document.head.append(remote);
    let thirdPartyFetch = "ALLOWED";
    try { await fetch("https://example.com/", { mode: "no-cors" }); } catch { thirdPartyFetch = "blocked"; }
    const fr = document.createElement("iframe"); fr.src = "https://example.com/"; document.body.append(fr);
    const img = new Image(); img.src = "https://example.com/pixel.png"; document.body.append(img);
    await new Promise((res) => setTimeout(res, 500));
    return { ran: ["__fn", "__evalString", "__eval", "__inline"].filter((k) => w[k]), thirdPartyFetch, violations: [...new Set(violations.map((v) => v.dir + (v.blocked === "eval" ? "(eval)" : "")))].sort().join(",") };
  });
  const policy = await cp.evaluate(() => document.querySelector('meta[http-equiv="Content-Security-Policy"]')?.getAttribute("content") ?? "");
  check("the policy forbids inline script and eval: script-src is 'self' only, default-src 'none', no unsafe-* anywhere", /default-src 'none'/.test(policy) && /script-src 'self'(;|$)/.test(policy) && !/unsafe-/.test(policy) && /object-src 'none'/.test(policy) && /base-uri 'none'/.test(policy) && /form-action 'none'/.test(policy), policy);
  check("CSP is enforced in the browser: eval, new Function, inline script, remote script, third-party fetch, frames and remote images are all blocked", csp.ran.length === 0 && csp.thirdPartyFetch === "blocked" && /script-src\(eval\)/.test(csp.violations) && /connect-src/.test(csp.violations) && /frame-src/.test(csp.violations) && /img-src/.test(csp.violations) && /script-src-elem/.test(csp.violations), JSON.stringify(csp));
  await cp.close();
}

// =====================================================================================
// 2. Splash + reduced motion
// =====================================================================================
{
  // sample the splash every 15 ms for 2.5 s: the animation as it is really computed, and the last frame's opacity
  const sample = () => `(() => { const out = []; window.__splash = out; const t0 = performance.now(); const id = setInterval(() => { const m = document.querySelector('.splash .mark, .splash svg'); if (m) { const cs = getComputedStyle(m); out.push({ name: cs.animationName, dur: cs.animationDuration, op: cs.opacity }); } if (performance.now() - t0 > 2500) clearInterval(id); }, 15); })()`;
  type Sample = { name: string; dur: string; op: string };
  const one = async (reduced: boolean) => {
    const c = await newCtx({ reducedMotion: reduced ? "reduce" : "no-preference" });
    const pg = await c.newPage();
    watch(pg, "splash-" + (reduced ? "reduced" : "normal"));
    await pg.addInitScript(sample());
    await pg.goto(ORIGIN + "/");
    await pg.waitForSelector('input[aria-label="Personal sentence"]', { timeout: 8000 });
    const s: Sample[] = await pg.evaluate(() => (window as any).__splash);
    await c.close();
    return s;
  };
  const secs = (d: string) => (d.endsWith("ms") ? parseFloat(d) / 1000 : parseFloat(d));
  const normal = await one(false), reduced = await one(true);
  check("splash animates normally (a real, named animation with a visible duration)", normal.length >= 5 && normal.some((x) => x.name !== "none" && secs(x.dur) >= 0.3), JSON.stringify(normal.slice(0, 2)));
  check("with reduced-motion the splash animation is switched off (≈0 duration at every sample) and the mark ends fully visible", reduced.length >= 2 && reduced.every((x) => secs(x.dur) <= 0.01) && Number(reduced[reduced.length - 1].op) === 1, JSON.stringify({ n: reduced.length, first: reduced[0], last: reduced[reduced.length - 1] }));
}

// =====================================================================================
// 3. The LIVE camera path
// =====================================================================================
const m = await generateKeypair();
chain.addAccount("merchant.testnet", 1n, m.publicKey);
const camReq = await createRequest(await signerFromSeed(m.seed, m.publicKey), "merchant.testnet", { amountYocto: (3n * NEAR) / 10n, fixed: true, note: "camera test" });
const camPng = `${OUT}/camera-qr.png`;
await qrImage(browser, camReq.qrText, camPng);
execFileSync("python3", ["-I", join(here, "fake_camera.py"), camPng, `${OUT}/camera-qr.y4m`], { stdio: "pipe" });
execFileSync("python3", ["-I", join(here, "fake_camera.py"), "-", `${OUT}/camera-empty.y4m`], { stdio: "pipe" });

const trackStreams = () => {
  const orig = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
  (window as any).__streams = [];
  navigator.mediaDevices.getUserMedia = async (c) => { const s = await orig(c); (window as any).__streams.push(s); return s; };
};
const flags = (y4m: string) => ["--use-fake-device-for-media-stream", "--use-fake-ui-for-media-stream", `--use-file-for-fake-video-capture=${y4m}`];
let payerState: any;

{
  const camBrowser = await chromium.launch({ args: flags(`${OUT}/camera-qr.y4m`) });
  const ctx = await prep(await camBrowser.newContext({ viewport: VIEW, deviceScaleFactor: 2, permissions: ["camera"] }));
  await ctx.addInitScript(trackStreams);
  const cam = await ctx.newPage();
  watch(cam, "camera");
  await createWallet(cam, SENT_PAYER, "payer");
  await cam.waitForSelector(".home");
  payerState = await ctx.storageState();
  const native = await cam.evaluate(async () => { const BD = (globalThis as any).BarcodeDetector; if (!BD) return "absent"; try { return (await BD.getSupportedFormats()).includes("qr_code") ? "present (qr_code)" : "present (no qr_code)"; } catch { return "present (unreadable)"; } });
  note(`live-camera run: native BarcodeDetector is ${native}; decoding therefore used ${native === "present (qr_code)" ? "the native detector" : "NEAT's own software decoder"}`);
  const before = await stat();
  const t0 = Date.now();
  await cam.getByRole("button", { name: "Send", exact: true }).click();
  await cam.waitForSelector("text=Scan to pay");
  await shot(cam, "camera-scanning");
  let found = true;
  try { await cam.waitForSelector("text=Paying", { timeout: 40000 }); } catch { found = false; }
  const ms = Date.now() - t0;
  check("LIVE camera: the scanner finds the QR in the video stream on its own and opens the Amount screen", found, found ? "" : (await cam.innerText("main")).replace(/\n/g, " | ").slice(0, 200));
  if (found) {
    note(`live-camera scan took ${ms} ms from opening Scan to the Amount screen`);
    const t = await cam.innerText("main");
    check("…it shows the verified recipient, the fixed requested amount and the note, exactly as signed", /merchant/.test(await cam.innerText("h1")) && /Requested amount/.test(t) && /camera test/.test(t) && (await cam.inputValue('input[aria-label="Amount in NEAR"]')) === "0.3" && /Verified/.test(t));
    check("…scanning moved no money and signed nothing", (await stat()).broadcasts === before.broadcasts);
    const ended = await cam.evaluate(() => { const s: MediaStream[] = (window as any).__streams; return { n: s.length, allEnded: s.length > 0 && s.every((x) => x.getTracks().every((t) => t.readyState === "ended")) }; });
    check("the camera is switched off as soon as a QR is read", ended.allEnded, JSON.stringify(ended));
  }
  await camBrowser.close();

  // camera on, nothing to scan: leaving the screen must turn the camera off
  const emptyBrowser = await chromium.launch({ args: flags(`${OUT}/camera-empty.y4m`) });
  const c2 = await prep(await emptyBrowser.newContext({ viewport: VIEW, deviceScaleFactor: 2, permissions: ["camera"], storageState: payerState }));
  await c2.addInitScript(trackStreams);
  const e = await c2.newPage();
  watch(e, "camera-empty");
  await e.goto(ORIGIN + "/");
  await unlock(e, SENT_PAYER);
  await e.getByRole("button", { name: "Send", exact: true }).click();
  await e.waitForSelector("text=Scan to pay");
  await e.waitForFunction(() => (window as any).__streams.length === 1 && (window as any).__streams[0].getTracks().some((t: MediaStreamTrack) => t.readyState === "live"), null, { timeout: 15000 });
  await e.waitForFunction(() => { const v = document.querySelector("video") as HTMLVideoElement | null; return !!v && v.videoWidth > 0; }, null, { timeout: 15000 });
  check("camera is live and streaming video on the Scan screen (an empty scene produces no false QR)", /Scan to pay/.test(await e.innerText("h1")) && (await e.locator('[role="alert"]').count()) === 0);
  await shot(e, "camera-empty-scene");
  await e.getByRole("button", { name: "Back", exact: true }).click();
  await e.waitForSelector(".home");
  const off = await e.evaluate(() => (window as any).__streams.every((s: MediaStream) => s.getTracks().every((t) => t.readyState === "ended")));
  check("leaving the Scan screen with Back turns the camera off", off);
  await emptyBrowser.close();
}

// camera not available / denied / absent: say so, and uploading a photo still works
{
  const cases: { id: string; script?: () => void; expect: RegExp; text: string }[] = [
    { id: "no camera device", expect: /Couldn't start the camera\. You can upload a photo/, text: "no device" },
    { id: "permission denied", script: () => { navigator.mediaDevices.getUserMedia = () => Promise.reject(new DOMException("denied", "NotAllowedError")); }, expect: /Camera access was blocked\. Allow it in your browser, or upload a photo of the QR\./, text: "denied" },
    { id: "no camera API at all", script: () => { Object.defineProperty(navigator, "mediaDevices", { value: undefined, configurable: true }); }, expect: /Camera isn't available here\. Upload a photo of the QR instead\./, text: "no API" },
  ];
  for (const c of cases) {
    const ctx = await newCtx({ storageState: payerState });
    if (c.script) await ctx.addInitScript(c.script);
    const pg = await ctx.newPage();
    watch(pg, "nocam-" + c.text);
    await pg.goto(ORIGIN + "/");
    await unlock(pg, SENT_PAYER);
    await pg.getByRole("button", { name: "Send", exact: true }).click();
    await pg.waitForSelector("text=Scan to pay");
    let said = true;
    try { await pg.waitForFunction((re: string) => new RegExp(re).test(document.querySelector(".scanner .msg")?.textContent ?? ""), c.expect.source, { timeout: 8000 }); } catch { said = false; }
    check(`camera ${c.id}: the screen says exactly what is wrong`, said, (await pg.locator(".scanner .msg").innerText().catch(() => "")).slice(0, 160));
    if (c.id === "permission denied") await shot(pg, "camera-denied");
    await pg.setInputFiles("#qrfile", camPng);
    let reached = true;
    try { await pg.waitForSelector("text=Paying", { timeout: 15000 }); } catch { reached = false; }
    check(`…and the photo-upload fallback still completes the scan (${c.id})`, reached && /merchant/.test(await pg.innerText("h1").catch(() => "")));
    await ctx.close();
  }
}

// =====================================================================================
// 4. Auto-lock on a controlled clock
// =====================================================================================
{
  const ctx = await newCtx({ storageState: payerState });
  await ctx.clock.install();
  const pg = await ctx.newPage();
  watch(pg, "autolock");
  await pg.goto(ORIGIN + "/");
  await unlock(pg, SENT_PAYER);
  const locked = async () => (await pg.locator('input[aria-label="Your personal sentence"]').count()) === 1;
  const home = async () => (await pg.locator(".home").count()) === 1;
  const setLock = async (value: string) => {
    await pg.getByRole("button", { name: "Settings" }).click();
    await pg.selectOption('select[aria-label="Auto-lock"]', value);
    await pg.getByRole("button", { name: "Back", exact: true }).click();
    await pg.waitForSelector(".home");
  };
  const hide = (on: boolean) => pg.evaluate((h: boolean) => { Object.defineProperty(document, "visibilityState", { get: () => (h ? "hidden" : "visible"), configurable: true }); document.dispatchEvent(new Event("visibilitychange")); }, on);

  await setLock("1");
  await ctx.clock.fastForward("00:45");
  check("auto-lock (1 min): still unlocked after 45 s of inactivity", await home() && !(await locked()));
  await ctx.clock.fastForward("00:30");
  await pg.waitForSelector('input[aria-label="Your personal sentence"]', { timeout: 5000 });
  check("auto-lock (1 min): locked after 75 s, the unlock screen is shown and the wallet screen is gone", (await locked()) && !(await home()) && (await pg.locator(".balance").count()) === 0);

  await unlock(pg, SENT_PAYER);
  await ctx.clock.fastForward("00:50");
  await pg.mouse.click(200, 400); // any interaction restarts the countdown
  await ctx.clock.fastForward("00:50");
  check("activity restarts the auto-lock countdown (100 s total, but only 50 s since the last touch)", await home());
  await ctx.clock.fastForward("00:30");
  await pg.waitForSelector('input[aria-label="Your personal sentence"]', { timeout: 5000 });
  check("…and it locks once a full minute passes with no activity", await locked());

  await unlock(pg, SENT_PAYER);
  await hide(true);
  await ctx.clock.fastForward("00:30");
  await hide(false);
  check("backgrounded for 30 s with a 1-minute setting: still unlocked", await home());
  await hide(true);
  await ctx.clock.fastForward("02:00");
  await hide(false);
  await pg.waitForSelector('input[aria-label="Your personal sentence"]', { timeout: 5000 });
  check("backgrounded for 2 minutes with a 1-minute setting: locked on return", await locked());

  await unlock(pg, SENT_PAYER);
  await setLock("0");
  await ctx.clock.fastForward("03:00:00");
  check("'Only when I lock': never locks by itself, however long it sits idle", await home());
  await hide(true);
  await ctx.clock.fastForward("12:00:00");
  await hide(false);
  check("'Only when I lock': coming back from the background does NOT lock either (the setting means what it says)", await home() && !(await locked()));
  await pg.getByRole("button", { name: "Lock" }).click();
  await pg.waitForSelector('input[aria-label="Your personal sentence"]');
  check("…and the Lock button always works", await locked());
  const keep = await state(pg);
  check("the chosen auto-lock setting is remembered across a reload", keep.prefs.autoLockMin === 0);
  await ctx.close();
}

// =====================================================================================
// 5. Install UI is honest; standalone mode is recognised
// =====================================================================================
{
  const ctx = await newCtx({ storageState: payerState });
  const pg = await ctx.newPage();
  watch(pg, "install");
  await pg.goto(ORIGIN + "/");
  await unlock(pg, SENT_PAYER);
  await pg.getByRole("button", { name: "Settings" }).click();
  await pg.waitForSelector("text=Danger zone");
  const t = await pg.innerText("main");
  check("no install event from the browser → no fake 'Install' button; instructions are shown instead", (await pg.getByRole("button", { name: "Install NEAT" }).count()) === 0 && /Install app|Add to Home Screen/.test(t));
  await pg.evaluate(() => {
    const ev: any = new Event("beforeinstallprompt", { cancelable: true });
    ev.prompt = () => { (window as any).__prompted = ((window as any).__prompted ?? 0) + 1; return Promise.resolve(); };
    window.dispatchEvent(ev);
  });
  await pg.getByRole("button", { name: "Back", exact: true }).click();
  await pg.getByRole("button", { name: "Settings" }).click();
  await pg.getByRole("button", { name: "Install NEAT" }).waitFor({ timeout: 5000 });
  await shot(pg, "settings-install");
  await pg.getByRole("button", { name: "Install NEAT" }).click();
  await pg.waitForFunction(() => (window as any).__prompted === 1, null, { timeout: 5000 });
  check("when the browser offers installation the button appears and triggers the browser's own prompt exactly once", (await pg.getByRole("button", { name: "Install NEAT" }).count()) === 0);
  // Chromium can't emulate the display-mode media feature, so the page is told it is running standalone the way an
  // installed PWA would see it (the app reads matchMedia("(display-mode: standalone)")).
  await pg.evaluate(() => { const orig = window.matchMedia.bind(window); const noop = () => {}; window.matchMedia = (q: string) => (/display-mode:\s*standalone/.test(q) ? ({ matches: true, media: q, onchange: null, addEventListener: noop, removeEventListener: noop, addListener: noop, removeListener: noop, dispatchEvent: () => false } as MediaQueryList) : orig(q)); });
  await pg.getByRole("button", { name: "Back", exact: true }).click();
  await pg.getByRole("button", { name: "Settings" }).click();
  await pg.waitForSelector("text=NEAT is installed on this device");
  check("in standalone (installed) mode Settings says it is installed and shows no install controls", (await pg.getByRole("button", { name: "Install NEAT" }).count()) === 0);
  await ctx.close();
}

// =====================================================================================
// 6. Secrets: search everything the app sends, stores, logs, caches or shows in a URL
// =====================================================================================
type Hay = { name: string; text: string; buf?: Buffer };
type Secret = { owner: string; what: string; needles: { form: string; text: string }[]; raw?: Buffer };

function encodings(bytes: Uint8Array): { form: string; text: string }[] {
  const b = Buffer.from(bytes);
  const out = [{ form: "hex", text: b.toString("hex") }, { form: "HEX", text: b.toString("hex").toUpperCase() }, { form: "base58", text: base58Encode(bytes) }];
  for (const k of [0, 1, 2]) { // the secret may start at any offset inside a larger base64 stream
    const part = b.subarray((3 - k) % 3);
    const aligned = part.subarray(0, part.length - (part.length % 3));
    out.push({ form: `base64 @${k}`, text: aligned.toString("base64") }, { form: `base64url @${k}`, text: aligned.toString("base64url") });
  }
  return out;
}
function secretsOf(owner: string, sentence: string, seed: Uint8Array, pub: Uint8Array, kek: Uint8Array): Secret[] {
  const norm = normalizeSentence(sentence);
  const words = [...new Set(norm.split(" "))].filter((w) => w.length >= 5);
  const sk = new Uint8Array([...seed, ...pub]);
  return [
    { owner, what: "ed25519 seed", needles: encodings(seed), raw: Buffer.from(seed) },
    { owner, what: "encryption key", needles: encodings(kek), raw: Buffer.from(kek) },
    { owner, what: "NEAR secret key string", needles: [{ form: "base58(seed‖pub)", text: base58Encode(sk) }], raw: Buffer.from(sk) },
    { owner, what: "sentence", needles: [{ form: "as typed", text: sentence }, { form: "normalized", text: norm }, { form: "url-encoded", text: encodeURIComponent(norm) }, { form: "base64", text: Buffer.from(norm).toString("base64") }, ...words.map((w) => ({ form: `word “${w}”`, text: w }))] },
  ];
}
function leaks(hays: Hay[], secrets: Secret[]): string[] {
  const out: string[] = [];
  for (const h of hays) for (const s of secrets) {
    for (const n of s.needles) if (n.text && h.text.toLowerCase().includes(n.text.toLowerCase())) out.push(`${h.name} ← ${s.owner}'s ${s.what} (${n.form})`);
    if (s.raw && h.buf && h.buf.includes(s.raw)) out.push(`${h.name} ← ${s.owner}'s ${s.what} (raw bytes)`);
  }
  return out;
}

{
  // The finder itself must be able to find things: plant every secret in every form and demand it is seen.
  const seed = crypto.getRandomValues(new Uint8Array(32)), pub = crypto.getRandomValues(new Uint8Array(32)), kek = crypto.getRandomValues(new Uint8Array(32));
  const sec = secretsOf("control", "violet rivers hum quietly tonight", seed, pub, kek);
  const planted = sec.flatMap((s) => s.needles.map((n) => `x=${n.text}&`)).join("");
  const found = new Set(leaks([{ name: "planted", text: planted }], sec).map((l) => l.replace(/^planted ← /, "")));
  const expected = sec.flatMap((s) => s.needles.map((n) => `${s.owner}'s ${s.what} (${n.form})`));
  const inBase64Stream = Buffer.concat([Buffer.from([1, 2, 3, 4, 5]), Buffer.from(seed), Buffer.from([9])]).toString("base64"); // seed at offset 5
  const embedded = leaks([{ name: "stream", text: inBase64Stream }], sec).some((l) => /seed \(base64/.test(l));
  const clean = leaks([{ name: "noise", text: Buffer.from(crypto.getRandomValues(new Uint8Array(4000))).toString("base64") }], sec);
  check("control: the secret finder detects every secret in every encoding (including a base64 stream at an odd offset) and nothing in random noise", expected.every((e) => found.has(e)) && embedded && clean.length === 0, `missing: ${expected.filter((e) => !found.has(e)).join("; ")}; embedded=${embedded}; false positives=${clean.length}`);
}

const SENT_SAM = "velvet harbour whispers beneath copper moons";
const SENT_TINA = "granite orchards hum quietly through winter fog";
const reqs: { who: string; method: string; url: string; headers: Record<string, string>; body: Buffer | null }[] = [];
const urls: { who: string; url: string }[] = [];
const watchWire = (ctx: any, pg: any, who: string) => {
  ctx.on("request", (r: any) => reqs.push({ who, method: r.method(), url: r.url(), headers: r.headers(), body: r.postDataBuffer() }));
  pg.on("framenavigated", (f: any) => { if (f === pg.mainFrame()) urls.push({ who, url: f.url() }); });
};

const ctxSam = await newCtx(), ctxTina = await newCtx();
const sam = await ctxSam.newPage(), tina = await ctxTina.newPage();
watch(sam, "sam"); watch(tina, "tina");
watchWire(ctxSam, sam, "sam"); watchWire(ctxTina, tina, "tina");
await createWallet(sam, SENT_SAM, "sam");
await sam.waitForSelector(".home");
await createWallet(tina, SENT_TINA, "tina");
await tina.waitForSelector(".home");
await sam.getByRole("button", { name: "Receive", exact: true }).click();
await sam.getByRole("tab", { name: "Request amount" }).click();
await sam.fill('input[aria-label="Amount in NEAR"]', "0.5");
await sam.fill('input[aria-label="Note"]', "for the secrets test");
await sam.getByRole("button", { name: "Create request" }).click();
await sam.waitForSelector(".qrcard svg");
const samQr = `${OUT}/sam-request-qr.png`;
await sam.locator(".qrcard").screenshot({ path: samQr });
await scanUpload(tina, samQr);
await tina.waitForSelector("text=Paying", { timeout: 15000 });
await tina.waitForFunction(() => { const b = [...document.querySelectorAll("button")].find((x) => x.textContent?.trim() === "Review"); return !!b && !(b as HTMLButtonElement).disabled; }, null, { timeout: 8000 });
await tina.getByRole("button", { name: "Review" }).click();
await tina.getByRole("button", { name: "Authorize payment" }).click();
await tina.waitForSelector("text=Payment sent", { timeout: 30000 });
await tina.getByRole("button", { name: "Done" }).click();
await tina.waitForSelector(".home");
// Sam sees it, backs up, locks, unlocks, and restores on a "new device"
await sam.getByRole("button", { name: "Back", exact: true }).click();
await sam.waitForSelector(".home");
await S.waitText(sam, "Sam sees Tina's payment arrive on its own (Home polls; index hint, verified on chain)", "Received", 45000);
await sam.getByRole("button", { name: "Settings" }).click();
const [dl] = await Promise.all([sam.waitForEvent("download"), sam.getByRole("button", { name: "Download encrypted backup" }).click()]);
const backupPath = `${OUT}/sam-secrets.neat`;
await dl.saveAs(backupPath);
await sam.getByRole("button", { name: "Lock now" }).click();
await unlock(sam, SENT_SAM);
const ctxSam2 = await newCtx();
const sam2 = await ctxSam2.newPage();
watch(sam2, "sam-restored"); watchWire(ctxSam2, sam2, "sam-restored");
await sam2.goto(ORIGIN + "/");
await sam2.getByRole("button", { name: "Restore from a backup file" }).click();
await sam2.setInputFiles("#bk", backupPath);
await sam2.waitForSelector("text=Backup found");
await sam2.fill('input[aria-label="Your sentence"]', SENT_SAM);
await sam2.getByRole("button", { name: "Restore wallet" }).click();
await sam2.waitForSelector(".home", { timeout: 20000 });
await sam2.getByRole("button", { name: "Receive", exact: true }).click();
await sam2.waitForSelector(".qrcard svg");

// what each wallet's secrets are (computed independently of the page, in Node)
const people = [
  { who: "sam", sentence: SENT_SAM, page: sam }, { who: "tina", sentence: SENT_TINA, page: tina },
];
const secrets: Secret[] = [];
const vaults: Record<string, any> = {};
for (const p of people) {
  const v = (await state(p.page)).vault;
  vaults[p.who] = v;
  const seed = await openVault(v, p.sentence);
  const kek = pbkdf2Sync(Buffer.from(normalizeSentence(p.sentence)), Buffer.from(fromBase64(v.salt)), v.iter, 32, "sha256");
  secrets.push(...secretsOf(p.who, p.sentence, seed, keyFromString(v.publicKey), new Uint8Array(kek)));
}

// everything that left the browser
const wire: Hay[] = reqs.map((r) => ({ name: `${r.who} → ${r.method} ${new URL(r.url).pathname}`, text: `${r.url}\n${JSON.stringify(r.headers)}\n${r.body?.toString("latin1") ?? ""}`, buf: r.body ?? undefined }));
check(`the wire capture is real: ${reqs.length} requests incl. RPC, registration and index calls`, reqs.length > 40 && reqs.some((r) => r.url.endsWith("/api/register")) && reqs.some((r) => r.url.endsWith("/rpc")) && reqs.some((r) => /\/index\/v1\/account\//.test(r.url)));
const onWire = leaks(wire, secrets);
check("NOTHING sent over the network contains any wallet's sentence, key or encryption key, in any encoding", onWire.length === 0, onWire.slice(0, 4).join(" ; "));
// Referer: the page's policy is no-referrer. Everything in this run is same-origin, so the policy is observed directly:
// a default request from the page omits Referer entirely, while a control request that explicitly asks for the
// "origin" policy does carry it (proving the echo endpoint would have shown a Referer if the page sent one).
// Cookies and credentials are never sent, and any Referer that DID appear (the service worker's own precache
// fetches) is only the app's root or its worker script, never a path with data.
const sentCreds = reqs.filter((r) => "cookie" in r.headers || "authorization" in r.headers);
const oddReferers = reqs.filter((r) => r.headers.referer && !(r.headers.referer === ORIGIN + "/" || r.headers.referer === ORIGIN + "/sw.js"));
const echo = await sam.evaluate(async () => {
  const dflt = await (await fetch("/__test/echo")).json();
  const forced = await (await fetch("/__test/echo", { referrerPolicy: "origin" })).json();
  return { dflt: dflt.headers.referer ?? null, forced: forced.headers.referer ?? null };
});
check("no cookie or credential header is ever sent, and no Referer reveals anything beyond the app's own origin", sentCreds.length === 0 && oddReferers.length === 0, [...sentCreds, ...oddReferers].slice(0, 4).map((r) => `${r.method} ${new URL(r.url).pathname} ${r.headers.referer ?? ""}`).join(" ; "));
check("the page's referrer policy is no-referrer: a default request omits Referer, a control request asking for 'origin' sends it", echo.dflt === null && echo.forced === ORIGIN + "/", JSON.stringify(echo));
const regs = reqs.filter((r) => r.url.endsWith("/api/register"));
const regOk = regs.length >= 2 && regs.every((r) => { try { const j = JSON.parse(r.body!.toString()); return r.method === "POST" && Object.keys(j).sort().join() === "label,publicKey" && Object.values(vaults).some((v: any) => v.publicKey === j.publicKey); } catch { return false; } });
check("the registration service receives only {label, publicKey}, and the key is the wallet's PUBLIC key", regOk, regs.map((r) => r.body?.toString().slice(0, 120)).join(" | "));
check("the sentence is never in a URL, and the address bar never leaves '/' (no payment, name or amount in history)", urls.every((u) => u.url === ORIGIN + "/"), [...new Set(urls.map((u) => u.url))].join(", "));

// everything at rest
const rest: Hay[] = [];
for (const [who, pg, ctx] of [["sam", sam, ctxSam], ["tina", tina, ctxTina], ["sam-restored", sam2, ctxSam2]] as const) {
  const dump = await pg.evaluate(async () => {
    const ls = Object.entries(localStorage).map(([k, v]) => k + "=" + v).join("\n");
    const ss = Object.entries(sessionStorage).map(([k, v]) => k + "=" + v).join("\n");
    const idb = indexedDB.databases ? (await indexedDB.databases()).map((d) => d.name).join(",") : "";
    const cache: string[] = [];
    for (const k of await caches.keys()) { cache.push(k); for (const r of await (await caches.open(k)).keys()) cache.push(r.url); }
    return { ls, ss, idb, cache: cache.join("\n"), title: document.title, scripts: [...document.scripts].map((s) => s.textContent ?? "").join("\n") };
  });
  rest.push({ name: `${who} localStorage`, text: dump.ls }, { name: `${who} sessionStorage`, text: dump.ss }, { name: `${who} IndexedDB names`, text: dump.idb }, { name: `${who} Cache Storage`, text: dump.cache }, { name: `${who} document title`, text: dump.title }, { name: `${who} inline scripts`, text: dump.scripts }, { name: `${who} cookies`, text: JSON.stringify(await ctx.cookies()) });
}
rest.push({ name: "encrypted backup file", text: readFileSync(backupPath, "utf8") });
rest.push({ name: "console output", text: logs.map((l) => l.text).join("\n") });
const atRest = leaks(rest, secrets);
check("nothing stored on the device (storage, caches, cookies, title) or in the backup file contains a sentence, key or encryption key in the clear", atRest.length === 0, atRest.slice(0, 4).join(" ; "));
check("the app wrote nothing to the console (no log, info, debug or warning from the app)", logs.filter((l) => ["log", "info", "debug", "trace", "warning"].includes(l.type)).length === 0, logs.slice(0, 3).map((l) => `${l.type}: ${l.text.slice(0, 80)}`).join(" | "));
const cacheUrls = (rest.find((r) => r.name === "sam Cache Storage")?.text ?? "").split("\n");
check("Cache Storage holds only the application shell: no RPC, registration or index response was ever cached", cacheUrls.length > 5 && cacheUrls.every((u) => !/\/rpc|\/api\/|\/index\/v1/.test(u)), cacheUrls.filter((u) => /\/rpc|\/api\/|\/index\/v1/.test(u)).join(","));

// structure of what IS stored
{
  const st = await state(sam);
  const v = st.vault;
  const bk = JSON.parse(readFileSync(backupPath, "utf8"));
  check("vault = AES-256-GCM sealed 32-byte seed (48 bytes with tag), 12-byte IV, 16-byte salt, 600k PBKDF2 iterations, PUBLIC key + name only", fromBase64(v.ct).length === 48 && fromBase64(v.iv).length === 12 && fromBase64(v.salt).length === 16 && v.iter === 600000 && v.kdf === "PBKDF2-SHA256" && Object.keys(v).sort().join() === "accountId,ct,iter,iv,kdf,publicKey,salt,v", Object.keys(v).join());
  check("two wallets never share a salt, IV or ciphertext", new Set([vaults.sam.salt, vaults.tina.salt]).size === 2 && new Set([vaults.sam.iv, vaults.tina.iv]).size === 2 && vaults.sam.ct !== vaults.tina.ct);
  check("the backup file holds only the sealed vault (no history, requests, balances or session data)", Object.keys(bk).sort().join() === "app,format,network,vault" && JSON.stringify(bk.vault) === JSON.stringify(v) && !/txs|requests|balance|lastNonce/.test(JSON.stringify(bk)));
  check("the stored app state has no field that could hold a key, sentence or seed", !/seed|secret|private|sentence|passphrase/i.test(JSON.stringify(Object.keys(st)) + JSON.stringify(Object.keys(v))));
  // QR payloads: public information only
  const req = st.requests.find((r: any) => r.kind === "amount");
  const qrBytes = Buffer.from(fromBase64Url(encodeRequest(req.request).slice(6)));
  const pkBytes = Buffer.from(keyFromString(v.publicKey));
  const qrSecrets = secrets.filter((s) => s.owner === "sam");
  check("the QR payload contains the PUBLIC key and none of the secrets", qrBytes.includes(pkBytes) && leaks([{ name: "QR payload", text: encodeRequest(req.request), buf: qrBytes }], qrSecrets).length === 0);
}

// the new device really restored the same wallet, with the name the chain confirmed
check("the restored copy works: same key, name re-verified on chain, balance shown", (await state(sam2)).vault.publicKey === vaults.sam.publicKey && /sam\.testnet/.test(await sam2.innerText("main")));

console.log(`\nnotes recorded for the report:\n${NOTES.map((n) => " - " + n).join("\n")}`);
await finish();
