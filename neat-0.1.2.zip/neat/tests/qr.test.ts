// QR encoder + decoder tests. The encoder is checked against the QR specification's capacity tables and (when
// available) against OpenCV in BOTH directions; the decoder is checked on synthetic "camera" conditions.
import test from "node:test";
import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { existsSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { drawFunctionPatterns, ECC_PER_BLOCK, encodeQr, MAX_VERSION, NUM_BLOCKS, type Ecl, type QrMatrix } from "../src/core/qr";
import { decodeQr, type RGBA } from "../src/core/qrdecode";
import { createRequest, parseRequest } from "../src/core/payload";
import { generateKeypair, signerFromSeed } from "../src/core/near";

// ---------- helpers ----------
function rng(seed: number) {
  return () => {
    seed = (seed + 0x6d2b79f5) | 0;
    let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type RenderOpts = { scale?: number; quiet?: number; rotate?: 0 | 1 | 2 | 3; flipModules?: number; shade?: [number, number]; pixelNoise?: number; seed?: number };

/** Draw a matrix as an RGBA bitmap, optionally rotated, with module damage, uneven lighting and sensor noise. */
function render(q: QrMatrix, o: RenderOpts = {}): RGBA {
  const scale = o.scale ?? 6, quiet = o.quiet ?? 4, n = q.size + 2 * quiet;
  const rand = rng(o.seed ?? 1);
  const dark: boolean[][] = Array.from({ length: n }, (_, y) => Array.from({ length: n }, (_, x) => q.get(x - quiet, y - quiet)));
  if (o.flipModules) for (let y = quiet; y < n - quiet; y++) for (let x = quiet; x < n - quiet; x++) if (rand() < o.flipModules) dark[y][x] = !dark[y][x];
  let grid = dark;
  for (let r = 0; r < (o.rotate ?? 0); r++) grid = grid.map((_, y) => grid.map((_, x) => grid[n - 1 - x][y]));
  const W = n * scale, data = new Uint8ClampedArray(W * W * 4);
  const [lo, hi] = o.shade ?? [1, 1];
  for (let y = 0; y < W; y++) {
    for (let x = 0; x < W; x++) {
      const v0 = grid[Math.floor(y / scale)][Math.floor(x / scale)] ? 20 : 235;
      const light = lo + (hi - lo) * (x / W);
      const v = Math.max(0, Math.min(255, v0 * light + (o.pixelNoise ? (rand() - 0.5) * 2 * o.pixelNoise : 0)));
      const i = (y * W + x) * 4;
      data[i] = data[i + 1] = data[i + 2] = v;
      data[i + 3] = 255;
    }
  }
  return { data, width: W, height: W };
}

const ALPHA = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_.~";
const textOf = (n: number, salt = 0) => Array.from({ length: n }, (_, i) => ALPHA[(i * 7 + n + salt) % ALPHA.length]).join("");

// Byte-mode data capacity (bytes) per version 1..20, from the QR specification (ISO/IEC 18004).
const CAPACITY: Record<Ecl, number[]> = {
  L: [17, 32, 53, 78, 106, 134, 154, 192, 230, 271, 321, 367, 425, 458, 520, 586, 644, 718, 792, 858],
  M: [14, 26, 42, 62, 84, 106, 122, 152, 180, 213, 251, 287, 331, 362, 412, 450, 504, 560, 624, 666],
};

// ---------- encoder ----------
test("encoder: version selection matches the QR specification's capacity table for versions 1-20, both levels", () => {
  for (const ecl of ["L", "M"] as const) {
    CAPACITY[ecl].forEach((cap, i) => {
      const v = i + 1;
      const fits = encodeQr(textOf(cap), ecl);
      assert.equal(fits.version, v, `${ecl} ${cap} bytes should be version ${v}`);
      assert.equal(fits.ecl, ecl);
      assert.equal(fits.size, 17 + 4 * v);
      if (i + 1 < CAPACITY[ecl].length) {
        const over = encodeQr(textOf(cap + 1), ecl);
        assert.equal(over.version, v + 1, `${ecl} ${cap + 1} bytes should spill into version ${v + 1}`);
      }
    });
  }
  assert.equal(MAX_VERSION, 20);
  assert.throws(() => encodeQr(textOf(CAPACITY.L[19] + 1), "L"));
});

test("encoder: asks for M but drops to L only when M can't hold the payload", () => {
  assert.equal(encodeQr(textOf(CAPACITY.M[19]), "M").ecl, "M");
  const q = encodeQr(textOf(CAPACITY.M[19] + 1), "M"); // 667 bytes: too big for M at version 20, fits L at version 18
  assert.equal(q.ecl, "L");
  assert.equal(q.version, 18);
});

test("encoder: finder patterns, timing patterns and the dark module are where the spec puts them", () => {
  const q = encodeQr("NEAT", "M");
  const n = q.size;
  for (const [cx, cy] of [[0, 0], [n - 7, 0], [0, n - 7]]) {
    for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) {
      const ring = Math.max(Math.abs(x - 3), Math.abs(y - 3));
      assert.equal(q.get(cx + x, cy + y), ring !== 2 && true, `finder at ${cx},${cy} module ${x},${y}`);
    }
  }
  for (let i = 8; i < n - 8; i++) { assert.equal(q.get(i, 6), i % 2 === 0); assert.equal(q.get(6, i), i % 2 === 0); }
  assert.equal(q.get(8, n - 8), true); // the always-dark module
});

// ---------- decoder on synthetic photos ----------
test("decoder: every version 1-20, both levels, several pixel scales", () => {
  for (const ecl of ["L", "M"] as const) {
    CAPACITY[ecl].forEach((cap, i) => {
      for (const len of [Math.max(1, cap - 3), cap]) {
        const text = textOf(len, i);
        const q = encodeQr(text, ecl);
        for (const scale of q.version > 12 ? [4, 6] : [3, 5, 9]) {
          assert.equal(decodeQr(render(q, { scale })), text, `v${q.version} ${ecl} len ${len} scale ${scale}`);
        }
      }
    });
  }
});

test("decoder: rotated, dim, unevenly lit and noisy images", () => {
  const text = textOf(180, 3);
  const q = encodeQr(text, "M");
  for (const rotate of [0, 1, 2, 3] as const) assert.equal(decodeQr(render(q, { rotate, scale: 5 })), text, `rotate ${rotate}`);
  assert.equal(decodeQr(render(q, { shade: [0.45, 1], scale: 5 })), text, "side lighting");
  assert.equal(decodeQr(render(q, { pixelNoise: 40, scale: 5, seed: 7 })), text, "sensor noise");
  assert.equal(decodeQr(render(q, { shade: [0.5, 0.9], pixelNoise: 30, rotate: 1, scale: 4, seed: 3 })), text, "everything at once");
});

/** A copy of `q` with the given data modules inverted (function patterns are left alone). */
function damage(q: QrMatrix, count: number, seed: number): QrMatrix {
  const { isFn } = drawFunctionPatterns(q.version, q.ecl);
  const r = rng(seed), flips = new Set<string>();
  while (flips.size < count) {
    const x = Math.floor(r() * q.size), y = Math.floor(r() * q.size);
    if (!isFn[y][x]) flips.add(`${x},${y}`);
  }
  return { ...q, get: (x, y) => (flips.has(`${x},${y}`) ? !q.get(x, y) : q.get(x, y)) };
}

test("decoder: error correction recovers any damage inside the code's guaranteed budget", () => {
  const text = textOf(120, 5);
  for (const ecl of ["L", "M"] as const) {
    const q = encodeQr(text, ecl);
    // Reed-Solomon corrects ecc/2 wrong codewords per block, and one flipped module damages at most one codeword,
    // so this many flips are recoverable wherever they land.
    const budget = Math.floor(ECC_PER_BLOCK[ecl][q.version] / 2);
    for (let seed = 1; seed <= 10; seed++) assert.equal(decodeQr(render(damage(q, budget, seed), { scale: 6 })), text, `${ecl} v${q.version}: ${budget} flipped modules, seed ${seed}`);
  }
});

test("decoder: damage far beyond the budget is refused, never returned as wrong text", () => {
  const text = textOf(120, 5);
  for (const ecl of ["L", "M"] as const) {
    const q = encodeQr(text, ecl);
    const total = ECC_PER_BLOCK[ecl][q.version] * NUM_BLOCKS[ecl][q.version];
    for (let seed = 1; seed <= 6; seed++) {
      const got = decodeQr(render(damage(q, total * 4, seed), { scale: 6 }));
      assert.ok(got === null || got === text, `${ecl} seed ${seed} returned wrong text: ${got}`);
    }
  }
});

test("decoder: never invents a code from noise, blanks or patterns that merely resemble one", () => {
  const rand = rng(99);
  const blank = (v: number, w = 300) => ({ data: new Uint8ClampedArray(w * w * 4).fill(v), width: w, height: w });
  assert.equal(decodeQr(blank(255)), null);
  assert.equal(decodeQr(blank(0)), null);
  for (let k = 0; k < 40; k++) {
    const w = 200 + Math.floor(rand() * 200), d = new Uint8ClampedArray(w * w * 4);
    for (let i = 0; i < w * w; i++) { const v = rand() < 0.5 ? 0 : 255; d[i * 4] = d[i * 4 + 1] = d[i * 4 + 2] = v; d[i * 4 + 3] = 255; }
    assert.equal(decodeQr({ data: d, width: w, height: w }), null, `noise ${k}`);
  }
  // a code whose data area has been wiped out must fail to decode rather than return garbage
  const q = encodeQr(textOf(100, 2), "M");
  const img = render(q, { scale: 6 });
  const mid = img.width / 2;
  for (let y = mid - 90; y < mid + 90; y++) for (let x = mid - 90; x < mid + 90; x++) { const i = (y * img.width + x) * 4; img.data[i] = img.data[i + 1] = img.data[i + 2] = ((x >> 3) + (y >> 3)) % 2 ? 0 : 255; }
  assert.equal(decodeQr(img), null);
});

test("real NEAT payment requests survive the whole encode → pixels → decode → parse path", async () => {
  const { seed, publicKey } = await generateKeypair();
  const signer = await signerFromSeed(seed, publicKey);
  const accounts = ["bob.testnet", "a-very-long-account-name-for-testing.testnet", "x_y.testnet"];
  for (let i = 0; i < 24; i++) {
    const { request, qrText } = await createRequest(signer, accounts[i % 3], { amountYocto: i % 4 === 0 ? undefined : BigInt(i + 1) * 10n ** 21n, fixed: i % 2 === 0, note: i % 3 === 0 ? "lunch ☕" : undefined, expiresInSec: i % 5 === 0 ? 3600 : undefined });
    const q = encodeQr(qrText, "M");
    const got = decodeQr(render(q, { scale: 5, rotate: (i % 4) as 0 | 1 | 2 | 3, seed: i, pixelNoise: 12 }));
    assert.equal(got, qrText);
    const p = parseRequest(got!);
    assert.ok(p.ok && p.request.id === request.id);
  }
});

// ---------- OpenCV cross-check (skipped when python3 + OpenCV aren't installed) ----------
const py = spawnSync("python3", ["-c", "import cv2, numpy"], { encoding: "utf8" });
const haveCv = py.status === 0;
const script = join(import.meta.dirname ?? ".", "qr_crosscheck.py");

function readPgm(path: string): RGBA {
  const b = readFileSync(path);
  let o = 0;
  const tok = () => { while (b[o] <= 32) o++; let s = ""; while (b[o] > 32) s += String.fromCharCode(b[o++]); return s; };
  tok(); const w = +tok(), h = +tok(); tok(); o++;
  const data = new Uint8ClampedArray(w * h * 4);
  for (let i = 0; i < w * h; i++) { data[i * 4] = data[i * 4 + 1] = data[i * 4 + 2] = b[o + i]; data[i * 4 + 3] = 255; }
  return { data, width: w, height: h };
}

test("OpenCV can read codes made by NEAT's encoder (all versions 1-20, both levels)", { skip: !haveCv && "python3 + OpenCV not installed" }, () => {
  const dir = mkdtempSync(join(tmpdir(), "neat-qr-"));
  const cases: { name: string; text: string }[] = [];
  for (const ecl of ["L", "M"] as const) CAPACITY[ecl].forEach((cap, i) => {
    for (const len of [Math.max(1, cap - 7), cap]) {
      const text = textOf(len, i + 11), q = encodeQr(text, ecl);
      const rows: string[] = [];
      for (let y = -4; y < q.size + 4; y++) { let r = ""; for (let x = -4; x < q.size + 4; x++) r += q.get(x, y) ? "1" : "0"; rows.push(r); }
      const name = `v${q.version}_${ecl}_${len}`;
      writeFileSync(join(dir, name + ".txt"), rows.join("\n"));
      cases.push({ name, text });
    }
  });
  writeFileSync(join(dir, "cases.json"), JSON.stringify(cases));
  const r = spawnSync("python3", [script, "decode", dir], { encoding: "utf8", maxBuffer: 1 << 26 });
  assert.equal(r.status, 0, r.stderr);
  const got: Record<string, string | null> = JSON.parse(r.stdout);
  const bad = cases.filter((c) => got[c.name] !== c.text).map((c) => c.name);
  assert.deepEqual(bad, [], `OpenCV could not read: ${bad.join(", ")}`);
});

test("NEAT's decoder can read codes made by OpenCV's encoder (several versions, both levels)", { skip: !haveCv && "python3 + OpenCV not installed" }, () => {
  const dir = mkdtempSync(join(tmpdir(), "neat-qr-"));
  const texts: { name: string; text: string; ecl: Ecl }[] = [];
  for (const ecl of ["L", "M"] as const) for (const len of [5, 40, 90, 150, 220, 300, 420]) texts.push({ name: `${ecl}_${len}`, text: textOf(len, 21), ecl });
  writeFileSync(join(dir, "texts.json"), JSON.stringify(texts));
  const r = spawnSync("python3", [script, "encode", dir], { encoding: "utf8", maxBuffer: 1 << 26 });
  assert.equal(r.status, 0, r.stderr);
  const made: string[] = JSON.parse(r.stdout);
  assert.ok(made.length >= 10, `OpenCV produced only ${made.length} codes`);
  for (const t of texts.filter((x) => made.includes(x.name))) {
    assert.ok(existsSync(join(dir, t.name + ".pgm")));
    assert.equal(decodeQr(readPgm(join(dir, t.name + ".pgm"))), t.text, t.name);
  }
});
