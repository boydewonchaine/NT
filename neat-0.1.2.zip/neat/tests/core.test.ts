import test from "node:test";
import assert from "node:assert/strict";
import { base58Decode, base58Encode, fromBase64Url, toBase64Url, toHex, utf8 } from "../src/core/encoding";
import { formatFee, formatNear, parseNear } from "../src/core/units";
import { decodeTransaction, encodeTransaction, generateKeypair, hashOfSigned, isValidAccountId, keyFromString, keyToString, signerFromSeed, signTransaction, validateNameLabel, verifySignature } from "../src/core/near";
import { checkSentence, nextDelayMs, open, registerFailure, seal, WrongSentence } from "../src/core/vault";

test("base58 known vector and roundtrip", () => {
  assert.equal(base58Encode(utf8.enc("Hello World!")), "2NEpo7TZRRrLZSi2U");
  assert.deepEqual(base58Decode("2NEpo7TZRRrLZSi2U"), utf8.enc("Hello World!"));
  const b = new Uint8Array([0, 0, 1, 2, 255, 254]);
  assert.deepEqual(base58Decode(base58Encode(b)), b);
  assert.throws(() => base58Decode("0OIl"));
});

test("base64url roundtrip", () => {
  const b = crypto.getRandomValues(new Uint8Array(77));
  assert.deepEqual(fromBase64Url(toBase64Url(b)), b);
  assert.throws(() => fromBase64Url("a+b"));
});

test("units: exact decimal math, no floats", () => {
  assert.equal(parseNear("1"), 10n ** 24n);
  assert.equal(parseNear("0.000001"), 10n ** 18n);
  assert.equal(parseNear("1.5"), 15n * 10n ** 23n);
  assert.equal(parseNear("0.0000001"), null); // > 6 decimals
  assert.equal(parseNear("abc"), null);
  assert.equal(parseNear(""), null);
  assert.equal(parseNear("1e3"), null);
  assert.equal(formatNear(15n * 10n ** 23n), "1.5");
  assert.equal(formatNear(10n ** 24n * 1234n), "1,234");
  assert.equal(formatFee(45n * 10n ** 18n), "0.000045");
  assert.notEqual(formatFee(1n), "0");
});

test("account id + name rules", () => {
  assert.ok(isValidAccountId("dimeji.testnet"));
  assert.ok(!isValidAccountId("Dimeji.testnet"));
  assert.ok(!isValidAccountId("a"));
  assert.ok(!isValidAccountId("a..b"));
  assert.ok(validateNameLabel("dimeji").ok);
  for (const bad of ["ab", "-ab", "ab-", "a--b", "has.dot", "UPPER", "a b", "x".repeat(33), "a".repeat(64).replace(/a/g, "f")]) assert.equal(validateNameLabel(bad).ok, false, bad);
});

test("borsh transfer layout matches hand-assembled bytes", async () => {
  const pk = new Uint8Array(32).fill(0xaa);
  const bh = new Uint8Array(32).fill(0xbb);
  const enc = new TextEncoder();
  const u32 = (n: number) => Uint8Array.from([n & 255, (n >> 8) & 255, 0, 0]);
  const parts = [u32(9), enc.encode("a.testnet"), Uint8Array.of(0), pk, Uint8Array.of(5, 0, 0, 0, 0, 0, 0, 0), u32(9), enc.encode("b.testnet"), bh, u32(1), Uint8Array.of(3), Uint8Array.of(1, ...new Array(15).fill(0))];
  const expected = Buffer.concat(parts.map((p) => Buffer.from(p)));
  const got = encodeTransaction({ signerId: "a.testnet", publicKey: pk, nonce: 5n, receiverId: "b.testnet", blockHash: bh, actions: [{ type: "transfer", deposit: 1n }] });
  assert.equal(toHex(got), expected.toString("hex"));
  const back = decodeTransaction(got);
  assert.equal(back.nonce, 5n);
  assert.deepEqual(back.actions, [{ type: "transfer", deposit: 1n }]);
});

test("function-call + large u128 encode/decode", () => {
  const pk = new Uint8Array(32).fill(1);
  const tx = { signerId: "f.testnet", publicKey: pk, nonce: 2n ** 63n, receiverId: "testnet", blockHash: new Uint8Array(32), actions: [{ type: "functionCall" as const, method: "create_account", args: utf8.enc('{"a":1}'), gas: 100_000_000_000_000n, deposit: 10n ** 24n }] };
  const d = decodeTransaction(encodeTransaction(tx));
  assert.deepEqual(d.actions, tx.actions);
  assert.equal(d.nonce, 2n ** 63n);
  assert.throws(() => encodeTransaction({ ...tx, actions: [{ type: "transfer", deposit: 2n ** 128n }] }));
});

test("sign: signature verifies over sha256(borsh), hash is stable", async () => {
  const { seed, publicKey } = await generateKeypair();
  const signer = await signerFromSeed(seed, publicKey);
  const tx = { signerId: "a.testnet", publicKey, nonce: 1n, receiverId: "b.testnet", blockHash: new Uint8Array(32).fill(3), actions: [{ type: "transfer" as const, deposit: 5n }] };
  const s = await signTransaction(tx, signer);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", s.txBytes));
  assert.ok(await verifySignature(publicKey, digest, s.signature));
  assert.equal(await hashOfSigned(s.bytes), s.hash);
  assert.deepEqual(keyFromString(keyToString(publicKey)), publicKey);
});

test("keys come from the CSPRNG and are independent of any sentence", async () => {
  const a = await generateKeypair(), b = await generateKeypair();
  assert.notDeepEqual(a.seed, b.seed);
  assert.equal(a.seed.length, 32);
});

test("vault: roundtrip, wrong sentence, tamper, no plaintext", async () => {
  const { seed, publicKey } = await generateKeypair();
  const pk = keyToString(publicKey);
  const s = "my blue bicycle rides at dawn";
  const rec = await seal(seed, pk, null, s, 2000);
  assert.deepEqual(await open(rec, s), seed);
  assert.deepEqual(await open(rec, "  my   blue bicycle rides at dawn "), seed); // whitespace-normalised
  await assert.rejects(open(rec, "my blue bicycle rides at dusk"), WrongSentence);
  await assert.rejects(open({ ...rec, publicKey: keyToString(new Uint8Array(32).fill(9)) }, s), WrongSentence); // AAD binds the key
  const flipped = Buffer.from(rec.ct, "base64"); flipped[0] ^= 1;
  await assert.rejects(open({ ...rec, ct: flipped.toString("base64") }, s), WrongSentence);
  const blob = JSON.stringify(rec);
  assert.ok(!blob.includes(Buffer.from(seed).toString("base64")) && !blob.includes(toHex(seed)));
  assert.ok(!blob.includes("bicycle"));
  const rec2 = await seal(seed, pk, null, s, 2000);
  assert.notEqual(rec.salt, rec2.salt); assert.notEqual(rec.ct, rec2.ct); // unique salt + iv
});

test("vault: production KDF cost is used and finishes in a sane time", async () => {
  const { seed, publicKey } = await generateKeypair();
  const t = Date.now();
  const rec = await seal(seed, keyToString(publicKey), null, "four score and seven years ago");
  assert.equal(rec.iter, 600_000);
  await open(rec, "four score and seven years ago");
  const ms = Date.now() - t;
  assert.ok(ms < 8000, `seal+open took ${ms}ms`);
});

test("sentence rules + attempt backoff", () => {
  assert.ok(!checkSentence("short one here").ok);
  assert.ok(!checkSentence("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa").ok);
  assert.ok(!checkSentence("word ".repeat(21)).ok); // 105 chars
  assert.ok(checkSentence("my blue bicycle rides at dawn").ok);
  assert.ok(!checkSentence("a b c d e f g h i j k l m n o p q r s t u v w x y z".repeat(3)).ok); // > 100
  assert.equal(nextDelayMs(2), 0);
  assert.equal(nextDelayMs(3), 5000);
  assert.equal(nextDelayMs(4), 10000);
  assert.equal(nextDelayMs(40), 15 * 60_000);
  let s = { fails: 0, lockedUntil: 0 };
  for (let i = 0; i < 3; i++) s = registerFailure(s, 1000);
  assert.equal(s.lockedUntil, 6000);
});
