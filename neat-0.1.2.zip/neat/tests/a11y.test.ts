// Accessibility checks that don't need a browser: WCAG 2.x contrast of the design tokens, in both themes.
import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { join } from "node:path";

const css = readFileSync(join(import.meta.dirname ?? ".", "../src/ui/styles.css"), "utf8");

type RGB = [number, number, number];
type Tok = { rgb: RGB; a: number };

function parseColor(v: string): Tok {
  v = v.trim();
  let m = /^#([0-9a-f]{6})$/i.exec(v);
  if (m) return { rgb: [0, 2, 4].map((i) => parseInt(m![1].slice(i, i + 2), 16)) as RGB, a: 1 };
  m = /^rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)$/i.exec(v) as RegExpExecArray | null;
  if (!m) throw new Error("unparsed colour: " + v);
  return { rgb: [+m[1], +m[2], +m[3]], a: m[4] === undefined ? 1 : +m[4] };
}

/** All `--name: value;` declarations inside the first block that starts with `selector`. */
function tokens(selector: string): Record<string, Tok> {
  const start = css.indexOf(selector);
  assert.ok(start >= 0, "missing " + selector);
  const body = css.slice(css.indexOf("{", start) + 1, css.indexOf("}", start));
  const out: Record<string, Tok> = {};
  for (const m of body.matchAll(/--([a-z0-9-]+)\s*:\s*([^;]+);/gi)) {
    try { out[m[1]] = parseColor(m[2]); } catch { /* non-colour token (font, radius) */ }
  }
  return out;
}

const lin = (c: number) => { c /= 255; return c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
const lum = ([r, g, b]: RGB) => 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
const over = (fg: Tok, bg: RGB): RGB => fg.rgb.map((c, i) => Math.round(c * fg.a + bg[i] * (1 - fg.a))) as RGB;
const ratio = (a: RGB, b: RGB) => { const [x, y] = [lum(a), lum(b)].sort((p, q) => q - p); return (x + 0.05) / (y + 0.05); };

const light = tokens(":root {");
// dark tokens: the explicit [data-theme="dark"] block and the prefers-color-scheme block must agree
const darkExplicit = { ...light, ...tokens(':root[data-theme="dark"]') };
const darkAuto = { ...light, ...tokens(':root:not([data-theme="light"])') };

for (const [name, t] of [["light", light], ["dark", darkExplicit]] as const) {
  const surfaces = (["paper", "raise", "sunk"] as const).map((k) => [k, t[k].rgb] as const);

  test(`${name}: text tokens meet WCAG AA (4.5:1) on every surface`, () => {
    for (const tok of ["ink", "ink-2", "ink-3", "ok", "bad"]) {
      for (const [sname, bg] of surfaces) {
        const r = ratio(over(t[tok], bg), bg);
        assert.ok(r >= 4.5, `${name} --${tok} on --${sname} is ${r.toFixed(2)}:1`);
      }
    }
  });

  test(`${name}: large-text / decorative token --ink-4 meets 3:1 and control edges meet 3:1`, () => {
    for (const [sname, bg] of surfaces) {
      assert.ok(ratio(over(t["ink-4"], bg), bg) >= 3, `--ink-4 on --${sname}`);
      assert.ok(ratio(over(t["edge"], bg), bg) >= 3, `--edge on --${sname}`);
    }
  });

  test(`${name}: primary button (paper on ink) and the page's focus ring are strongly visible`, () => {
    assert.ok(ratio(t.paper.rgb, t.ink.rgb) >= 7);
    assert.ok(ratio(t.focus.rgb, t.paper.rgb) >= 3);
  });
}

test("the automatic dark theme and the explicit dark theme use identical tokens", () => {
  for (const k of Object.keys(darkExplicit)) assert.deepEqual(darkAuto[k], darkExplicit[k], k);
});

test("the faint --ink-4 tier is only used for large display type", () => {
  const uses = [...css.matchAll(/([^{}]+)\{[^}]*color:\s*var\(--ink-4\)/g)].map((m) => m[1].trim());
  assert.deepEqual(uses, [".display .sfx"]);
});

test("motion: every animation is neutralised under prefers-reduced-motion, and touch targets are at least 44px", () => {
  assert.match(css, /@media \(prefers-reduced-motion: reduce\)[\s\S]*animation-duration: 0\.001ms !important/);
  assert.match(css, /\.btn \{[^}]*min-height: 56px/);
  assert.match(css, /\.iconbtn \{[^}]*width: 44px; height: 44px/);
  assert.match(css, /\.btn\.ghost \{[^}]*min-height: 44px/);
});

test("interactive states (:hover, :active, :focus) only ever paint a background the contrast tests cover", () => {
  // text colour tiers are verified on --paper, --raise and --sunk (and primary buttons on --ink), so a state that
  // paints anything else (a translucent tint, say) would silently void those guarantees
  const covered = /^(var\(--(paper|raise|sunk|ink)\)|transparent|none|inherit|currentColor)$/i;
  const bad: string[] = [];
  for (const m of css.matchAll(/([^{}]+?):(hover|active|focus|focus-visible)\b([^{}]*)\{([^}]*)\}/g)) {
    for (const d of m[4].matchAll(/(?:^|;)\s*background(?:-color)?\s*:\s*([^;]+)/g)) {
      if (!covered.test(d[1].trim())) bad.push(`${m[1].trim()}:${m[2]}${m[3]} { background: ${d[1].trim()} }`);
    }
  }
  assert.deepEqual(bad, []);
});
