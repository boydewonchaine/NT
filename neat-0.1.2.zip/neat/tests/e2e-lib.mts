// Shared plumbing for the end-to-end suites: real Chromium + the production bundle + a mock NEAR chain
// (tests/e2e-server.ts). Each suite starts its own server on PORT, so they must run one after another.
import { createRequire } from "node:module";
import { mkdirSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { startServer } from "./e2e-server";
import { encodeQr, qrToSvg } from "../src/core/qr";

const require = createRequire(import.meta.url);
export const { chromium } = require(process.env.PLAYWRIGHT_PATH ?? "playwright");

export const PORT = 4173; // the e2e bundle is built with its RPC/index URLs pointing here
export const ORIGIN = `http://127.0.0.1:${PORT}`;
export const OUT = process.env.E2E_OUT ?? join(tmpdir(), "neat-e2e");
export const SENT_A = "the quick orange fox jumps over lakes";
export const SENT_B = "my blue bicycle rides at dawn today";
export const SENT_C = "seven green lanterns glow above rivers";
export const VIEW = { width: 390, height: 844 };
export const NEAR = 10n ** 24n;

export type Page = any;

/**
 * tsx compiles with "keepNames", which wraps named inner functions in a `__name(...)` helper that doesn't exist inside
 * the browser when a callback is serialised into `page.evaluate`. Defining it makes every evaluated callback work.
 */
export async function prep(ctx: any) {
  await ctx.addInitScript("globalThis.__name = globalThis.__name || ((f) => f);");
  return ctx;
}
export type Suite = Awaited<ReturnType<typeof openSuite>>;

export async function openSuite(name: string, opts: { funded?: boolean; launch?: Record<string, unknown> } = {}) {
  mkdirSync(`${OUT}/shots`, { recursive: true });
  const results: { name: string; ok: boolean; detail?: string }[] = [];
  const check = (n: string, ok: boolean, detail = "") => {
    results.push({ name: n, ok, detail });
    console.log(`${ok ? "PASS" : "FAIL"}  ${n}${ok || !detail ? "" : "  → " + detail}`);
    return ok;
  };
  const { chain, stats, close } = await startServer(process.env.E2E_DIST ?? "dist-test", PORT, { funded: opts.funded });
  const post = (path: string, body: any = {}) => fetch(`${ORIGIN}/__test/${path}`, { method: "POST", body: JSON.stringify(body) }).then((r) => r.json());
  const browser = await chromium.launch(opts.launch ?? {});
  const newCtx = async (o: any = {}) => prep(await browser.newContext({ viewport: VIEW, deviceScaleFactor: 2, acceptDownloads: true, ...o }));

  // Console noise: anything the app itself reports as an error fails the run. Browser-level "Failed to load resource"
  // lines for HTTP error statuses are expected in tests that provoke those statuses on purpose, so a suite can allow them.
  const errors: string[] = [];
  const logs: { who: string; type: string; text: string }[] = [];
  const allowed: RegExp[] = [];
  const allowConsole = (re: RegExp) => void allowed.push(re);
  const watch = (page: Page, who: string) => {
    page.on("pageerror", (e: Error) => errors.push(`${who} pageerror: ${e.message}`));
    page.on("console", (m: any) => {
      logs.push({ who, type: m.type(), text: m.text() });
      if (m.type() === "error" && !allowed.some((re) => re.test(m.text()))) errors.push(`${who} console: ${m.text()}`);
    });
  };

  const waitText = async (page: Page, n: string, needle: string, timeout = 15000) => {
    try {
      await page.waitForFunction((t: string) => document.body.innerText.toLowerCase().includes(t.toLowerCase()), needle, { timeout });
      check(n, true);
      return true;
    } catch {
      check(n, false, `never saw "${needle}"; page says: ${(await page.innerText("main").catch(() => "")).replace(/\n+/g, " | ").slice(0, 260)}`);
      return false;
    }
  };
  /** Let finite animations (fades, shakes) finish so screenshots are not caught mid-transition. */
  const settle = (page: Page) =>
    page
      .evaluate(async () => {
        const done = document.getAnimations().filter((a: any) => Number.isFinite(a.effect?.getComputedTiming?.().endTime)).map((a: any) => a.finished.catch(() => {}));
        await Promise.race([Promise.all(done), new Promise((r) => setTimeout(r, 1500))]);
      })
      .catch(() => {});
  const shot = async (page: Page, n: string) => {
    await settle(page);
    await page.screenshot({ path: `${OUT}/shots/${name}-${n}.png` });
  };
  const text = (page: Page, sel: string) => page.locator(sel).first().innerText();
  const state = async (page: Page) => JSON.parse(await page.evaluate(() => localStorage.getItem("neat.state.v1") ?? "{}"));
  const bal = (id: string): bigint => chain.accounts.get(id)!.amount;

  const finish = async () => {
    check("no uncaught page errors or unexpected console errors", errors.length === 0, errors.slice(0, 5).join(" || "));
    const failed = results.filter((r) => !r.ok);
    console.log(`\n[${name}] ${results.length - failed.length}/${results.length} checks passed`);
    writeFileSync(`${OUT}/${name}-results.json`, JSON.stringify(results, null, 1));
    await browser.close();
    await close();
    process.exit(failed.length ? 1 : 0);
  };

  return { name, chain, stats, post, browser, newCtx, watch, errors, logs, allowConsole, check, waitText, settle, shot, text, state, bal, finish };
}

// ---------------------------------------------------------------------------------------------
// Wallet + identity helpers (they drive the real UI)

/** First run: create the encrypted wallet and wait for the "choose your name" screen. */
export async function startWallet(page: Page, sentence: string) {
  await page.goto(ORIGIN + "/");
  await page.waitForSelector('input[aria-label="Personal sentence"]', { timeout: 10000 });
  await page.fill('input[aria-label="Personal sentence"]', sentence);
  await page.fill('input[aria-label="Repeat your sentence"]', sentence);
  await page.getByRole("button", { name: "Create wallet" }).click();
  await page.waitForSelector('input[aria-label="Choose your NEAT name"]', { timeout: 20000 });
}

/** Type a name and wait until the live lookup says it is available. */
export async function typeName(page: Page, label: string) {
  await page.fill('input[aria-label="Choose your NEAT name"]', label);
  await page.waitForFunction((n: string) => document.body.innerText.includes(`${n}.testnet is available`), label, { timeout: 8000 });
}

/** Continue → explicit confirmation sheet → Register name. */
export async function confirmRegistration(page: Page, label: string) {
  await page.getByRole("button", { name: "Continue" }).click();
  await page.waitForSelector(`text=Register ${label}.testnet?`);
  await page.getByRole("button", { name: "Register name" }).click();
}

export async function createWallet(page: Page, sentence: string, label: string) {
  await startWallet(page, sentence);
  await typeName(page, label);
  await confirmRegistration(page, label);
  await page.waitForSelector(".home", { timeout: 30000 });
}

export async function unlock(page: Page, sentence: string) {
  await page.waitForSelector('input[aria-label="Your personal sentence"]', { timeout: 15000 });
  await page.fill('input[aria-label="Your personal sentence"]', sentence);
  await page.getByRole("button", { name: "Unlock" }).click();
  await page.waitForSelector(".home", { timeout: 20000 });
}

// ---------------------------------------------------------------------------------------------
// QR helpers

/** Render a QR for `qrText` to a PNG file (a screenshot of NEAT's own SVG rendering, at an integer module scale). */
export async function qrImage(browser: any, qrText: string, file: string) {
  const ctx = await prep(await browser.newContext({ viewport: { width: 760, height: 760 }, deviceScaleFactor: 1 }));
  const page = await ctx.newPage();
  const svg = qrToSvg(encodeQr(qrText, "M"), { quiet: 3, fg: "#000", bg: "#fff" });
  const n = Number(/viewBox="0 0 (\d+) /.exec(svg)![1]);
  const px = n * Math.max(3, Math.floor(600 / n));
  await page.setContent(`<body style="margin:0;background:#fff"><div id="q" style="width:${px}px;height:${px}px">${svg.replace("<svg ", `<svg width="${px}" height="${px}" `)}</div></body>`);
  await page.locator("#q").screenshot({ path: file });
  await ctx.close();
}

/** Home → Send → upload a QR image → wait for the Amount screen. */
export async function scanUpload(page: Page, file: string) {
  await page.getByRole("button", { name: "Send" }).click();
  await page.waitForSelector("text=Scan to pay");
  await page.setInputFiles("#qrfile", file);
}

/** From Home: scan `file`, type `amount`, press Review, and wait for the Authorize button. */
export async function toReview(page: Page, file: string, amount: string) {
  await scanUpload(page, file);
  await page.waitForSelector("text=Paying", { timeout: 15000 });
  await page.fill('input[aria-label="Amount in NEAR"]', amount);
  await page.waitForFunction(() => { const b = [...document.querySelectorAll("button")].find((x) => x.textContent?.trim() === "Review"); return !!b && !(b as HTMLButtonElement).disabled; }, null, { timeout: 8000 });
  await page.getByRole("button", { name: "Review" }).click();
  await page.getByRole("button", { name: "Authorize payment" }).waitFor({ timeout: 10000 });
}
