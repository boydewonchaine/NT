// TEST-ONLY in-memory NEAR testnet stand-in. It decodes and signature-checks real Borsh transactions,
// so it proves our encoding/signing is self-consistent. It does NOT prove compatibility with the real
// network: that still needs a run against live testnet (see README).

import { webcrypto } from "node:crypto";
import { base58Encode, fromBase64, toHex } from "../src/core/encoding";
import { decodeTransaction, keyToString, sha256 } from "../src/core/near";

const GAS_PRICE = 100_000_000n; // fixture
const FIX = { send_sir: 100_000_000_000, send_not_sir: 110_000_000_000, execution: 120_000_000_000 };

type Key = { nonce: bigint; full: boolean };
type Account = { amount: bigint; storage: number; keys: Map<string, Key> };
type TxRow = { hash: string; signer: string; receiver: string; bytes: Uint8Array; queries: number; mode: "ok" | "fail"; burnt: bigint; blockHash: string; failure?: any; amount: bigint; ts: number; kind: "transfer" | "call"; pk: string; nonce: bigint; actions: any[] };

export class MockChain {
  accounts = new Map<string, Account>();
  txs = new Map<string, TxRow>();
  height = 1000;
  blockHash = base58Encode(new Uint8Array(32).fill(7));
  /** number of `tx` queries that return "not final yet" before FINAL */
  finalizeAfter = 0;
  /** next N broadcasts are acknowledged but silently dropped (simulates a lost submission) */
  dropNext = 0;
  /** make the next N RPC calls fail at the network layer */
  failNext = 0;
  /** registrations are accepted by the node but fail when executed (e.g. the registrar contract panics) */
  failRegistrations = false;
  broadcasts = 0;
  log: string[] = [];

  addAccount(id: string, amountNear: bigint, pk?: Uint8Array) {
    const a: Account = { amount: amountNear * 10n ** 24n, storage: 182, keys: new Map() };
    if (pk) a.keys.set(keyToString(pk), { nonce: 1n, full: true });
    this.accounts.set(id, a);
    return a;
  }

  fetchImpl = async (_url: any, init: any): Promise<Response> => {
    if (this.failNext > 0) {
      this.failNext--;
      throw new TypeError("network down");
    }
    const { method, params, id } = JSON.parse(init.body);
    const out = await this.handle(method, params);
    return new Response(JSON.stringify({ jsonrpc: "2.0", id, ...out }), { status: 200, headers: { "content-type": "application/json" } });
  };

  private err(name: string, extra: any = {}) {
    return { error: { name: "HANDLER_ERROR", code: -32000, message: "Server error", cause: { name, info: extra } } };
  }

  async handle(method: string, params: any): Promise<{ result: any } | { error: any }> {
    switch (method) {
      case "query": {
        const a = this.accounts.get(params.account_id);
        if (!a) return this.err("UNKNOWN_ACCOUNT");
        if (params.request_type === "view_account") return { result: { amount: a.amount.toString(), locked: "0", code_hash: "11111111111111111111111111111111", storage_usage: a.storage, block_height: this.height } };
        if (params.request_type === "view_access_key") {
          const k = a.keys.get(params.public_key);
          if (!k) return this.err("UNKNOWN_ACCESS_KEY");
          return { result: { nonce: Number(k.nonce), permission: k.full ? "FullAccess" : { FunctionCall: {} }, block_height: this.height } };
        }
        return this.err("UNSUPPORTED");
      }
      case "gas_price":
        return { result: { gas_price: GAS_PRICE.toString() } };
      case "block":
        return { result: { header: { hash: this.blockHash, height: this.height, timestamp: (BigInt(Date.now()) * 1_000_000n).toString() } } };
      case "EXPERIMENTAL_protocol_config":
        return {
          result: {
            runtime_config: {
              storage_amount_per_byte: "10000000000000000000",
              transaction_costs: {
                action_receipt_creation_config: FIX,
                action_creation_config: { transfer_cost: FIX, create_account_cost: FIX, add_key_cost: { full_access_cost: FIX } },
                burnt_gas_reward: [3, 10],
                pessimistic_gas_price_inflation_ratio: [103, 100],
              },
            },
          },
        };
      case "status":
        return { result: { chain_id: "testnet", sync_info: { latest_block_height: this.height, latest_block_time: new Date().toISOString(), syncing: false } } };
      case "send_tx":
      case "broadcast_tx_async": {
        const b64 = method === "send_tx" ? params.signed_tx_base64 : params[0];
        try {
          return await this.submit(fromBase64(b64));
        } catch {
          // what a node answers to bytes it cannot decode
          return { error: { name: "REQUEST_VALIDATION_ERROR", code: -32602, message: "Invalid params", cause: { name: "PARSE_ERROR", info: { error_message: "Failed to decode transaction" } }, data: "Failed to decode transaction" } };
        }
      }
      case "tx": {
        const row = this.txs.get(params.tx_hash);
        if (!row) return this.err("UNKNOWN_TRANSACTION");
        row.queries++;
        const final = row.queries > this.finalizeAfter;
        const status = row.mode === "ok" ? { SuccessValue: "" } : { Failure: row.failure };
        return {
          result: {
            final_execution_status: final ? "FINAL" : "EXECUTED_OPTIMISTIC",
            status,
            transaction: { signer_id: row.signer, public_key: row.pk, nonce: Number(row.nonce), receiver_id: row.receiver, actions: row.actions, signature: "ed25519:mock", hash: row.hash },
            transaction_outcome: { block_hash: row.blockHash, outcome: { tokens_burnt: (row.burnt / 2n).toString(), status: { SuccessReceiptId: "x" } } },
            receipts_outcome: [{ outcome: { tokens_burnt: (row.burnt - row.burnt / 2n).toString(), status: row.mode === "ok" ? { SuccessValue: "" } : { Failure: row.failure } } }],
          },
        };
      }
      default:
        return { error: { code: -32601, message: "Method not found", name: "METHOD_NOT_FOUND", cause: { name: "METHOD_NOT_FOUND" } } };
    }
  }

  private async submit(bytes: Uint8Array): Promise<{ result: any } | { error: any }> {
    this.broadcasts++;
    const tx = decodeTransaction(bytes);
    const txBytes = bytes.slice(0, tx._len);
    const sig = bytes.slice(tx._len + 1);
    if (bytes[tx._len] !== 0 || sig.length !== 64) return this.err("INVALID_TRANSACTION", { InvalidTxError: "InvalidSignature" });
    const digest = await sha256(txBytes);
    const key = await webcrypto.subtle.importKey("raw", tx.publicKey, { name: "Ed25519" }, false, ["verify"]);
    if (!(await webcrypto.subtle.verify({ name: "Ed25519" }, key, sig, digest))) return this.err("INVALID_TRANSACTION", { InvalidTxError: "InvalidSignature" });
    const hash = base58Encode(digest);
    if (this.txs.has(hash)) return { result: {} }; // idempotent: same hash executes once
    const signer = this.accounts.get(tx.signerId);
    const k = signer?.keys.get(keyToString(tx.publicKey));
    if (!signer || !k) return this.err("INVALID_TRANSACTION", { InvalidTxError: "SignerDoesNotExist" });
    if (tx.nonce <= k.nonce) return this.err("INVALID_TRANSACTION", { InvalidTxError: { InvalidNonce: {} } });
    let gas = 2n * (BigInt(FIX.send_not_sir) + BigInt(FIX.execution));
    let deposit = 0n;
    for (const a of tx.actions) {
      if (a.type === "transfer") deposit += a.deposit;
      if (a.type === "functionCall") deposit += a.deposit;
    }
    const fee = BigInt(gas) * GAS_PRICE;
    if (signer.amount < deposit + (fee * 103n) / 100n) return this.err("INVALID_TRANSACTION", { InvalidTxError: { NotEnoughBalance: {} } });
    if (this.dropNext > 0) {
      this.dropNext--;
      return { result: {} };
    }
    k.nonce = tx.nonce;
    const actions = tx.actions.map((a) => (a.type === "transfer" ? { Transfer: { deposit: a.deposit.toString() } } : a.type === "functionCall" ? { FunctionCall: { method_name: a.method, args: Buffer.from(a.args).toString("base64"), gas: Number(a.gas), deposit: a.deposit.toString() } } : "CreateAccount"));
    const row: TxRow = { hash, signer: tx.signerId, receiver: tx.receiverId, bytes, queries: 0, mode: "ok", burnt: fee, blockHash: this.blockHash, amount: deposit, ts: Date.now(), kind: tx.actions.some((a) => a.type === "transfer") ? "transfer" : "call", pk: keyToString(tx.publicKey), nonce: tx.nonce, actions };
    signer.amount -= fee;
    for (const a of tx.actions) {
      if (a.type === "transfer") {
        let r = this.accounts.get(tx.receiverId);
        if (!r && /^[0-9a-f]{64}$/.test(tx.receiverId)) r = this.addAccount(tx.receiverId, 0n, new Uint8Array(Buffer.from(tx.receiverId, "hex")));
        if (!r) {
          row.mode = "fail";
          row.failure = { ActionError: { kind: { AccountDoesNotExist: { account_id: tx.receiverId } } } };
        } else {
          signer.amount -= a.deposit;
          r.amount += a.deposit;
        }
      } else if (a.type === "functionCall" && tx.receiverId === "testnet" && a.method === "create_account") {
        const args = JSON.parse(new TextDecoder().decode(a.args));
        if (this.failRegistrations) {
          row.mode = "fail";
          row.failure = { ActionError: { kind: { FunctionCallError: { ExecutionError: "Smart contract panicked: registration refused" } } } };
        } else if (this.accounts.has(args.new_account_id)) {
          row.mode = "fail";
          row.failure = { ActionError: { kind: { FunctionCallError: "AccountAlreadyExists" } } };
        } else {
          signer.amount -= a.deposit;
          const na = this.addAccount(args.new_account_id, 0n);
          na.amount = a.deposit;
          na.keys.set(args.new_public_key, { nonce: 0n, full: true });
        }
      }
    }
    this.txs.set(hash, row);
    this.height++;
    this.log.push(`${tx.signerId}->${tx.receiverId} ${row.mode}`);
    return { result: {} };
  }

  /**
   * Shape modelled on the example in NearBlocks' docs for `/v1/account/{id}/txns`: receipt-style entries with
   * `predecessor_account_id`, `receiver_account_id`, `receipt_outcome.status`, `transaction_hash`, `block_timestamp`.
   * The index is only ever a HINT: the app takes every fact (sender, receiver, amount, status) from the `tx` RPC.
   */
  indexFor(account: string) {
    const txns = [...this.txs.values()]
      .filter((r) => r.receiver === account || r.signer === account)
      .reverse()
      .map((r) => ({
        id: r.hash,
        predecessor_account_id: r.signer,
        receiver_account_id: r.receiver,
        receipt_kind: "ACTION",
        receipt_outcome: { status: r.mode === "ok" },
        transaction_hash: r.hash,
        block_timestamp: (BigInt(r.ts) * 1_000_000n).toString(),
        actions: [r.kind === "transfer" ? { action: "TRANSFER", method: null } : { action: "FUNCTION_CALL", method: "create_account" }],
        actions_agg: { deposit: Number(r.amount) },
      }));
    return { txns, cursor: null };
  }
}

export const hexOf = toHex;
