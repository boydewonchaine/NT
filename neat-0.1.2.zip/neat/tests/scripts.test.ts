// The funder key generator is a dependency-free script; check what it prints is exactly what the server expects.
import test from "node:test";
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { parseSecretKey, signerFromSeed, verifySignature } from "../src/core/near";
import { toHex, utf8 } from "../src/core/encoding";

test("funder-keygen prints an id and key that agree, parse on the server, and sign and verify", async () => {
  const run = () => execFileSync(process.execPath, ["scripts/funder-keygen.mjs"], { encoding: "utf8", stdio: ["ignore", "pipe", "ignore"] });
  const out = run();
  const id = /^NEAT_FUNDER_ID=([0-9a-f]{64})$/m.exec(out)?.[1];
  const key = /^NEAT_FUNDER_KEY=(ed25519:[1-9A-HJ-NP-Za-km-z]+)$/m.exec(out)?.[1];
  assert.ok(id && key, out);
  const k = parseSecretKey(key);
  assert.equal(toHex(k.publicKey), id, "the account id is the hex of the key's public half");
  const signer = await signerFromSeed(k.seed, k.publicKey);
  const sig = await signer.sign(utf8.enc("neat"));
  assert.equal(await verifySignature(k.publicKey, utf8.enc("neat"), sig), true, "the seed really belongs to the public key");
  assert.notEqual(run(), out, "every run produces a fresh key");
});

test("the public build contains no server secrets, whatever is in the environment at build time", async (t) => {
  const { existsSync, readdirSync, readFileSync, rmSync, statSync } = await import("node:fs");
  const { join } = await import("node:path");
  const out = "dist-secretcheck"; // relative: build.mjs always writes inside the project
  const secrets = ["ed25519:SECRETFUNDERKEYVALUE1234567890abcdef", "rpc-key-DO-NOT-SHIP-987654", "funder-id-marker.testnet"];
  const env = { ...process.env, NEAT_OUT: out, NEAT_FUNDER_ID: secrets[2], NEAT_FUNDER_KEY: secrets[0], NEAT_RPC_KEY: secrets[1], NEAT_STARTING_BALANCE: "7" };
  try {
    execFileSync(process.execPath, ["scripts/build.mjs"], { env, stdio: "ignore" });
  } catch {
    return t.skip("esbuild is not available here (npm install, or set ESBUILD_PATH)");
  }
  try {
    const files: string[] = [];
    const walk = (d: string) => readdirSync(d).forEach((n) => (statSync(join(d, n)).isDirectory() ? walk(join(d, n)) : files.push(join(d, n))));
    walk(out);
    assert.ok(files.length > 5 && existsSync(join(out, "sw.js")), "the build produced the app");
    for (const f of files) {
      if (/\.(png|ico)$/.test(f)) continue;
      const text = readFileSync(f, "utf8");
      for (const s of secrets) assert.ok(!text.includes(s), `${f} must not contain a server secret`);
    }
  } finally {
    rmSync(out, { recursive: true, force: true });
  }
});
