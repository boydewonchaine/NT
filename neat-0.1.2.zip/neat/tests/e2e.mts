// End-to-end, suite 1 of 3: the core journey in real Chromium against the production bundle and a mock NEAR chain.
//   create wallet → name → receive QR → scan → amount → review → authorize → settle → verify, plus lock/restore/offline.
// Build the bundle and run all suites with `npm run e2e` (see README).
import { readFileSync } from "node:fs";
import { OUT, ORIGIN, SENT_A, SENT_B, createWallet, openSuite } from "./e2e-lib.mts";
import { formatNear } from "../src/core/units";

const S = await openSuite("journey");
const { chain, post, browser, newCtx, watch, check, waitText, shot, text, finish } = S;

// ---------------------------------------------------------------------------------------------
const ctxA = await newCtx(), ctxB = await newCtx();
const alice = await ctxA.newPage(), bob = await ctxB.newPage();

// ===== splash + first run =====
watch(bob, "bob");
await bob.goto(ORIGIN + "/");
const splashSeen = await bob.locator(".splash .mark").count();
check("splash shows the NEAT mark on first paint", splashSeen === 1);
await shot(bob, "01-splash");
await bob.waitForSelector('input[aria-label="Personal sentence"]');
await shot(bob, "02-create");
check("first run lands on Create wallet (no wallet-connect screen)", /Create your wallet/.test(await text(bob, "h1")));
check("create screen has no external wallet-connect option", !/connect (a )?wallet|metamask|near wallet|meteor|my near/i.test(await bob.innerText("body")));

// weak sentences rejected, mismatch rejected
await bob.fill('input[aria-label="Personal sentence"]', "short");
check("short sentence is refused", await bob.getByRole("button", { name: "Create wallet" }).isDisabled());
await bob.fill('input[aria-label="Personal sentence"]', SENT_B);
await bob.fill('input[aria-label="Repeat your sentence"]', SENT_B + "x");
check("mismatched confirmation is refused", await bob.getByRole("button", { name: "Create wallet" }).isDisabled());
check("sentence input is capped at 100 chars", (await bob.getAttribute('input[aria-label="Personal sentence"]', "maxlength")) === "100");

// ===== create wallet + identity for Bob =====
await bob.fill('input[aria-label="Repeat your sentence"]', SENT_B);
await bob.getByRole("button", { name: "Create wallet" }).click();
await bob.waitForSelector('input[aria-label="Choose your NEAT name"]', { timeout: 20000 });
check("wallet is created, then asks for a name", true);
const stored = await bob.evaluate(() => localStorage.getItem("neat.state.v1")!);
const st = JSON.parse(stored);
check("vault is stored encrypted (ciphertext, salt, iv, 600k PBKDF2 iterations)", !!st.vault?.ct && !!st.vault?.salt && !!st.vault?.iv && st.vault.iter === 600000 && st.vault.kdf === "PBKDF2-SHA256");
check("sentence is not present anywhere in storage", !stored.includes("bicycle") && !stored.includes("dawn"));
check("no plaintext key material key names in storage", !/seed|secret|private/i.test(stored));
check("name not shown as registered before registration", st.vault.accountId === null);

// name validation + availability
const nameInput = bob.locator('input[aria-label="Choose your NEAT name"]');
await nameInput.fill("ab");
await bob.waitForSelector("text=at least 3");
check("too-short name is explained", true);
await nameInput.fill("Bad Name!");
check("input is lower-cased / spaces stripped", (await nameInput.inputValue()) === "badname!");
await bob.waitForSelector("text=Lowercase letters");
chain.addAccount("taken.testnet", 1n);
await nameInput.fill("taken");
await bob.waitForSelector("text=taken.testnet is taken");
check("taken name is reported as taken (real RPC lookup)", await bob.getByRole("button", { name: "Continue" }).isDisabled());
await shot(bob, "03-identity-taken");
await nameInput.fill("bob");
await bob.waitForSelector("text=bob.testnet is available");
await shot(bob, "04-identity-available");
await bob.getByRole("button", { name: "Continue" }).click();
await bob.waitForSelector("text=Register bob.testnet?");
await shot(bob, "05-identity-confirm");
check("registration requires explicit confirmation (nothing sent yet)", (await (await fetch(`${ORIGIN}/__test/stats`, { method: "POST", body: "{}" })).json()).registerCalls === 0);
await bob.getByRole("button", { name: "Register name" }).click();
await bob.waitForSelector(".home", { timeout: 30000 });
await shot(bob, "06-registered-lands-on-dashboard");
const landed = await bob.innerText("body");
check("a successful registration goes straight to the dashboard: no interim screen, no 'Open wallet', no explorer link or prompt to view one", (await bob.locator(".home").count()) === 1 && (await bob.locator('a[href*="/txns/"]').count()) === 0 && !/open wallet|nearblocks|explorer|registration transaction/i.test(landed), landed.replace(/\n/g, " | ").slice(0, 200));
check("registered name shown only after on-chain confirmation", /bob/.test(await text(bob, "h1")) && chain.accounts.has("bob.testnet"));
const bobKeyOnChain = [...chain.accounts.get("bob.testnet")!.keys.keys()][0];
check("on-chain account is controlled by the key made on this device", (await bob.evaluate(() => JSON.parse(localStorage.getItem("neat.state.v1")!).vault.publicKey)) === bobKeyOnChain);
check("starting balance came from the funder service, not the browser", chain.accounts.get("bob.testnet")!.amount === 5n * 10n ** 24n);
await bob.waitForSelector(".home");
await shot(bob, "07-home-bob");
check("home shows the NEAT name as identity", /bob\.testnet/.test(await bob.innerText(".home h1")));
check("home shows the real balance", (await bob.innerText(".balance")).includes("5"));
check("home never shows a long hex address", !/[0-9a-f]{40,}/.test(await bob.innerText("body")));

// ===== Alice =====
watch(alice, "alice");
await createWallet(alice, SENT_A, "alice");
await alice.waitForSelector(".home");
check("second wallet registered independently", chain.accounts.has("alice.testnet"));
await shot(alice, "08-home-alice");

// ===== Receive (Bob): open QR + amount request =====
await bob.getByRole("button", { name: "Receive", exact: true }).click();
await bob.waitForSelector(".qrcard svg");
await shot(bob, "09-receive-open");
const openQrMeta = await bob.innerText("main");
check("receive screen shows identity, QR and network", /bob/.test(openQrMeta) && /Testnet/i.test(openQrMeta));
await bob.getByRole("tab", { name: "Request amount" }).click();
await bob.fill('input[aria-label="Amount in NEAR"]', "1.5");
await bob.fill('input[aria-label="Note"]', "lunch");
await shot(bob, "10-request-form");
await bob.getByRole("button", { name: "Create request" }).click();
await bob.waitForSelector(".qrcard svg");
await shot(bob, "11-request-qr");
check("amount request shows amount and an Open status", /1\.5/.test(await bob.innerText("main")) && /Open/.test(await bob.innerText("main")));
const bobBefore = BigInt((await post("balance", { id: "bob.testnet" })).amount);
check("creating a request moved no funds", bobBefore === 5n * 10n ** 24n);
await bob.locator(".qrcard").screenshot({ path: `${OUT}/bob-request-qr.png` });

// ===== no copy / paste affordances anywhere =====
async function noCopyPaste(page: any, where: string) {
  const labels: string[] = await page.evaluate(() => [...document.querySelectorAll("button, a, [role=button], input[type=button], label, summary")].map((e) => ((e as HTMLElement).innerText || e.getAttribute("aria-label") || "").trim()).filter(Boolean));
  const bad = labels.filter((l) => /\b(copy|paste)\b/i.test(l));
  check(`no copy/paste control on ${where}`, bad.length === 0, bad.join(", "));
}
await noCopyPaste(bob, "Receive (request)");
check("no text input accepts a pasted address or link on Receive", (await bob.locator('input[placeholder*="address" i], input[placeholder*="link" i], input[placeholder*="http" i]').count()) === 0);

// ===== QR payload has no secrets =====
const qrLocal = JSON.parse(await bob.evaluate(() => localStorage.getItem("neat.state.v1")!));
const reqRec = qrLocal.requests.find((r: any) => r.kind === "amount");
check("stored request record holds only public fields", !!reqRec && !("seed" in reqRec.request) && Object.keys(reqRec.request).every((k) => ["v", "id", "to", "pk", "amt", "fix", "asset", "net", "note", "iat", "exp", "sig"].includes(k)));

// ===== Alice scans via image upload (software decoder in real Chromium) =====
await alice.getByRole("button", { name: "Send", exact: true }).click();
await alice.waitForSelector("text=Scan to pay");
await shot(alice, "12-scan");
await noCopyPaste(alice, "Scan");
check("scan screen offers camera + upload only (no address/link field)", (await alice.locator('input[type=text], input:not([type])').count()) === 0 && (await alice.locator('input[type=file]').count()) === 1);
// junk image first
await alice.setInputFiles("#qrfile", `${OUT}/shots/journey-01-splash.png`);
await alice.waitForSelector("text=No QR code found");
check("an image without a QR is rejected with a clear message, and no payment starts", (await post("stats")).broadcasts === 2); // only the 2 name registrations so far
await alice.getByRole("button", { name: "Scan again" }).click();
await alice.setInputFiles("#qrfile", `${OUT}/bob-request-qr.png`);
await alice.waitForSelector("text=Paying", { timeout: 15000 });
await shot(alice, "13-amount");
check("scanned QR resolves to the recipient's NEAT name", /bob/.test(await alice.innerText("h1")));
check("amount screen shows a verification line", /Verified/.test(await alice.innerText("main")));
check("fixed-amount request keeps its amount (read-only)", (await alice.inputValue('input[aria-label="Amount in NEAR"]')) === "1.5" && (await alice.getAttribute('input[aria-label="Amount in NEAR"]', "readonly")) !== null);
check("scan alone never submitted a transaction", (await post("stats")).broadcasts === 2);
await alice.waitForFunction(() => !(document.querySelector("button.btn:not(.sec):not(.ghost)") as HTMLButtonElement | null)?.disabled, null, { timeout: 8000 });
await alice.getByRole("button", { name: "Review" }).click();
await alice.waitForSelector("text=Authorize payment");
await shot(alice, "14-review");
const review = await alice.innerText("main");
check("review shows recipient, amount, one stamp-fee line, total, recipient gets, network", /bob\.testnet/.test(review) && /Stamp fee \(estimated\)/.test(review) && !/Network fee|NEAT service fee/.test(review) && /Total cost to you/.test(review) && /They receive/.test(review) && /NEAR Testnet/.test(review));
const feeText = /Stamp fee \(estimated\)\s*([0-9.]+) NEAR/.exec(review.replace(/\n/g, " "));
check("stamp fee is a real estimate, not zero", !!feeText && Number(feeText[1]) > 0, feeText?.[1]);
check("review didn't submit anything yet", (await post("stats")).broadcasts === 2);

// ===== authorize → processing → receipt, with real lifecycle =====
await post("set", { finalizeAfter: 2 });
await alice.getByRole("button", { name: "Authorize payment" }).click();
await alice.waitForSelector("text=Sending payment");
await shot(alice, "15-processing");
check("processing screen shows steps, not a success message", /Confirming on the network/.test(await alice.innerText("main")) && !/Payment sent/.test(await alice.innerText("main")));
await alice.waitForSelector("text=Payment sent", { timeout: 30000 });
await shot(alice, "16-receipt");
const rc = await alice.innerText("main");
check("receipt reports Completed only after FINAL", /Completed/i.test(rc) && /FINAL/.test(rc));
check("receipt shows amount, stamp fee (actual), parties, network, hash, evidence", /1\.5/.test(rc) && /Stamp fee/i.test(rc) && !/Network fee/i.test(rc) && /alice\.testnet/.test(rc) && /bob\.testnet/.test(rc) && /NEAR Testnet/.test(rc) && /evidence/i.test(rc) && /Transaction/i.test(rc));
check("receipt links to an explorer but has no copy action", (await alice.locator('a[href*="/txns/"]').count()) === 1);
await noCopyPaste(alice, "Receipt");
const bobAfter = BigInt((await post("balance", { id: "bob.testnet" })).amount);
check("recipient actually received exactly the amount on chain", bobAfter - bobBefore === 15n * 10n ** 23n);
const aliceTx = JSON.parse(await alice.evaluate(() => localStorage.getItem("neat.state.v1")!)).txs[0];
check("local record: completed, fee reconciled, signed bytes cleared", aliceTx.status === "completed" && !!aliceTx.feeActual && !aliceTx.signed);

// the receipt is a small printed slip: contained, plain typewriter type, the date and time printed on it, names in bold
{
  const slip = alice.locator(".slip");
  const box = (await slip.boundingBox())!;
  const vp = alice.viewportSize()!;
  check("receipt is a contained slip: narrower than the screen, and it fits the screen together with its Done button (no scrolling to read it)", box.width <= 305 && box.width < vp.width - 40 && box.height <= vp.height - 150 && (await alice.evaluate(() => { const m = document.querySelector("main.screen")!; return m.scrollHeight <= m.clientHeight + 1; })), JSON.stringify({ box, vp }));
  const type = await slip.evaluate((el) => ({ family: getComputedStyle(el).fontFamily, weight: getComputedStyle(el).fontWeight, name: getComputedStyle(el.querySelector(".ln b")!).fontWeight, size: getComputedStyle(el).fontSize }));
  check("receipt type is the plain typewriter face at regular weight; only the names (and the header) are bold", /Courier/.test(type.family) && type.weight === "400" && Number(type.name) >= 600 && parseFloat(type.size) <= 13, JSON.stringify(type));
  const printed = await alice.evaluate((ms: number) => {
    const d = new Date(ms);
    return { date: d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" }), time: d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short" }) };
  }, aliceTx.createdAt);
  check("receipt prints the date and the time the payment was made", /\bdate\b/i.test(rc) && /\btime\b/i.test(rc) && rc.includes(printed.date) && rc.includes(printed.time), JSON.stringify(printed));
  const total = formatNear(15n * 10n ** 23n + BigInt(aliceTx.feeActual), 9);
  check("receipt shows one stamp-fee line (the fee the network actually charged) and a total that adds the fee to the amount", rc.replace(/\n/g, " ").includes(`${formatNear(BigInt(aliceTx.feeActual), 9)} NEAR`) && rc.replace(/\n/g, " ").includes(`${total} NEAR`), total);
  check("receipt has a boxed status stamp and the printed names are the people's NEAT names", (await alice.locator(".slip .stamp.ok").count()) === 1 && /alice\.testnet/.test(await alice.innerText(".slip .ln b")));
}

// duplicate: scanning the same (fixed) request again is refused
await alice.getByRole("button", { name: "Done" }).click();
await alice.getByRole("button", { name: "Send", exact: true }).click();
await alice.setInputFiles("#qrfile", `${OUT}/bob-request-qr.png`);
await alice.waitForSelector("text=already paid", { timeout: 15000 });
check("already-paid request is detected and cannot be paid twice", (await post("stats")).broadcasts === 3);
await shot(alice, "17-already-paid");
await alice.getByRole("button", { name: "Back", exact: true }).click();
await alice.waitForSelector(".home");

// ===== Bob: incoming payment appears, request becomes Paid after verification =====
await bob.getByRole("button", { name: "New request" }).click().catch(() => {});
await bob.reload();
await bob.waitForSelector('input[aria-label="Your personal sentence"]');
await shot(bob, "18-unlock");
check("reload returns to the Unlock screen, never creates a new wallet", /locked/i.test(await bob.innerText("main")) && /bob/.test(await bob.innerText("h1")));
// wrong sentence
await bob.fill('input[aria-label="Your personal sentence"]', "this is definitely wrong sentence");
await bob.getByRole("button", { name: "Unlock" }).click();
await bob.waitForSelector("text=doesn't match this wallet");
check("incorrect sentence does not unlock and says so", true);
await shot(bob, "19-unlock-wrong");
check("vault is untouched by a failed unlock", JSON.parse(await bob.evaluate(() => localStorage.getItem("neat.state.v1")!)).vault.publicKey === bobKeyOnChain);
// rate limit after 3 failures
for (let i = 0; i < 2; i++) {
  await bob.fill('input[aria-label="Your personal sentence"]', "wrong sentence number " + i);
  await bob.getByRole("button", { name: "Unlock" }).click();
  await bob.waitForSelector("text=doesn't match this wallet");
  await bob.waitForTimeout(150);
}
await bob.waitForSelector("text=Too many wrong attempts");
check("repeated failures trigger a lockout delay", await bob.getByRole("button", { name: "Unlock" }).isDisabled());
await shot(bob, "20-unlock-locked-out");
// clear the lockout (test hook: edit the stored counter, simulating the wait elapsing)
await bob.evaluate(() => { const s = JSON.parse(localStorage.getItem("neat.state.v1")!); s.attempts = { fails: 0, lockedUntil: 0 }; localStorage.setItem("neat.state.v1", JSON.stringify(s)); });
await bob.reload();
await bob.fill('input[aria-label="Your personal sentence"]', SENT_B);
await bob.getByRole("button", { name: "Unlock" }).click();
await bob.waitForSelector(".home", { timeout: 15000 });
check("correct sentence unlocks the existing wallet", /bob\.testnet/.test(await bob.innerText(".home h1")));
await waitText(bob, "incoming payment shows up in recent activity", "Received");
await shot(bob, "21-home-bob-received");
check("incoming payment is discovered (index hint) and verified through RPC", /\+1\.5/.test(await bob.innerText(".list")));
const bobBal = await bob.innerText(".balance");
check("balance reflects the received funds", /6\.4999|6\.5/.test(bobBal) || /6/.test(bobBal), bobBal);
await bob.getByRole("button", { name: "See all" }).click();
await bob.getByRole("tab", { name: "Requests" }).click();
await waitText(bob, "request flips to Paid after verification", "Paid");
await shot(bob, "22-activity-requests");
check("request is marked Paid only after verified completed incoming transfer", /Paid/.test(await bob.innerText("main")));

// ===== insufficient balance for amount + fee =====
await bob.getByRole("button", { name: "Back", exact: true }).click();
await bob.getByRole("button", { name: "Send", exact: true }).click();
// Alice makes an open QR; Bob (6.5 NEAR) tries to pay 100
await alice.getByRole("button", { name: "Receive", exact: true }).click();
await alice.waitForSelector(".qrcard svg");
await alice.locator(".qrcard").screenshot({ path: `${OUT}/alice-open-qr.png` });
await bob.setInputFiles("#qrfile", `${OUT}/alice-open-qr.png`);
await bob.waitForSelector("text=Paying", { timeout: 15000 });
await bob.fill('input[aria-label="Amount in NEAR"]', "100");
await bob.waitForSelector("text=can't cover");
await shot(bob, "23-insufficient");
check("insufficient balance for amount + fee is explained before review", await bob.getByRole("button", { name: "Review" }).isDisabled());
const bal = (await bob.innerText("main")).match(/Available ([0-9.,]+) NEAR after fees/);
check("amount screen shows spendable balance after fees and storage", !!bal && Number(bal[1].replace(",", "")) < 6.5 && Number(bal[1].replace(",", "")) > 6.4, bal?.[1]);
// exactly-max works: use max
await bob.getByRole("button", { name: "Use max" }).click();
check("'Use max' leaves room for the fee", !(await bob.getByRole("button", { name: "Review" }).isDisabled()));
await bob.fill('input[aria-label="Amount in NEAR"]', "0.25");
await bob.getByRole("button", { name: "Review" }).click();
await bob.waitForSelector("text=Authorize payment");
check("open QR (no amount) lets the payer choose the amount", /0\.25/.test(await bob.innerText("main")));

// ===== timeout / lost submission: never auto-resubmits, safe resend of identical tx =====
await post("set", { dropNext: 1 });
const bcBefore = (await post("stats")).broadcasts;
await bob.getByRole("button", { name: "Authorize payment" }).click();
await bob.waitForSelector("text=Sending payment");
// shorten: leave the screen instead of waiting two minutes — payment state must persist honestly
await bob.waitForTimeout(2500);
await shot(bob, "24-processing-unknown");
await bob.reload();
await bob.fill('input[aria-label="Your personal sentence"]', SENT_B);
await bob.getByRole("button", { name: "Unlock" }).click();
await bob.waitForSelector(".home");
const pendingList = await bob.innerText(".list");
check("a payment the network hasn't confirmed is shown as pending, not as sent or failed", /Submitted|Confirming|Not confirmed/.test(pendingList) && !/Failed/.test(pendingList), pendingList.replace(/\n/g, " | "));
check("reload/timeout did not trigger any second broadcast", (await post("stats")).broadcasts === bcBefore + 1);
await bob.locator(".list .item").first().click();
await bob.waitForSelector("text=Evidence", { timeout: 8000 });
await shot(bob, "25-receipt-pending");
check("while unconfirmed the receipt says Processing and does not claim success", /Processing|Not confirmed/.test(await bob.innerText("main")) && !/Payment sent/.test(await bob.innerText("main")));
await bob.getByRole("button", { name: "Resend the same payment" }).waitFor({ timeout: 25000 });
await shot(bob, "25b-receipt-resend-offered");
check("after a grace period with no network record, the receipt warns not to pay again and offers a safe resend", /Don't pay again/.test(await bob.innerText("main")));
await bob.getByRole("button", { name: "Resend the same payment" }).click();
await bob.waitForSelector("text=Payment sent", { timeout: 30000 });
check("resend re-sent the identical tx; it executed exactly once", (await post("stats")).broadcasts === bcBefore + 2 && chain.log.filter((l: string) => l === "bob.testnet->alice.testnet ok").length === 1);

// ===== lock / settings / backup / restore =====
await bob.getByRole("button", { name: "Done" }).click();
await bob.getByRole("button", { name: "Settings" }).click();
await shot(bob, "26-settings");
const settingsText = await bob.innerText("main");
check("settings: lock, backup, install, network info present", /Lock now/.test(settingsText) && /Download encrypted backup/.test(settingsText) && /Install/.test(settingsText) && /NEAR Testnet/.test(settingsText));
check("settings is honest about device loss", /losing this device means losing the wallet|Without a backup/.test(settingsText));
await noCopyPaste(bob, "Settings");
const [dl] = await Promise.all([bob.waitForEvent("download"), bob.getByRole("button", { name: "Download encrypted backup" }).click()]);
const backupPath = `${OUT}/bob.neat`;
await dl.saveAs(backupPath);
const backupText = readFileSync(backupPath, "utf8");
check("backup file is encrypted: no sentence, no plaintext seed", !backupText.includes("bicycle") && JSON.parse(backupText).vault.ct.length > 20 && JSON.parse(backupText).format === 1);
await bob.getByRole("button", { name: "Lock now" }).click();
await bob.waitForSelector('input[aria-label="Your personal sentence"]');
check("Lock now returns to unlock and clears the session", true);

// new device: restore from backup
const ctxB2 = await newCtx();
const bob2 = await ctxB2.newPage();
watch(bob2, "bob2");
await bob2.goto(ORIGIN + "/");
await bob2.getByRole("button", { name: "Restore from a backup file" }).click();
await bob2.setInputFiles("#bk", backupPath);
await bob2.waitForSelector("text=Backup found. Enter its sentence.");
await bob2.fill('input[aria-label="Your sentence"]', "wrong wrong wrong wrong");
await bob2.getByRole("button", { name: "Restore wallet" }).click();
await bob2.waitForSelector("text=doesn't match this backup");
check("restore with the wrong sentence fails and creates nothing", (await bob2.evaluate(() => JSON.parse(localStorage.getItem("neat.state.v1") ?? "{}").vault ?? null)) === null);
await bob2.fill('input[aria-label="Your sentence"]', SENT_B);
await bob2.getByRole("button", { name: "Restore wallet" }).click();
await bob2.waitForSelector(".home", { timeout: 20000 });
await shot(bob2, "27-restored");
check("backup + sentence restores the wallet on a new device with its verified name", /bob\.testnet/.test(await bob2.innerText(".home h1")));
const bob2Key = await bob2.evaluate(() => JSON.parse(localStorage.getItem("neat.state.v1")!).vault.publicKey);
check("restored wallet has the same key", bob2Key === bobKeyOnChain);
// the existing-device Create screen can never overwrite
await ctxB2.close();

// ===== offline behaviour + PWA =====
const manifest = await (await fetch(ORIGIN + "/manifest.webmanifest")).json();
check("manifest: standalone, name, icons incl. maskable", manifest.display === "standalone" && manifest.name === "NEAT" && manifest.icons.some((i: any) => i.purpose === "maskable") && manifest.icons.some((i: any) => i.sizes === "512x512"));
const swReady = await alice.evaluate(async () => { const r = await navigator.serviceWorker.ready; return !!r.active; });
check("service worker is active", swReady);
await alice.reload();
await alice.waitForSelector('input[aria-label="Your personal sentence"]');
await alice.fill('input[aria-label="Your personal sentence"]', SENT_A);
await alice.getByRole("button", { name: "Unlock" }).click();
await alice.waitForSelector(".home");
await ctxA.setOffline(true);
await alice.waitForSelector("#net-banner");
await shot(alice, "28-offline-home");
check("offline banner appears and states payments need a connection", /offline/i.test(await alice.innerText("#net-banner")));
await alice.getByRole("button", { name: "Lock" }).click();
await alice.reload();
await alice.waitForSelector('input[aria-label="Your personal sentence"]', { timeout: 10000 });
check("offline reload still opens the app shell (from the service worker cache)", true);
await shot(alice, "29-offline-reload");
await ctxA.setOffline(false);

await finish();
