// Registration funder diagnostics.
//
// The deployed app once answered every funder problem with the same line, "isn't set up (the funder isn't
// configured)": a missing variable, a funder account that was never funded, a key that doesn't belong to the account,
// even a malformed key. Whoever runs a deployment can't fix a problem that has the wrong name, so each of these
// now has its own code and wording, and none of them involves the user or anything secret.
import test, { beforeEach } from "node:test";
import assert from "node:assert/strict";
import { MockChain } from "./mock-chain";
import { Rpc } from "../src/core/rpc";
import { generateKeypair, keyToString } from "../src/core/near";
import { base58Encode } from "../src/core/encoding";
import { requestRegistration } from "../src/core/identity";
import { checkFunder, funderStatus, handleRegister, readFunder, startingBalance } from "../src/server/register";

const FUNDER = "neat-funder.testnet";
let chain: MockChain, rpc: Rpc;
let ipSeq = 0;
const ip = () => `20.${Math.floor(ipSeq / 250)}.${ipSeq++ % 250}.1`; // the registration rate limit is per address; every call gets its own

type Kp = { seed: Uint8Array; publicKey: Uint8Array };
const secretOf = (k: Kp) => "ed25519:" + base58Encode(new Uint8Array([...k.seed, ...k.publicKey]));
const goodEnv = (k: Kp, extra: Record<string, string> = {}) => ({ NEAT_FUNDER_ID: FUNDER, NEAT_FUNDER_KEY: secretOf(k), NEAT_STARTING_BALANCE: "1", ...extra });

let funder: Kp, user: Kp;
beforeEach(async () => {
  chain = new MockChain();
  rpc = new Rpc({ endpoints: ["http://mock"], fetchImpl: chain.fetchImpl as any, timeoutMs: 2000 });
  funder = await generateKeypair();
  user = await generateKeypair();
});

const register = (env: Record<string, string | undefined>, label = "newbie", r: Rpc = rpc) => handleRegister({ label, publicKey: keyToString(user.publicKey) }, env, ip(), r);
const neverTouched = new Rpc({ endpoints: ["http://nowhere"], fetchImpl: (async () => { throw new Error("the network must not be touched for a settings problem"); }) as any, timeoutMs: 500 });
const noSecrets = (o: unknown, ...secrets: string[]) => {
  const text = JSON.stringify(o);
  for (const s of secrets) assert.ok(!text.includes(s), "a secret appeared in a reply");
};

test("unconfigured: says exactly which variable is missing, and never touches the network", async () => {
  const both = await register({}, "newbie", neverTouched);
  assert.equal(both.status, 503);
  assert.equal(both.body.code, "unconfigured");
  assert.deepEqual(both.body.missing, ["NEAT_FUNDER_ID", "NEAT_FUNDER_KEY"]);
  assert.match(String(both.body.detail), /Missing on the server: NEAT_FUNDER_ID and NEAT_FUNDER_KEY/);

  const noKey = await register({ NEAT_FUNDER_ID: FUNDER }, "newbie", neverTouched);
  assert.equal(noKey.body.code, "unconfigured");
  assert.deepEqual(noKey.body.missing, ["NEAT_FUNDER_KEY"]);

  const noId = await register({ NEAT_FUNDER_KEY: secretOf(funder) }, "newbie", neverTouched);
  assert.equal(noId.body.code, "unconfigured");
  assert.deepEqual(noId.body.missing, ["NEAT_FUNDER_ID"]);
  noSecrets(noId, secretOf(funder), base58Encode(funder.seed));

  // a variable that exists but is empty (a blank field saved in a dashboard) is the same as a missing one
  const blank = await register({ NEAT_FUNDER_ID: "  ", NEAT_FUNDER_KEY: "" }, "newbie", neverTouched);
  assert.deepEqual(blank.body.missing, ["NEAT_FUNDER_ID", "NEAT_FUNDER_KEY"]);
});

test("malformed settings are called malformed, not 'not configured'", async () => {
  const other = await generateKeypair();
  const damaged = "ed25519:" + base58Encode(new Uint8Array([...funder.seed, ...other.publicKey])); // right length, halves don't belong together
  const cases: { why: string; env: Record<string, string>; code: string; mentions: RegExp }[] = [
    { why: "an account id with spaces and capitals", env: goodEnv(funder, { NEAT_FUNDER_ID: "Not A Valid ID!" }), code: "funder_config", mentions: /NEAT_FUNDER_ID/ },
    { why: "a key that is not a key", env: goodEnv(funder, { NEAT_FUNDER_KEY: "not-a-key" }), code: "funder_config", mentions: /NEAT_FUNDER_KEY/ },
    { why: "a key cut short", env: goodEnv(funder, { NEAT_FUNDER_KEY: secretOf(funder).slice(0, 40) }), code: "funder_config", mentions: /NEAT_FUNDER_KEY/ },
    { why: "another key type", env: goodEnv(funder, { NEAT_FUNDER_KEY: secretOf(funder).replace("ed25519:", "secp256k1:") }), code: "funder_config", mentions: /NEAT_FUNDER_KEY/ },
    { why: "a key whose halves don't match (a character was lost in copying)", env: goodEnv(funder, { NEAT_FUNDER_KEY: damaged }), code: "funder_config", mentions: /don't match/ },
    { why: "a starting balance that is not a number", env: goodEnv(funder, { NEAT_STARTING_BALANCE: "a lot" }), code: "funder_config", mentions: /NEAT_STARTING_BALANCE/ },
    { why: "a starting balance of zero", env: goodEnv(funder, { NEAT_STARTING_BALANCE: "0" }), code: "funder_config", mentions: /NEAT_STARTING_BALANCE/ },
  ];
  for (const c of cases) {
    const r = await register(c.env, "newbie", neverTouched);
    assert.equal(r.status, 503, c.why);
    assert.equal(r.body.code, c.code, `${c.why}: ${JSON.stringify(r.body)}`);
    assert.match(String(r.body.detail), c.mentions, c.why);
    // the secret a person pasted must never be echoed back to anyone
    noSecrets(r, base58Encode(funder.seed), secretOf(funder), String(c.env.NEAT_FUNDER_KEY));
  }
});

test("values pasted the way dashboards mangle them are cleaned, and registration works", async () => {
  chain.addAccount(FUNDER, 100n, funder.publicKey);
  const key = secretOf(funder);
  const variants: Record<string, string>[] = [
    { NEAT_FUNDER_ID: FUNDER, NEAT_FUNDER_KEY: `"${key}"`, NEAT_STARTING_BALANCE: "1" }, // wrapping quotes
    { NEAT_FUNDER_ID: `  ${FUNDER}\n`, NEAT_FUNDER_KEY: `${key}\n`, NEAT_STARTING_BALANCE: " 1 " }, // stray whitespace
    { NEAT_FUNDER_ID: `NEAT_FUNDER_ID=${FUNDER}`, NEAT_FUNDER_KEY: `NEAT_FUNDER_KEY=${key}`, NEAT_STARTING_BALANCE: "NEAT_STARTING_BALANCE=1" }, // the whole line copied
    { NEAT_FUNDER_ID: `'${FUNDER}'`, NEAT_FUNDER_KEY: `'${key}'` }, // single quotes, balance left unset
  ];
  let n = 0;
  for (const env of variants) {
    const read = await readFunder(env);
    assert.ok(read.ok && read.funder.id === FUNDER, JSON.stringify(env));
    assert.equal(startingBalance(env), 10n ** 24n);
    const label = `mangled${n++}`;
    const r = await register(env, label);
    assert.equal(r.status, 200, JSON.stringify(r.body));
    assert.ok(chain.accounts.has(`${label}.testnet`), "the name exists on the chain");
  }
});

test("funder_unfunded: the account has never been given tokens, so it doesn't exist yet", async () => {
  // everything is set, correctly; the account simply isn't on the network
  const r = await register(goodEnv(funder));
  assert.equal(r.status, 503);
  assert.equal(r.body.code, "funder_unfunded");
  assert.equal(r.body.funder, FUNDER);
  assert.match(String(r.body.detail), /never received any testnet NEAR/);
  assert.match(String(r.body.detail), /Send it testnet NEAR/);
  assert.equal(chain.broadcasts, 0, "nothing was sent");
  assert.equal(chain.accounts.has("newbie.testnet"), false);
  // a 64-character funder id is shortened in sentences, and given whole in its own field
  const id64 = Buffer.from(funder.publicKey).toString("hex");
  const r2 = await register(goodEnv(funder, { NEAT_FUNDER_ID: id64 }));
  assert.equal(r2.body.code, "funder_unfunded");
  assert.equal(r2.body.funder, id64);
  assert.ok(String(r2.body.detail).includes(id64.slice(0, 8) + "…") && !String(r2.body.detail).includes(id64));
});

test("funder_key: the account exists, but the key in NEAT_FUNDER_KEY is not its key", async () => {
  const someoneElse = await generateKeypair();
  chain.addAccount(FUNDER, 100n, someoneElse.publicKey); // funded, but controlled by a different key
  const r = await register(goodEnv(funder));
  assert.equal(r.status, 503);
  assert.equal(r.body.code, "funder_key");
  assert.match(String(r.body.detail), /isn't registered on account/);
  assert.equal(chain.broadcasts, 0);

  // a limited-access (function-call) key can't pay a deposit either
  const limited = await generateKeypair();
  chain.addAccount(FUNDER, 100n, limited.publicKey);
  chain.accounts.get(FUNDER)!.keys.get(keyToString(limited.publicKey))!.full = false;
  const r2 = await register(goodEnv(limited));
  assert.equal(r2.body.code, "funder_key");
  assert.match(String(r2.body.detail), /limited-access key/);
  assert.equal(chain.broadcasts, 0);
});

test("funder_empty: names the balance and the cost; also caught when the network itself refuses for lack of tokens", async () => {
  const a = chain.addAccount(FUNDER, 0n, funder.publicKey);
  a.amount = 4n * 10n ** 23n; // 0.4 NEAR, a name costs 1
  const r = await register(goodEnv(funder));
  assert.equal(r.status, 503);
  assert.equal(r.body.code, "funder_empty");
  assert.equal(r.body.balance, "0.4 NEAR");
  assert.equal(r.body.perName, "1 NEAR");
  assert.match(String(r.body.detail), /holds 0\.4 NEAR; each name needs 1 NEAR plus network fees/);
  assert.equal(chain.broadcasts, 0, "the preflight spared a doomed transaction");

  // exactly the deposit: the preflight passes, the network then refuses (the fee can't be paid)
  a.amount = 10n ** 24n;
  const r2 = await register(goodEnv(funder));
  assert.equal(r2.status, 503);
  assert.equal(r2.body.code, "funder_empty");
  assert.equal(chain.accounts.has("newbie.testnet"), false);
});

test("a healthy funder registers the name, and the reply says who paid", async () => {
  chain.addAccount(FUNDER, 100n, funder.publicKey);
  const r = await register(goodEnv(funder, { NEAT_STARTING_BALANCE: "0.5" }), "dimeji2");
  assert.equal(r.status, 200);
  assert.equal(r.body.signerId, FUNDER);
  assert.equal(chain.accounts.get("dimeji2.testnet")!.amount, 5n * 10n ** 23n);
  noSecrets(r, secretOf(funder), base58Encode(funder.seed));
});

test("network trouble is reported as network trouble, with the reason; other failures aren't blamed on the network", async () => {
  chain.addAccount(FUNDER, 100n, funder.publicKey);
  chain.failNext = 100;
  const down = await register(goodEnv(funder));
  assert.equal(down.status, 502);
  assert.equal(down.body.code, "network");
  assert.match(String(down.body.detail), /network down/);
  chain.failNext = 0;

  const throttled = new Rpc({ endpoints: ["http://rate-limited"], fetchImpl: (async () => new Response("", { status: 429 })) as any, timeoutMs: 500 });
  const r = await register(goodEnv(funder), "newbie", throttled);
  assert.equal(r.body.code, "network");
  assert.equal(r.body.detail, "RPC 429", "an RPC provider refusing us is named, so it can be fixed (a key, a plan)");

  // something breaking in our own code is not the network's fault, and says nothing beyond the kind of error
  const bug = { viewAccount: async () => { throw new TypeError("a bug in our code"); } } as unknown as Rpc;
  const odd = await register(goodEnv(funder), "newbie", bug);
  assert.equal(odd.status, 500);
  assert.equal(odd.body.code, "failed");
  assert.equal(odd.body.detail, "TypeError");
  assert.ok(!JSON.stringify(odd.body).includes("a bug in our code"));
});

test("the readiness check: GET /api/register says whether registration works, registers nothing, and shows no secret", async () => {
  chain.addAccount(FUNDER, 12n, funder.publicKey);
  const ok = await funderStatus(goodEnv(funder), rpc, ip());
  assert.equal(ok.status, 200);
  assert.deepEqual(ok.body, { ready: true, network: "testnet", funder: FUNDER, balance: "12 NEAR", perName: "1 NEAR" });
  noSecrets(ok, secretOf(funder), base58Encode(funder.seed), base58Encode(funder.publicKey));
  assert.equal(chain.broadcasts, 0, "a check is not a registration");

  const none = await funderStatus({}, neverTouched, ip());
  assert.equal(none.status, 503);
  assert.equal(none.body.ready, false);
  assert.equal(none.body.code, "unconfigured");

  const unfunded = await funderStatus(goodEnv(funder, { NEAT_FUNDER_ID: "ghost-funder.testnet" }), rpc, ip());
  assert.equal(unfunded.body.ready, false);
  assert.equal(unfunded.body.code, "funder_unfunded");
  assert.equal(unfunded.body.funder, "ghost-funder.testnet");

  const wrongKey = await funderStatus(goodEnv(await generateKeypair()), rpc, ip());
  assert.equal(wrongKey.body.ready, false);
  assert.equal(wrongKey.body.code, "funder_key");

  chain.failNext = 100;
  const down = await funderStatus(goodEnv(funder), rpc, ip());
  chain.failNext = 0;
  assert.equal(down.status, 502);
  assert.equal(down.body.ready, false);
  assert.equal(down.body.code, "network");

  // it is cheap to call, but not free for us: a flood is turned away
  const same = "30.30.30.30";
  let last = await funderStatus(goodEnv(funder), rpc, same);
  for (let i = 0; i < 25; i++) last = await funderStatus(goodEnv(funder), rpc, same);
  assert.equal(last.status, 429);
});

test("checkFunder reports the nonce the signature will need, and the balance it saw", async () => {
  chain.addAccount(FUNDER, 7n, funder.publicKey);
  const read = await readFunder(goodEnv(funder));
  assert.ok(read.ok);
  const st = await checkFunder(read.funder, goodEnv(funder), rpc);
  assert.ok(st.ok && st.balance === 7n * 10n ** 24n && st.deposit === 10n ** 24n && st.nonce === 1n);
});

// ---------- what the app shows ----------

const f = (status: number, body: any) => (async () => new Response(JSON.stringify(body), { status })) as any;
const k = new Uint8Array(32);

test("client: each funder code gets its own wording and carries the operator's detail", async () => {
  const detail = "Specific next step.";
  const un = await requestRegistration("abc", k, "/x", f(503, { code: "unconfigured", missing: ["NEAT_FUNDER_KEY"], detail }));
  assert.ok(!un.ok && un.code === "unconfigured");
  assert.match(un.message, /isn't set up on this deployment yet \(the NEAT funder account isn't configured\)\./);
  assert.equal(un.detail, detail, "the specific fix (which variable) is the server's detail line");

  const cfg = await requestRegistration("abc", k, "/x", f(503, { code: "funder_config", detail }));
  assert.ok(!cfg.ok && cfg.code === "funder_config" && /set up incorrectly/.test(cfg.message) && cfg.detail === detail);

  const unf = await requestRegistration("abc", k, "/x", f(503, { code: "funder_unfunded", detail }));
  assert.ok(!unf.ok && unf.code === "funder_unfunded" && /hasn't been given any testnet tokens/.test(unf.message) && unf.detail === detail);

  const key = await requestRegistration("abc", k, "/x", f(503, { code: "funder_key", detail }));
  assert.ok(!key.ok && key.code === "funder_key" && /funder key doesn't work/.test(key.message) && key.detail === detail);

  const empty = await requestRegistration("abc", k, "/x", f(503, { code: "funder_empty", detail }));
  assert.ok(!empty.ok && empty.code === "funder_empty" && /run out of tokens/.test(empty.message) && empty.detail === detail);

  // the four messages are different from one another: that was the whole bug
  const messages = new Set([un, cfg, unf, key, empty].map((r) => (r.ok ? "" : r.message)));
  assert.equal(messages.size, 5);

  const net = await requestRegistration("abc", k, "/x", f(502, { code: "network", detail: "RPC 429" }));
  assert.ok(!net.ok && net.code === "network" && net.detail === "RPC 429");
});

test("client: a bare 503 is not guessed to mean 'not configured'; non-JSON answers are said to be what they are", async () => {
  const bare = await requestRegistration("abc", k, "/x", f(503, {}));
  assert.ok(!bare.ok && bare.code === "failed" && !/funder|isn't set up/.test(bare.message));

  const html = (status: number) => (async () => new Response("<!doctype html><title>Service Unavailable</title>", { status, headers: { "content-type": "text/html" } })) as any;
  const platform = await requestRegistration("abc", k, "/x", html(503));
  assert.ok(!platform.ok && platform.code === "unavailable" && /HTTP 503/.test(platform.message) && !/funder|isn't set up/.test(platform.message));

  const missing = await requestRegistration("abc", k, "/x", html(404));
  assert.ok(!missing.ok && missing.code === "unavailable" && /HTTP 404/.test(missing.message) && /\/api\/register isn't being served/.test(missing.detail ?? ""));

  // a site that answers every path with its home page (a single-page-app fallback): 200 but not our function
  const spa = await requestRegistration("abc", k, "/x", html(200));
  assert.ok(!spa.ok && spa.code === "unavailable" && /isn't being served/.test(spa.detail ?? ""));

  // detail is for funder problems only: a taken name or a rate limit never shows server text beyond its own wording
  const taken = await requestRegistration("abc", k, "/x", f(409, { code: "taken", detail: "leak?" }));
  assert.ok(!taken.ok && taken.code === "taken" && taken.detail === undefined);
  const long = await requestRegistration("abc", k, "/x", f(503, { code: "funder_key", detail: "x".repeat(5000) }));
  assert.ok(!long.ok && (long.detail ?? "").length <= 400);
});
