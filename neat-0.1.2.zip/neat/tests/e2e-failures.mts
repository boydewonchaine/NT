// End-to-end, suite 2 of 3: everything that goes WRONG, and the audit of every screen in three viewport/theme setups.
// The point of this suite is that the app tells the truth when things fail: no success shown for a failed payment,
// no name claimed that the chain doesn't confirm, no second payment from a double click or a retry, no secrets leaked.
import { readFileSync, writeFileSync } from "node:fs";
import { OUT, ORIGIN, NEAR, SENT_A, SENT_B, SENT_C, confirmRegistration, createWallet, openSuite, qrImage, scanUpload, startWallet, toReview, typeName, unlock } from "./e2e-lib.mts";
import { audit, focusRing, writeAuditNotes } from "./e2e-audit.mts";
import { createRequest } from "../src/core/payload";
import { generateKeypair, keyFromString, signerFromSeed } from "../src/core/near";
import { open as openVault } from "../src/core/vault";
import { fromBase64Url, toBase64Url, utf8 } from "../src/core/encoding";

const S = await openSuite("failures");
const { chain, post, browser, newCtx, watch, check, shot, state, bal, finish, allowConsole } = S;
// The browser reports HTTP error statuses on fetches as console errors; this suite provokes some of them on purpose.
allowConsole(/Failed to load resource: the server responded with a status of (409|429|503|502|422)/);
allowConsole(/Failed to load resource: net::ERR_INTERNET_DISCONNECTED/);

const stat = () => post("stats") as Promise<{ broadcasts: number; registerCalls: number; log: string[] }>;
const bodyText = (page: any) => page.innerText("main");
const okLog = (from: string, to: string) => chain.log.filter((l: string) => l === `${from}->${to} ok`).length;
const nameInput = 'input[aria-label="Choose your NEAT name"]';

// ===== actors =====
const ctxA = await newCtx(), ctxB = await newCtx();
const alice = await ctxA.newPage(), bob = await ctxB.newPage();
watch(alice, "alice");
watch(bob, "bob");
await createWallet(alice, SENT_A, "alice");
await alice.waitForSelector(".home");
await createWallet(bob, SENT_B, "bob");
await bob.waitForSelector(".home");
await bob.getByRole("button", { name: "Receive", exact: true }).click();
await bob.waitForSelector(".qrcard svg");
const bobQr = `${OUT}/bob-open-qr.png`;
await bob.locator(".qrcard").screenshot({ path: bobQr });
const txCount = async () => ((await state(alice)).txs ?? []).length;
const aliceStart = bal("alice.testnet"), bobStart = bal("bob.testnet");

// =====================================================================================
// A. Payments that do not (or must not) go through
// =====================================================================================

// A1. Back and Cancel at Review
{
  const before = await stat();
  await toReview(alice, bobQr, "0.1");
  await shot(alice, "review");
  await alice.getByRole("button", { name: "Back", exact: true }).click();
  await alice.waitForSelector("text=Paying");
  check("Back from Review returns to the amount screen", /paying/i.test(await bodyText(alice)));
  await alice.fill('input[aria-label="Amount in NEAR"]', "0.1");
  await alice.getByRole("button", { name: "Review" }).click();
  await alice.getByRole("button", { name: "Authorize payment" }).waitFor();
  await alice.getByRole("button", { name: "Cancel" }).click();
  await alice.waitForSelector(".home");
  check("cancelling at Review: nothing signed or broadcast, no record, balances untouched", (await stat()).broadcasts === before.broadcasts && (await txCount()) === 0 && bal("alice.testnet") === aliceStart && bal("bob.testnet") === bobStart);
}

// A2. The wallet's key was revoked on-chain: refused before anything is signed
{
  const before = await stat();
  await toReview(alice, bobQr, "0.1");
  await post("delkey", { id: "alice.testnet" });
  await alice.getByRole("button", { name: "Authorize payment" }).click();
  await alice.waitForSelector("text=Payment not sent.", { timeout: 15000 });
  await shot(alice, "signing-failed");
  const t = await bodyText(alice);
  check("revoked key: refused with the real reason, and no success wording", /not authorized on its account/.test(t) && !/Payment sent|Completed/i.test(t), t.replace(/\n/g, " | ").slice(0, 200));
  check("…nothing was signed, stored or broadcast", (await txCount()) === 0 && (await stat()).broadcasts === before.broadcasts);
  await post("addkey", { id: "alice.testnet" });
  await alice.getByRole("button", { name: "Back to home" }).click();
  await alice.waitForSelector(".home");
}

// A3. Connection lost at the moment of authorizing
{
  const before = await stat();
  await toReview(alice, bobQr, "0.1");
  await ctxA.setOffline(true);
  await alice.getByRole("button", { name: "Authorize payment" }).click();
  await alice.waitForSelector("text=Couldn't connect.", { timeout: 15000 });
  const t = await bodyText(alice);
  check("offline at Authorize: says nothing was signed or sent", /Nothing was signed or sent/.test(t) && !/Payment sent/i.test(t));
  await ctxA.setOffline(false);
  check("…and nothing was stored or broadcast", (await txCount()) === 0 && (await stat()).broadcasts === before.broadcasts);
  await alice.getByRole("button", { name: "Back to home" }).click();
  await alice.waitForSelector(".home");
}

// A4. The balance drops between Review and Authorize: the network rejects it, and the app says exactly that
{
  const aliceBefore = bal("alice.testnet");
  const before = await stat();
  await toReview(alice, bobQr, "1");
  await post("setbalance", { id: "alice.testnet", yocto: (NEAR / 10n).toString() }); // 0.1 NEAR left
  await alice.getByRole("button", { name: "Authorize payment" }).click();
  await alice.waitForSelector("text=Payment not sent.", { timeout: 15000 });
  const t = await bodyText(alice);
  check("balance drained after review: the network's rejection is reported, not a success", /Not enough balance/.test(t) && !/Payment sent|Completed/i.test(t), t.replace(/\n/g, " | ").slice(0, 200));
  const rec = (await state(alice)).txs[0];
  check("…recorded as failed, signed bytes dropped, no fee claimed for a transaction that never ran", rec?.status === "failed" && !rec.signed && !rec.feeActual && chain.log.length === before.log.length);
  await alice.getByRole("button", { name: "View details" }).click();
  await alice.waitForSelector("text=Payment failed");
  const r = await bodyText(alice);
  check("receipt of a rejected payment: Failed, nothing delivered, no fee charged", /Failed/i.test(r) && /Nothing delivered/i.test(r) && !/still charged/i.test(r) && !/Payment sent/i.test(r));
  await alice.getByRole("button", { name: "Done" }).click();
  await alice.waitForSelector(".home");
  await post("setbalance", { id: "alice.testnet", yocto: aliceBefore.toString() });
}

// A5. The recipient disappears: the transfer executes and FAILS on-chain; the fee is still burnt
{
  const preAlice = bal("alice.testnet"), preBob = bal("bob.testnet");
  await toReview(alice, bobQr, "0.2");
  await post("hide", { id: "bob.testnet" });
  await alice.getByRole("button", { name: "Authorize payment" }).click();
  await alice.waitForSelector("text=Payment failed.", { timeout: 30000 });
  await shot(alice, "processing-failed");
  const t = await bodyText(alice);
  check("failed on-chain payment: processing screen says failed, why, and that the fee was still charged", /doesn't exist on testnet/.test(t) && /amount was not delivered/.test(t) && /still charged/.test(t) && !/Payment sent/i.test(t), t.replace(/\n/g, " | ").slice(0, 260));
  await alice.getByRole("button", { name: "View details" }).click();
  await alice.waitForSelector("text=Payment failed");
  await shot(alice, "receipt-failed");
  const r = await bodyText(alice);
  check("failed receipt: Failed stamp, 'Nothing delivered', FINAL evidence, explorer link, no success wording", /Failed/i.test(r) && /Nothing delivered/i.test(r) && /FINAL/.test(r) && !/Payment sent|Completed/i.test(r) && (await alice.locator('a[href*="/txns/"]').count()) === 1);
  const rec = (await state(alice)).txs[0];
  const burnt = preAlice - bal("alice.testnet");
  check("on-chain truth: only the network fee left Alice's account, and it equals the reconciled fee", rec.status === "failed" && burnt > 0n && burnt === BigInt(rec.feeActual) && burnt < NEAR / 100n, `${burnt} vs ${rec.feeActual}`);
  await post("unhide", { id: "bob.testnet" });
  check("…and the recipient received nothing", bal("bob.testnet") === preBob);
  await alice.getByRole("button", { name: "Done" }).click();
  await alice.waitForSelector(".home");
}

// A6. A double click sends exactly one payment, and a standing QR can be paid again
{
  const before = await stat();
  const bobBefore = bal("bob.testnet");
  await toReview(alice, bobQr, "0.1");
  await alice.getByRole("button", { name: "Authorize payment" }).dblclick();
  await alice.waitForSelector("text=Payment sent", { timeout: 30000 });
  check("double-clicking Authorize submits exactly one payment", (await stat()).broadcasts === before.broadcasts + 1 && okLog("alice.testnet", "bob.testnet") === 1);
  await alice.getByRole("button", { name: "Done" }).click();
  await alice.waitForSelector(".home");
  await toReview(alice, bobQr, "0.05");
  await alice.getByRole("button", { name: "Authorize payment" }).click();
  await alice.waitForSelector("text=Payment sent", { timeout: 30000 });
  check("the same standing QR can be paid a second time (only amount requests are single-use)", okLog("alice.testnet", "bob.testnet") === 2 && bal("bob.testnet") - bobBefore === (15n * NEAR) / 100n);
  await alice.getByRole("button", { name: "Done" }).click();
  await alice.waitForSelector(".home");
}

// =====================================================================================
// B. QR codes that must be refused (uploaded at the scanner)
// =====================================================================================
{
  const bobState = await state(bob);
  const bobSigner = await signerFromSeed(await openVault(bobState.vault, SENT_B), keyFromString(bobState.vault.publicKey));
  const aliceState = await state(alice);
  const aliceSigner = await signerFromSeed(await openVault(aliceState.vault, SENT_A), keyFromString(aliceState.vault.publicKey));
  const eve = await generateKeypair();
  const eveSigner = await signerFromSeed(eve.seed, eve.publicKey);
  const valid = await createRequest(bobSigner, "bob.testnet", { amountYocto: NEAR / 10n, fixed: true, note: "lunch" });
  const rawOf = (qr: string) => Buffer.from(fromBase64Url(qr.slice(6)));
  const tampered = (() => { const raw = rawOf(valid.qrText); raw[raw.indexOf(Buffer.from("bob.testnet"))] = 0x78; return "NEAT1." + toBase64Url(raw); })(); // the recipient becomes "xob.testnet"
  const newerVersion = (() => { const raw = rawOf(valid.qrText); raw[0] = 2; return "NEAT1." + toBase64Url(raw); })();
  const cases: { id: string; qr: string; expect: RegExp; why: string }[] = [
    { id: "expired", qr: (await createRequest(bobSigner, "bob.testnet", { amountYocto: NEAR / 10n, expiresInSec: 60, now: Date.now() - 3600_000 })).qrText, expect: /has expired/, why: "a correctly signed but expired request" },
    { id: "retargeted", qr: (await createRequest(eveSigner, "bob.testnet", { amountYocto: NEAR })).qrText, expect: /wasn't issued by the owner of bob\.testnet/, why: "someone else's key claiming Bob's account" },
    { id: "tampered", qr: tampered, expect: /signature is invalid/, why: "the recipient edited after signing" },
    { id: "version", qr: newerVersion, expect: /newer version of NEAT, or for another network/, why: "another version / network" },
    { id: "ghost", qr: (await createRequest(eveSigner, "ghost.testnet", {})).qrText, expect: /ghost\.testnet doesn't exist on testnet/, why: "a signed request for an account that doesn't exist" },
    { id: "damaged", qr: valid.qrText.slice(0, Math.floor(valid.qrText.length / 2)), expect: /damaged or isn't a NEAT payment/, why: "a truncated payload" },
    { id: "foreign-url", qr: "https://example.com/pay?to=bob.testnet&amount=1", expect: /isn't a NEAT payment QR/, why: "a payment link" },
    { id: "bare-account", qr: "bob.testnet", expect: /isn't a NEAT payment QR/, why: "a bare account id" },
    { id: "near-uri", qr: "near:bob.testnet?amount=1", expect: /isn't a NEAT payment QR/, why: "another wallet's URI format" },
    { id: "own", qr: (await createRequest(aliceSigner, "alice.testnet", {})).qrText, expect: /your own QR/, why: "the wallet's own QR" },
  ];
  const before = await stat();
  const txsBefore = await txCount();
  await alice.getByRole("button", { name: "Send", exact: true }).click();
  await alice.waitForSelector("text=Scan to pay");
  let rejected = 0;
  const detail: string[] = [];
  for (const c of cases) {
    const file = `${OUT}/qr-${c.id}.png`;
    await qrImage(browser, c.qr, file);
    await alice.setInputFiles("#qrfile", file);
    try {
      await alice.waitForSelector('[role="alert"]', { timeout: 12000 });
      const msg = await alice.innerText('[role="alert"]');
      const onScan = /Scan to pay/.test(await alice.innerText("h1"));
      if (c.expect.test(msg) && onScan) rejected++;
      else detail.push(`${c.id}: “${msg}” (on scan screen: ${onScan})`);
      if (c.id === "retargeted") await shot(alice, "qr-rejected");
      await alice.getByRole("button", { name: "Scan again" }).click();
    } catch {
      detail.push(`${c.id}: no rejection shown (${(await alice.innerText("main").catch(() => "")).replace(/\n/g, " | ").slice(0, 120)})`);
      break;
    }
  }
  check(`${cases.length} kinds of bad QR are each refused with a specific reason (${cases.map((c) => c.id).join(", ")})`, rejected === cases.length, detail.join(" ; "));
  check("…and none of them started a payment: no transaction was broadcast, signed or recorded", (await stat()).broadcasts === before.broadcasts && (await txCount()) === txsBefore, `broadcasts ${before.broadcasts}→${(await stat()).broadcasts}, records ${txsBefore}→${await txCount()}`);
  // positive control: the scanner is not just rejecting everything
  const validFile = `${OUT}/qr-valid.png`;
  await qrImage(browser, valid.qrText, validFile);
  await alice.setInputFiles("#qrfile", validFile);
  await alice.waitForSelector("text=Paying", { timeout: 15000 });
  const t = await bodyText(alice);
  check("control: a genuine signed request from the same recipient IS accepted", /bob/.test(await alice.innerText("h1")) && /Requested amount/.test(t) && /lunch/.test(t) && (await alice.inputValue('input[aria-label="Amount in NEAR"]')) === "0.1");
  await alice.getByRole("button", { name: "Back", exact: true }).click(); // → scan
  await alice.getByRole("button", { name: "Back", exact: true }).click(); // → home
  await alice.waitForSelector(".home");
}

// =====================================================================================
// C. Name registration that fails, stalls, or races
// =====================================================================================
const actor = async (who: string) => {
  const ctx = await newCtx();
  const page = await ctx.newPage();
  watch(page, who);
  return { ctx, page };
};

// C1. Carol: the registration service isn't configured, then it is
const carol = await actor("carol");
{
  const p = carol.page;
  await p.goto(ORIGIN + "/");
  await p.waitForSelector('input[aria-label="Personal sentence"]');
  await audit(S, p, carol.ctx, "mobile-light · Create wallet");
  await post("funder", { on: false });
  await startWallet(p, SENT_C);
  await audit(S, p, carol.ctx, "mobile-light · Choose your name");
  await typeName(p, "carol");
  await confirmRegistration(p, "carol");
  await p.waitForSelector("text=Not registered", { timeout: 15000 });
  await shot(p, "register-unconfigured");
  const t = await bodyText(p);
  check("registration service not configured: says so plainly and claims no name", /isn't set up on this deployment/.test(t) && !/is registered/i.test(t) && !chain.accounts.has("carol.testnet"), t.replace(/\n/g, " | ").slice(0, 200));
  check("…the wallet stays nameless", (await state(p)).vault.accountId === null);
  await audit(S, p, carol.ctx, "mobile-light · Name not registered");
  await post("funder", { on: true });
  await p.getByRole("button", { name: "Try again" }).click();
  await p.waitForSelector(".home", { timeout: 30000 });
  check("Try again registers the name once the service is available (and only then)", chain.accounts.has("carol.testnet") && (await state(p)).vault.accountId === "carol.testnet");
}

// C1b. Hana: a deployment being set up, one mistake at a time. The first real deployment answered every one of these with
//      the same vague "isn't set up" line, so the person running it couldn't tell what to fix. Each has its own words now,
//      and the same screen carries on to a real registration once the last mistake is fixed.
{
  const { page: p } = await actor("hana");
  const readyCheck = async () => (await fetch(ORIGIN + "/api/register")).json() as Promise<any>;
  const before = await stat();
  const fundBefore = bal("neat-funder.testnet");
  const FUND = "neat-funder.testnet";
  await post("env", { unset: ["NEAT_FUNDER_KEY"] }); // the dashboard has the id but the key was never added
  await startWallet(p, SENT_C);
  await typeName(p, "hana");
  await confirmRegistration(p, "hana");
  await p.waitForSelector("text=Not registered", { timeout: 15000 });
  const sees = async (re: RegExp, what: string) => {
    try {
      await p.waitForFunction((src: string) => new RegExp(src, "i").test(document.body.innerText.replace(/\s+/g, " ")), re.source, { timeout: 15000 });
      return true;
    } catch {
      console.log(`  (waiting for: ${what}; saw: ${(await bodyText(p)).replace(/\s+/g, " ").slice(0, 260)})`);
      return false;
    }
  };
  const tryAgain = async () => { await p.getByRole("button", { name: "Try again" }).click(); };
  const text = async () => (await bodyText(p)).replace(/\s+/g, " ");

  check("a missing key is named: 'Missing on the server: NEAT_FUNDER_KEY' (not just 'not configured')", (await sees(/isn't set up on this deployment yet/, "not set up")) && (await sees(/Missing on the server: NEAT_FUNDER_KEY\./, "missing key")), await text());
  check("…with the fix for whoever runs the deployment, in a smaller line under the message", await sees(/Missing on the server: NEAT_FUNDER_KEY\. Add it in the host's environment variables, then redeploy\./, "operator note") && (await p.locator('[role="alert"] .note').count()) === 1);
  check("…the failed name is shown as a name (the .testnet suffix is styled like the picker's), not as plain text", (await p.locator("h1 .sfx").count()) === 1 && /hana/i.test(await p.innerText("h1")));
  await shot(p, "register-missing-key");
  const r0 = await readyCheck();
  check("the readiness link says the same, without registering anything", r0.ready === false && r0.code === "unconfigured" && JSON.stringify(r0.missing) === '["NEAT_FUNDER_KEY"]', JSON.stringify(r0));

  await post("env", { set: { NEAT_FUNDER_KEY: "this is not a key" } }); // something was pasted, but it isn't the key
  await tryAgain();
  check("a value that isn't a key is called invalid, naming the setting", (await sees(/set up incorrectly/, "invalid key")) && (await sees(/NEAT_FUNDER_KEY must be the whole value/, "invalid key note")), await text());
  check("…and the secret that was entered is not shown back", !/this is not a key/.test(await text()));

  await post("funder", { on: true }); // all three settings, correct
  await post("hide", { id: FUND }); // …but the account was never given tokens: it doesn't exist on the network yet
  await tryAgain();
  check("a funder that was never funded says so (it doesn't exist yet), and what to do", (await sees(/hasn't been given any testnet tokens/, "unfunded")) && (await sees(/never received any testnet NEAR.*Send it testnet NEAR first/, "unfunded note")), await text());
  const r1 = await readyCheck();
  check("…the readiness link agrees", r1.ready === false && r1.code === "funder_unfunded" && r1.funder === FUND, JSON.stringify(r1));
  await post("unhide", { id: FUND });

  await post("delkey", { id: FUND }); // the account exists, but the key we hold is not on it
  await tryAgain();
  check("a key that isn't on the account is a key problem, not a 'not configured'", (await sees(/funder key doesn't work for the funder account/, "wrong key")) && (await sees(/isn't registered on account neat-funder\.testnet/, "wrong key note")), await text());
  await post("addkey", { id: FUND });

  const { was } = await post("drain-funder");
  await tryAgain();
  check("an empty funder states what it holds and what a name costs", (await sees(/run out of tokens/, "empty")) && (await sees(/holds 0\.0001 NEAR; each name needs 5 NEAR plus network fees/, "empty note")), await text());
  await post("drain-funder", { restore: was });

  const s1 = await stat();
  check("none of those attempts sent anything or created a name; the funder spent nothing", s1.broadcasts === before.broadcasts && !chain.accounts.has("hana.testnet") && bal("neat-funder.testnet") === fundBefore);

  await tryAgain();
  await p.waitForSelector(".home", { timeout: 30000 });
  const r2 = await readyCheck();
  check("with every setting right, the same screen registers the name for real, and the readiness link says ready", chain.accounts.has("hana.testnet") && (await state(p)).vault.accountId === "hana.testnet" && r2.ready === true && r2.funder === FUND && typeof r2.balance === "string", JSON.stringify(r2));
  check("the readiness link never contains a secret", !/ed25519:[1-9A-HJ-NP-Za-km-z]{60,}/.test(JSON.stringify([r0, r1, r2])));
}

// C2. Dave: the network accepts the registration but it fails when executed
{
  const { page: p, ctx } = await actor("dave");
  await post("set", { failRegistrations: true });
  await startWallet(p, SENT_C);
  await typeName(p, "dave");
  await confirmRegistration(p, "dave");
  await p.waitForSelector("text=Failed transaction", { timeout: 30000 });
  await shot(p, "register-failed-onchain");
  const t = await bodyText(p);
  check("on-chain registration failure is reported with a retry, and no name is shown as registered", /rejected the registration/.test(t) && /Try again/.test(t) && !/is registered/i.test(t) && !chain.accounts.has("dave.testnet"), t.replace(/\n/g, " | ").slice(0, 220));
  check("…it carries the failed transaction as evidence, and nothing stays 'pending'", (await p.locator('a[href*="/txns/"]').count()) === 1 && (await state(p)).pending === undefined && (await state(p)).vault.accountId === null);
  await audit(S, p, ctx, "mobile-light · Registration failed on-chain");
  await post("set", { failRegistrations: false });
  await p.getByRole("button", { name: "Try again" }).click();
  await p.waitForSelector(".home", { timeout: 30000 });
  check("retry after an on-chain failure succeeds with a fresh transaction", chain.accounts.has("dave.testnet") && (await state(p)).vault.accountId === "dave.testnet");
}

// C3. Erin: the name is taken between the availability check and the registration
{
  const { page: p } = await actor("erin");
  await startWallet(p, SENT_C);
  await typeName(p, "erin");
  chain.addAccount("erin.testnet", 1n); // someone else registers it first
  const before = await stat();
  await p.getByRole("button", { name: "Continue" }).click();
  await p.waitForSelector("text=Register erin.testnet?");
  await p.getByRole("button", { name: "Register name" }).click();
  await p.waitForSelector("text=just taken", { timeout: 20000 });
  const t = await bodyText(p);
  check("name taken in the meantime: refused, nothing registered, the funder spent nothing", /just taken/.test(t) && (await stat()).broadcasts === before.broadcasts && (await state(p)).vault.accountId === null);
  await p.getByRole("button", { name: "Choose another name" }).click();
  await typeName(p, "erin-2");
  await confirmRegistration(p, "erin-2");
  await p.waitForSelector(".home", { timeout: 30000 });
  check("…and the person can pick another name and carry on", chain.accounts.has("erin-2.testnet") && (await state(p)).vault.accountId === "erin-2.testnet");
}

// C4. Frank: NEAT's funder account has run dry. The message must blame the funder, not the user.
{
  const { page: p } = await actor("frank");
  const { was } = await post("drain-funder");
  await startWallet(p, SENT_C);
  await typeName(p, "frank");
  await confirmRegistration(p, "frank");
  await p.waitForSelector("text=run out of tokens", { timeout: 20000 });
  const t = await bodyText(p);
  check("funder out of tokens: says the funder is empty (not the user's balance) and offers a retry", /NEAT's testnet funder has run out of tokens/.test(t) && !/your (balance|account)/i.test(t) && /Try again/.test(t) && !chain.accounts.has("frank.testnet"));
  await post("drain-funder", { restore: was });
  await p.getByRole("button", { name: "Try again" }).click();
  await p.waitForSelector(".home", { timeout: 30000 });
  check("…and registers once the funder is topped up", chain.accounts.has("frank.testnet"));
}

// C5. Gina: submitted but never confirmed. Stays pending across a reload, is never re-sent, and is only
//     claimed once the chain really shows the account under her key.
{
  const { page: p, ctx } = await actor("gina");
  await post("set", { dropNext: 1 }); // the node acknowledges the funder's transaction and then loses it
  await startWallet(p, SENT_C);
  await typeName(p, "gina");
  await confirmRegistration(p, "gina");
  await p.waitForSelector("text=Submitted transaction", { timeout: 15000 });
  await shot(p, "register-waiting");
  const w = await bodyText(p);
  check("while the network hasn't confirmed: 'Registering', with the transaction, and no name claimed", /registering/i.test(w) && !/is registered/i.test(w) && !chain.accounts.has("gina.testnet"));
  await audit(S, p, ctx, "mobile-light · Registering");
  const calls = (await stat()).registerCalls;
  await p.reload();
  await p.waitForSelector('input[aria-label="Your personal sentence"]');
  await p.fill('input[aria-label="Your personal sentence"]', SENT_C);
  await p.getByRole("button", { name: "Unlock" }).click();
  await p.waitForSelector("text=Not confirmed yet", { timeout: 60000 });
  await shot(p, "register-not-confirmed");
  const t = await bodyText(p);
  check("after a reload: still pending, says nothing is registered, and no second request was sent", /Nothing is registered until it does/.test(t) && (await stat()).registerCalls === calls && !chain.accounts.has("gina.testnet") && (await state(p)).vault.accountId === null);
  await audit(S, p, ctx, "mobile-light · Registration not confirmed yet");
  chain.addAccount("gina.testnet", 5n, keyFromString((await state(p)).vault.publicKey)); // the network catches up
  await p.getByRole("button", { name: "Check again" }).click();
  await p.waitForSelector(".home", { timeout: 40000 });
  check("when the chain finally shows the account under her key, the name is shown, and only then", (await state(p)).vault.accountId === "gina.testnet" && (await stat()).registerCalls === calls);
}

// C6. Hank: the name exists on-chain under his key but this device never recorded it (a crash between the
//     network confirming and the app saving). He can reclaim it. Nobody can claim someone else's.
{
  const { page: p } = await actor("hank");
  await startWallet(p, SENT_C);
  await p.fill(nameInput, "alice");
  await p.waitForSelector("text=alice.testnet is taken");
  check("a name that belongs to someone else's key can't be claimed", await p.getByRole("button", { name: "Continue" }).isDisabled());
  chain.addAccount("hank.testnet", 5n, keyFromString((await state(p)).vault.publicKey));
  await p.fill(nameInput, "hank");
  await p.waitForSelector("text=already belongs to this wallet's key");
  await shot(p, "name-reclaim");
  const callsBefore = (await stat()).registerCalls, bcBefore = (await stat()).broadcasts;
  await p.getByRole("button", { name: "Use this name" }).click();
  await p.waitForSelector(".home", { timeout: 20000 });
  check("a name registered for this key but never recorded here can be reclaimed, after the chain confirms it again", (await state(p)).vault.accountId === "hank.testnet");
  check("…reclaiming sent no registration request and spent nothing from the funder", (await stat()).registerCalls === callsBefore && (await stat()).broadcasts === bcBefore);
}

// =====================================================================================
// D. Forgot the sentence → erase (explicit, typed confirmation); the chain account is untouched
// =====================================================================================
{
  const p = carol.page;
  await p.waitForSelector(".home");
  await p.getByRole("button", { name: "Lock" }).click();
  await p.waitForSelector('input[aria-label="Your personal sentence"]');
  await audit(S, p, carol.ctx, "mobile-light · Unlock");
  await p.getByRole("button", { name: "Forgot your sentence?" }).click();
  const dlg = p.getByRole("dialog");
  await dlg.waitFor();
  await shot(p, "forgot-sheet");
  const ft = await dlg.innerText();
  check("'Forgot your sentence?' is honest: no reset, the backup won't help, funds stay on the network", /can't reset or recover/.test(ft) && /same sentence, so it won't help/.test(ft) && /stay on NEAR Testnet/.test(ft) && /never create a new wallet for you/.test(ft));
  await audit(S, p, carol.ctx, "mobile-light · Forgot sheet");
  check("no replacement wallet was created by reaching this screen", (await state(p)).vault?.accountId === "carol.testnet");
  await dlg.getByRole("button", { name: "Erase this wallet…" }).click();
  await p.fill('input[aria-label="Type carol to confirm"]', "wrong");
  check("erasing stays disabled until the name is typed exactly", await p.getByRole("button", { name: "Erase wallet" }).isDisabled());
  await p.fill('input[aria-label="Type carol to confirm"]', "carol");
  check("…and a backup can be downloaded first", (await p.getByRole("button", { name: "Download encrypted backup first" }).count()) === 1 && !(await p.getByRole("button", { name: "Erase wallet" }).isDisabled()));
  await shot(p, "erase-sheet");
  await p.getByRole("button", { name: "Erase wallet" }).click();
  await p.waitForSelector("text=Create your wallet");
  const after = await state(p);
  check("after erasing: back to Create, nothing left in storage, and the on-chain account is untouched", after.vault === null && (after.txs ?? []).length === 0 && chain.accounts.has("carol.testnet") && chain.accounts.get("carol.testnet")!.keys.size === 1);
}

// =====================================================================================
// E. Restoring: bad files, a tampered file, and a file that lies about its name
// =====================================================================================
{
  await bob.goto(ORIGIN + "/"); // this page has been idle for minutes (auto-lock): come back the way a person does
  await unlock(bob, SENT_B);
  await bob.getByRole("button", { name: "Settings" }).click();
  const [dl] = await Promise.all([bob.waitForEvent("download"), bob.getByRole("button", { name: "Download encrypted backup" }).click()]);
  const good = `${OUT}/bob-good.neat`;
  await dl.saveAs(good);
  const bk = JSON.parse(readFileSync(good, "utf8"));
  const flip = (s: string) => s.slice(0, 12) + (s[12] === "A" ? "B" : "A") + s.slice(13);
  const files: Record<string, string> = {
    notNeat: JSON.stringify({ hello: "world" }),
    weakKdf: JSON.stringify({ ...bk, vault: { ...bk.vault, iter: 1000 } }),
    tampered: JSON.stringify({ ...bk, vault: { ...bk.vault, ct: flip(bk.vault.ct) } }),
    renamed: JSON.stringify({ ...bk, vault: { ...bk.vault, accountId: "alice.testnet" } }), // claims Alice's account, Bob's key
  };
  for (const [k, v] of Object.entries(files)) writeFileSync(`${OUT}/bk-${k}.neat`, v);
  const restoreWith = async (file: string) => {
    const { page: p, ctx } = await actor("restore-" + file);
    await p.goto(ORIGIN + "/");
    await p.getByRole("button", { name: "Restore from a backup file" }).click();
    await p.setInputFiles("#bk", `${OUT}/bk-${file}.neat`);
    return { p, ctx };
  };
  {
    const { p, ctx } = await restoreWith("notNeat");
    await p.waitForSelector("text=isn't a NEAT backup file");
    await audit(S, p, ctx, "mobile-light · Restore (bad file)");
    check("a file that isn't a NEAT backup is refused", await p.getByRole("button", { name: "Restore wallet" }).isDisabled());
  }
  {
    const { p } = await restoreWith("weakKdf");
    await p.waitForSelector("text=isn't a NEAT backup file");
    check("a backup downgraded to a weak key-derivation setting is refused", true);
  }
  {
    const { p } = await restoreWith("tampered");
    await p.waitForSelector("text=Backup found");
    await p.fill('input[aria-label="Your sentence"]', SENT_B);
    await p.getByRole("button", { name: "Restore wallet" }).click();
    await p.waitForSelector("text=doesn't match this backup");
    check("a tampered backup does not decrypt even with the right sentence, and creates nothing", (await state(p)).vault == null);
  }
  {
    const { p } = await restoreWith("renamed");
    await p.waitForSelector("text=Backup found");
    check("the file's claimed name is not displayed before the chain confirms it", !/alice/i.test(await bodyText(p)));
    await p.fill('input[aria-label="Your sentence"]', SENT_B);
    await p.getByRole("button", { name: "Restore wallet" }).click();
    await p.waitForSelector("text=Choose your name", { timeout: 20000 });
    const s = await state(p);
    check("a backup claiming someone else's name restores the key but NOT the name (the chain doesn't agree)", s.vault.accountId === null && s.vault.publicKey === bk.vault.publicKey && !/alice/i.test(await p.innerText("h1")));
  }
}

// =====================================================================================
// F. Audit every screen in three setups: phone/light, desktop/dark/reduced-motion, small phone/light
// =====================================================================================
async function tour(page: any, ctx: any, tag: string) {
  const A = (screen: string) => audit(S, page, ctx, `${tag} · ${screen}`);
  await A("Home");
  await page.getByRole("button", { name: "Receive", exact: true }).click();
  await page.waitForSelector(".qrcard svg");
  await A("Receive · my QR");
  await page.getByRole("tab", { name: "Request amount" }).click();
  await page.waitForSelector('input[aria-label="Amount in NEAR"]');
  await A("Receive · request form");
  await page.fill('input[aria-label="Amount in NEAR"]', "0.25");
  await page.fill('input[aria-label="Note"]', "audit");
  await page.getByRole("button", { name: "Create request" }).click();
  await page.waitForSelector("text=Fixed amount");
  await A("Receive · amount request");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page.waitForSelector(".home");
  await scanUpload(page, bobQr);
  await page.waitForSelector("text=Paying", { timeout: 15000 });
  await A("Amount");
  await page.fill('input[aria-label="Amount in NEAR"]', "0.1");
  await page.getByRole("button", { name: "Review" }).click();
  await page.getByRole("button", { name: "Authorize payment" }).waitFor();
  await A("Review");
  await page.getByRole("button", { name: "Cancel" }).click();
  await page.waitForSelector(".home");
  await page.getByRole("button", { name: "Send", exact: true }).click();
  await page.waitForSelector("text=Scan to pay");
  await A("Scan");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page.waitForSelector(".home");
  await page.getByRole("button", { name: "See all" }).click();
  await page.waitForSelector("text=Activity");
  await page.waitForSelector(".item");
  await A("Activity · payments");
  await page.locator(".item").filter({ has: page.locator("small", { hasText: /^NEAR$/ }) }).first().click();
  await page.waitForSelector("text=Evidence");
  await A("Receipt · completed");
  await page.getByRole("button", { name: "Done" }).click();
  await page.waitForSelector("text=Activity");
  await page.locator(".item:has(.chip.bad)").first().click();
  await page.waitForSelector("text=Evidence");
  await A("Receipt · failed");
  await page.getByRole("button", { name: "Done" }).click();
  await page.getByRole("tab", { name: "Requests" }).click();
  await A("Activity · requests");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page.waitForSelector(".home");
  await page.getByRole("button", { name: "Settings" }).click();
  await page.waitForSelector("text=Danger zone");
  await A("Settings");
  await page.getByRole("button", { name: "How your sentence works" }).click();
  await page.getByRole("dialog").waitFor();
  await A("Sheet · how your sentence works");
  await page.keyboard.press("Escape");
  await page.getByRole("button", { name: "Back", exact: true }).click();
  await page.waitForSelector(".home");
  await page.getByRole("button", { name: "Lock" }).click();
  await page.waitForSelector('input[aria-label="Your personal sentence"]');
  await A("Unlock");
}

// F1: phone, light (Alice's own page; it may have auto-locked while the registration scenarios ran)
await alice.goto(ORIGIN + "/");
await unlock(alice, SENT_A);
await tour(alice, ctxA, "mobile-light");
await focusRing(S, alice, "Unlock (mobile-light)");

// F2/F3: other setups, signed in with a copy of Alice's wallet (same encrypted storage, her sentence)
const aliceStorage = await ctxA.storageState();
for (const cfg of [
  { tag: "desktop-dark-reduced-motion", opts: { viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1, colorScheme: "dark", reducedMotion: "reduce" } },
  { tag: "small-phone-320", opts: { viewport: { width: 320, height: 568 }, deviceScaleFactor: 2, colorScheme: "light" } },
]) {
  const ctx = await newCtx({ ...cfg.opts, storageState: aliceStorage });
  const p = await ctx.newPage();
  watch(p, cfg.tag);
  await p.goto(ORIGIN + "/");
  await p.waitForSelector('input[aria-label="Your personal sentence"]');
  await shot(p, `${cfg.tag}-unlock`);
  await audit(S, p, ctx, `${cfg.tag} · Unlock`);
  await unlock(p, SENT_A);
  await shot(p, `${cfg.tag}-home`);
  await tour(p, ctx, cfg.tag);
  await focusRing(S, p, `Unlock (${cfg.tag})`);
  // first-run screens in this setup
  const fresh = await newCtx(cfg.opts);
  const fp = await fresh.newPage();
  watch(fp, cfg.tag + "-fresh");
  await fp.goto(ORIGIN + "/");
  await fp.waitForSelector('input[aria-label="Personal sentence"]');
  await shot(fp, `${cfg.tag}-create`);
  await audit(S, fp, fresh, `${cfg.tag} · Create wallet`);
  await fp.getByRole("button", { name: "How it works" }).click();
  await fp.getByRole("dialog").waitFor();
  await audit(S, fp, fresh, `${cfg.tag} · Sheet · how your sentence works`);
  await fp.keyboard.press("Escape");
  await fp.getByRole("button", { name: "Restore from a backup file" }).click();
  await fp.waitForSelector("text=Restore a wallet");
  await audit(S, fp, fresh, `${cfg.tag} · Restore`);
}
console.log(`audit notes (soft findings, see audit-notes.json): ${writeAuditNotes()}`);

await finish();
