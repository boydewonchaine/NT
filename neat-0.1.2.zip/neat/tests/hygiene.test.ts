// Static rules about WHAT THE CODE IS ALLOWED TO DO, checked on the syntax tree (so a mention in a comment or in a
// string can't hide or fake a use). These are the directive's hard rules turned into tests that fail the build:
// no copy/paste affordances, no logging (recovery material must never reach a console), no dynamic code, storage and
// network only through the modules that are meant to touch them, NEAR Testnet only, no external wallet connectors.
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { readFileSync, readdirSync, statSync, existsSync } from "node:fs";
import { join, relative } from "node:path";

const require = createRequire(import.meta.url);
let ts: any = null;
for (const p of ["typescript", process.env.TYPESCRIPT_PATH ?? "/home/claude/.npm-global/lib/node_modules/typescript"]) {
  try { ts = require(p); break; } catch { /* try next */ }
}
const skip = !ts && "typescript is not installed (npm install)";

const root = join(import.meta.dirname ?? ".", "..");
const walk = (dir: string): string[] => readdirSync(dir).flatMap((n) => { const p = join(dir, n); return statSync(p).isDirectory() ? walk(p) : p.endsWith(".ts") ? [p] : []; });
const files = ["src", "api"].flatMap((d) => (existsSync(join(root, d)) ? walk(join(root, d)) : []));
const rel = (f: string) => relative(root, f).replace(/\\/g, "/");

type Hit = { file: string; line: number; what: string };

/** Walk every source file's syntax tree; `visit` returns a description for each violation it finds. */
function scan(visit: (n: any, file: string) => string | undefined): Hit[] {
  const out: Hit[] = [];
  for (const f of files) {
    const sf = ts.createSourceFile(f, readFileSync(f, "utf8"), ts.ScriptTarget.ES2022, true);
    const go = (n: any) => {
      const what = visit(n, rel(f));
      if (what) out.push({ file: rel(f), line: sf.getLineAndCharacterOfPosition(n.getStart()).line + 1, what });
      ts.forEachChild(n, go);
    };
    go(sf);
  }
  return out;
}
const show = (hits: Hit[]) => hits.map((h) => `${h.file}:${h.line} ${h.what}`).join("\n");
const isIdent = (n: any, name: string) => n.kind === ts.SyntaxKind.Identifier && n.text === name;

test("the scan really sees the project's source", { skip }, () => {
  assert.ok(files.length >= 20, `only ${files.length} files found`);
  assert.ok(files.some((f) => rel(f) === "src/core/vault.ts") && files.some((f) => rel(f) === "api/register.ts"));
  // and it can see what it is looking for: a deliberate violation in a snippet is found
  const sf = ts.createSourceFile("x.ts", "console.log(1); navigator.clipboard.writeText('x'); eval('1')", ts.ScriptTarget.ES2022, true);
  let seen = 0;
  const go = (n: any) => { if (isIdent(n, "console") || isIdent(n, "clipboard") || isIdent(n, "eval")) seen++; ts.forEachChild(n, go); };
  go(sf);
  assert.equal(seen, 3);
});

test("nothing is ever logged (recovery material can't leak into a console)", { skip }, () => {
  const hits = scan((n) => (isIdent(n, "console") ? "uses console" : n.kind === ts.SyntaxKind.DebuggerStatement ? "debugger statement" : undefined));
  assert.equal(hits.length, 0, show(hits));
});

test("no copy / paste / clipboard capability exists in the app", { skip }, () => {
  const bad = new Set(["clipboard", "execCommand", "writeText", "readText", "onpaste", "oncopy", "oncut", "ClipboardItem"]);
  const hits = scan((n) => {
    if (n.kind === ts.SyntaxKind.Identifier && bad.has(n.text)) return `uses ${n.text}`;
    if (n.kind === ts.SyntaxKind.StringLiteral || n.kind === ts.SyntaxKind.NoSubstitutionTemplateLiteral) {
      if (["paste", "copy", "cut"].includes(n.text)) return `event name "${n.text}"`;
      if (/\b(copy|paste)\b/i.test(n.text) && !/^\s*$/.test(n.text)) return `UI/text mentions "${n.text.slice(0, 60)}"`;
    }
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
});

test("no dynamic code: no eval, no Function constructor, no document.write, markup injection only in dom.ts", { skip }, () => {
  const hits = scan((n, file) => {
    if (n.kind === ts.SyntaxKind.CallExpression && isIdent(n.expression, "eval")) return "eval()";
    if (n.kind === ts.SyntaxKind.NewExpression && isIdent(n.expression, "Function")) return "new Function()";
    if (n.kind === ts.SyntaxKind.PropertyAccessExpression) {
      const name = n.name.text;
      if (name === "write" && isIdent(n.expression, "document")) return "document.write";
      if (["innerHTML", "outerHTML", "insertAdjacentHTML"].includes(name) && file !== "src/ui/dom.ts") return `${name} outside dom.ts`;
    }
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
});

test("browser storage is only touched by the store (and the explicit erase flow); no IndexedDB, cookies or session storage", { skip }, () => {
  const allowed = new Set(["src/core/store.ts", "src/ui/views-auth.ts"]);
  const hits = scan((n, file) => {
    if (n.kind !== ts.SyntaxKind.Identifier) return undefined;
    if (["localStorage"].includes(n.text) && !allowed.has(file)) return `${n.text} outside the store`;
    if (["sessionStorage", "indexedDB", "openDatabase"].includes(n.text)) return `uses ${n.text}`;
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
  const cookie = scan((n) => (n.kind === ts.SyntaxKind.PropertyAccessExpression && n.name.text === "cookie" ? "uses document.cookie" : undefined));
  assert.equal(cookie.length, 0, show(cookie));
});

test("the network is only reached through rpc, identity (registration), history (index) and the QR-less helpers", { skip }, () => {
  const allowed = new Set(["src/core/rpc.ts", "src/core/identity.ts", "src/core/history.ts"]);
  const hits = scan((n, file) => {
    if (n.kind === ts.SyntaxKind.Identifier && ["fetch", "XMLHttpRequest", "WebSocket", "EventSource", "sendBeacon"].includes(n.text) && !allowed.has(file)) return `uses ${n.text} outside the network modules`;
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
});

test("NEAR Testnet only: no mainnet endpoint, account suffix or network name anywhere in the code", { skip }, () => {
  const hits = scan((n) => {
    if (n.kind !== ts.SyntaxKind.StringLiteral && n.kind !== ts.SyntaxKind.NoSubstitutionTemplateLiteral && n.kind !== ts.SyntaxKind.TemplateHead) return undefined;
    const t: string = n.text ?? "";
    if (/mainnet|\.near\b|near\.org\/(?!testnet)|rpc\.mainnet|nearblocks\.io(?<!testnet\.nearblocks\.io)(?<!api-testnet\.nearblocks\.io)/i.test(t) && !/testnet/i.test(t)) return `mentions a non-testnet network: ${t.slice(0, 70)}`;
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
});

test("all network endpoints are https and no wallet-connect / external signer library is referenced", { skip }, () => {
  const hits = scan((n) => {
    if (n.kind !== ts.SyntaxKind.StringLiteral && n.kind !== ts.SyntaxKind.NoSubstitutionTemplateLiteral) return undefined;
    const t: string = n.text;
    if (/^http:\/\//i.test(t) && t !== "http://www.w3.org/2000/svg" && !/^http:\/\/mock/.test(t)) return `plain-http URL: ${t}`;
    if (/walletconnect|wallet-selector|near-api-js|@near-|meteor|mynearwallet|sender\.org|ledger|metamask|web3modal/i.test(t)) return `external wallet / signer reference: ${t.slice(0, 60)}`;
    return undefined;
  });
  assert.equal(hits.length, 0, show(hits));
  const imports = scan((n) => (n.kind === ts.SyntaxKind.ImportDeclaration && !/^\.{1,2}\//.test(n.moduleSpecifier.text) ? `non-relative import "${n.moduleSpecifier.text}"` : undefined));
  assert.equal(imports.length, 0, "the app has no runtime dependencies:\n" + show(imports));
});

test("sharing is limited to a QR IMAGE: no text, url or account is ever passed to the share sheet", { skip }, () => {
  const hits = scan((n) => {
    if (n.kind !== ts.SyntaxKind.CallExpression || n.expression.kind !== ts.SyntaxKind.PropertyAccessExpression || n.expression.name.text !== "share") return undefined;
    const arg = n.arguments[0];
    if (!arg || arg.kind !== ts.SyntaxKind.ObjectLiteralExpression) return "navigator.share with a non-literal argument";
    const keys = arg.properties.map((p: any) => p.name?.text);
    return keys.includes("text") || keys.includes("url") ? `navigator.share passes ${keys.join(", ")}` : keys.includes("files") ? undefined : "navigator.share without files";
  });
  assert.equal(hits.length, 0, show(hits));
});

test("the production bundle (when built) has no console calls, no eval and no clipboard code", () => {
  const dir = join(root, "dist", "assets");
  if (!existsSync(dir)) return; // not built yet: the source rules above are the primary guard
  for (const f of readdirSync(dir).filter((n) => n.endsWith(".js"))) {
    const js = readFileSync(join(dir, f), "utf8");
    assert.ok(!/\bconsole\s*\.\s*(log|info|debug|warn|error|trace|dir)\b/.test(js), `console call in ${f}`);
    assert.ok(!/\beval\s*\(|new Function\s*\(/.test(js), `dynamic code in ${f}`);
    assert.ok(!/navigator\.clipboard|execCommand/.test(js), `clipboard code in ${f}`);
  }
});
