#!/usr/bin/env python3
"""Make a short YUV4MPEG2 clip of a QR code on a table, for Chromium's fake camera
(--use-file-for-fake-video-capture). Used by the end-to-end test to exercise the LIVE scanning path.

  fake_camera.py <qr.png | -> <out.y4m>      ("-" = an empty table: a scene with nothing to scan)
"""
import sys

import numpy as np
from PIL import Image

src, out = sys.argv[1], sys.argv[2]
W, H, N = 640, 480, 24
side = 340
canvas = Image.new("L", (W, H), 214)  # light grey "table"
if src != "-":
    qr = Image.open(src).convert("L").resize((side, side), Image.NEAREST)  # NEAREST keeps module edges crisp
    canvas.paste(qr, ((W - side) // 2, (H - side) // 2))
y = np.asarray(canvas, dtype=np.uint8)
chroma = np.full((H // 2, W // 2), 128, dtype=np.uint8)  # neutral colour
with open(out, "wb") as f:
    f.write(f"YUV4MPEG2 W{W} H{H} F10:1 Ip A1:1 C420jpeg\n".encode())
    for i in range(N):
        dx, dy = int(3 * np.sin(i / 3)), int(3 * np.cos(i / 4))  # a few pixels of hand-held drift
        frame = np.roll(np.roll(y, dx, axis=1), dy, axis=0)
        f.write(b"FRAME\n" + frame.tobytes() + chroma.tobytes() + chroma.tobytes())
print("ok")
