// Independent-implementation checks for the pieces whose compatibility with the real NEAR network we cannot
// test from a sandbox: Ed25519 via WebCrypto must produce exactly the signatures NEAR validators expect.
// tweetnacl is an unrelated, widely deployed Ed25519 implementation; Ed25519 is deterministic (RFC 8032), so
// identical bytes are required, not merely "verifies".
import test from "node:test";
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { base58Encode, utf8 } from "../src/core/encoding";
import { generateKeypair, keyFromString, keyToString, parseSecretKey, signerFromSeed, signTransaction, verifySignature } from "../src/core/near";

const require = createRequire(import.meta.url);
let nacl: any = null;
for (const p of ["tweetnacl", process.env.TWEETNACL_PATH ?? "/opt/npm-tools/node_modules/tweetnacl"]) {
  try { nacl = require(p); break; } catch { /* try next */ }
}
const skip = !nacl && "tweetnacl is not installed (npm install)";

test("Ed25519: WebCrypto keys and signatures are byte-identical to tweetnacl's", { skip }, async () => {
  for (let i = 0; i < 25; i++) {
    const { seed, publicKey } = await generateKeypair();
    const kp = nacl.sign.keyPair.fromSeed(seed);
    assert.deepEqual(new Uint8Array(kp.publicKey), publicKey, "seed → public key");
    const signer = await signerFromSeed(seed, publicKey);
    const msg = crypto.getRandomValues(new Uint8Array(1 + i * 13));
    const mine = await signer.sign(msg);
    const theirs = new Uint8Array(nacl.sign.detached(msg, kp.secretKey));
    assert.deepEqual(mine, theirs, "signature bytes");
    assert.ok(nacl.sign.detached.verify(msg, mine, publicKey));
    assert.ok(await verifySignature(publicKey, msg, theirs));
    assert.equal(await verifySignature(publicKey, msg, new Uint8Array(64)), false);
  }
});

test("NEAR key strings: ed25519:<base58> public keys and 64-byte secret keys are tweetnacl-compatible", { skip }, async () => {
  const kp = nacl.sign.keyPair();
  const pubStr = "ed25519:" + base58Encode(kp.publicKey);
  assert.deepEqual(keyFromString(pubStr), new Uint8Array(kp.publicKey));
  assert.equal(keyToString(new Uint8Array(kp.publicKey)), pubStr);
  // NEAR serialises a secret key as base58(seed ‖ public key), which is exactly tweetnacl's secretKey layout
  const secretStr = "ed25519:" + base58Encode(kp.secretKey);
  const parsed = parseSecretKey(secretStr);
  assert.deepEqual(parsed.seed, new Uint8Array(kp.secretKey.slice(0, 32)));
  assert.deepEqual(parsed.publicKey, new Uint8Array(kp.publicKey));
});

test("a signed NEAR transaction verifies under tweetnacl over sha256(borsh(tx)), as validators check it", { skip }, async () => {
  const { seed, publicKey } = await generateKeypair();
  const signer = await signerFromSeed(seed, publicKey);
  const tx = { signerId: "alice.testnet", publicKey, nonce: 42n, receiverId: "bob.testnet", blockHash: new Uint8Array(32).fill(5), actions: [{ type: "transfer" as const, deposit: 10n ** 24n }] };
  const s = await signTransaction(tx, signer);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", s.txBytes));
  assert.ok(nacl.sign.detached.verify(digest, s.signature, publicKey));
  // wire layout of the signed transaction: borsh(tx) ‖ 0x00 (ed25519) ‖ 64-byte signature
  assert.equal(s.bytes.length, s.txBytes.length + 1 + 64);
  assert.equal(s.bytes[s.txBytes.length], 0);
  assert.deepEqual(s.bytes.slice(s.txBytes.length + 1), s.signature);
  // the hash NEAR reports for a transaction is base58(sha256(borsh(tx)))
  assert.equal(s.hash, base58Encode(digest));
  assert.ok(utf8.enc(s.hash).length >= 43);
});
