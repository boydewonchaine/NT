// Server-side name registration (Vercel function). It holds ONE secret: the funder account's key used to
// pay for `testnet.create_account`. It never receives, derives or stores any user secret — only a
// public key — and has no authority over the created account.
//
// Everything that can be wrong with the funder gets its own stable `code`, so the operator is told what to fix
// instead of one catch-all "not configured":
//   unconfigured     NEAT_FUNDER_ID and/or NEAT_FUNDER_KEY are not set on the server
//   funder_config    they are set, but a value is malformed (bad id, damaged key, bad NEAT_STARTING_BALANCE)
//   funder_unfunded  the funder account has never been given tokens, so it doesn't exist on testnet yet
//   funder_key       the account exists, but NEAT_FUNDER_KEY is not one of its full-access keys
//   funder_empty     the account is fine but holds less than one name costs
// Every one of these is the operator's to fix; none of them says anything about the user.

import { Ed25519Unsupported, isValidAccountId, keyFromString, keyToString, nameToAccountId, parseSecretKey, signerFromSeed, signTransaction, validateNameLabel, verifySignature } from "../core/near";
import { Rpc, RpcError } from "../core/rpc";
import { formatNear, parseNear } from "../core/units";
import { utf8 } from "../core/encoding";

export type Env = Record<string, string | undefined>;
/** `code` is a stable, machine-readable reason the client maps to wording; `error` is a human sentence; `detail` is the specific next step. */
export type Reply = { status: number; body: Record<string, unknown> };

export type FunderCode = "unconfigured" | "funder_config" | "funder_unfunded" | "funder_key" | "funder_empty";
export type Funder = { id: string; seed: Uint8Array; publicKey: Uint8Array; publicKeyStr: string };
type Failed = { ok: false; reply: Reply };

const REGISTRAR = "testnet";
const GAS = 100_000_000_000_000n; // 100 TGas, unused gas is refunded

const hits = new Map<string, number[]>();
export function rateLimited(ip: string, now = Date.now(), max = 5, windowMs = 10 * 60_000): boolean {
  const arr = (hits.get(ip) ?? []).filter((t) => now - t < windowMs);
  arr.push(now);
  hits.set(ip, arr);
  if (hits.size > 5000) hits.clear();
  return arr.length > max;
}

/**
 * Dashboards make these values easy to enter wrongly: stray spaces or newlines, wrapping quotes, or the whole
 * `NAME=value` line that funder-keygen prints. None of that is worth failing a registration over.
 */
function clean(name: string, raw: string | undefined): string {
  let v = (raw ?? "").trim();
  if (v.startsWith(name + "=")) v = v.slice(name.length + 1).trim();
  if (v.length >= 2 && /^(["'`])[\s\S]*\1$/.test(v)) v = v.slice(1, -1).trim();
  return v;
}

const DEFAULT_STARTING_BALANCE = 10n ** 24n; // 1 NEAR

export function startingBalance(env: Env): bigint {
  const v = parseNear(clean("NEAT_STARTING_BALANCE", env.NEAT_STARTING_BALANCE) || "1");
  return v && v > 0n ? v : DEFAULT_STARTING_BALANCE;
}

const shortId = (id: string) => (id.length > 24 ? `${id.slice(0, 8)}…${id.slice(-6)}` : id);

function problem(code: FunderCode, error: string, detail: string, extra: Record<string, unknown> = {}): Failed {
  return { ok: false, reply: { status: 503, body: { code, error, detail, ...extra } } };
}

/** Read and sanity-check the funder settings. Pure: no network. */
export async function readFunder(env: Env): Promise<{ ok: true; funder: Funder } | Failed> {
  const id = clean("NEAT_FUNDER_ID", env.NEAT_FUNDER_ID);
  const keyText = clean("NEAT_FUNDER_KEY", env.NEAT_FUNDER_KEY);

  const missing = [!id && "NEAT_FUNDER_ID", !keyText && "NEAT_FUNDER_KEY"].filter((x): x is string => !!x);
  if (missing.length) {
    return problem("unconfigured", "Registration service is not configured.", `Missing on the server: ${missing.join(" and ")}. Add ${missing.length > 1 ? "them" : "it"} in the host's environment variables, then redeploy.`, { missing });
  }
  if (!isValidAccountId(id)) {
    return problem("funder_config", "NEAT_FUNDER_ID is not a valid account id.", "NEAT_FUNDER_ID must be the funder account's id: the 64-character id that npm run funder-keygen prints, or a name ending in .testnet.");
  }
  const rawBalance = clean("NEAT_STARTING_BALANCE", env.NEAT_STARTING_BALANCE);
  if (rawBalance) {
    const v = parseNear(rawBalance);
    if (!v || v <= 0n) return problem("funder_config", "NEAT_STARTING_BALANCE is not a valid amount.", "NEAT_STARTING_BALANCE must be a plain number of NEAR, such as 1 (or leave it unset for 1).");
  }

  let secret: { seed: Uint8Array; publicKey: Uint8Array };
  try {
    secret = parseSecretKey(keyText);
  } catch {
    return problem("funder_config", "NEAT_FUNDER_KEY is not a valid secret key.", "NEAT_FUNDER_KEY must be the whole value npm run funder-keygen prints, starting with ed25519: Enter it again exactly as printed, with nothing added or removed.");
  }
  // The two halves of the key must belong together; a character lost in copying would otherwise only show up later as a rejected signature.
  try {
    const signer = await signerFromSeed(secret.seed, secret.publicKey);
    const probe = utf8.enc("neat-funder-key-check");
    if (!(await verifySignature(secret.publicKey, probe, await signer.sign(probe)))) {
      return problem("funder_config", "NEAT_FUNDER_KEY is damaged.", "The secret and public parts of NEAT_FUNDER_KEY don't match, which usually means a character was lost or changed along the way. Enter the whole value again.");
    }
  } catch (e) {
    if (e instanceof Ed25519Unsupported) return problem("funder_config", "This server can't sign.", "The server's Node.js version doesn't support Ed25519 signatures. Use Node.js 20 or newer for this deployment.");
    throw e;
  }
  return { ok: true, funder: { id, seed: secret.seed, publicKey: secret.publicKey, publicKeyStr: keyToString(secret.publicKey) } };
}

/** Look at the funder on the network. Throws RpcError when the network can't be reached. */
export async function checkFunder(funder: Funder, env: Env, rpc: Rpc): Promise<{ ok: true; balance: bigint; deposit: bigint; nonce: bigint } | Failed> {
  const deposit = startingBalance(env);
  const [acct, key] = await Promise.all([rpc.viewAccount(funder.id), rpc.viewAccessKey(funder.id, funder.publicKeyStr)]);
  const who = shortId(funder.id);
  if (!acct) {
    return problem("funder_unfunded", "The funder account does not exist on testnet yet.", `Account ${who} (NEAT_FUNDER_ID) has never received any testnet NEAR, so it doesn't exist on the network yet. Send it testnet NEAR first.`, { funder: funder.id });
  }
  if (!key) {
    return problem("funder_key", "NEAT_FUNDER_KEY is not a key of the funder account.", `The key in NEAT_FUNDER_KEY isn't registered on account ${who}. NEAT_FUNDER_ID and NEAT_FUNDER_KEY must come as a pair (they do when both are printed by the same npm run funder-keygen run).`, { funder: funder.id });
  }
  if (!key.fullAccess) {
    return problem("funder_key", "NEAT_FUNDER_KEY is not a full-access key.", `The key in NEAT_FUNDER_KEY is only a limited-access key on ${who}. Creating accounts needs a full-access key.`, { funder: funder.id });
  }
  if (acct.amount < deposit) {
    return problem("funder_empty", "NEAT's testnet funder has run out of tokens.", `Funder ${who} holds ${formatNear(acct.amount, 4)} NEAR; each name needs ${formatNear(deposit, 4)} NEAR plus network fees. Send it more testnet NEAR.`, { funder: funder.id, balance: `${formatNear(acct.amount, 4)} NEAR`, perName: `${formatNear(deposit, 4)} NEAR` });
  }
  return { ok: true, balance: acct.amount, deposit, nonce: key.nonce };
}

function networkReply(e: unknown): Reply {
  if (e instanceof RpcError) return { status: 502, body: { code: "network", error: "NEAR Testnet is unreachable right now.", detail: e.message.slice(0, 160) } };
  // Not a network problem: a bug or an unexpected failure. Say so rather than blaming the network.
  return { status: 500, body: { code: "failed", error: "The registration service hit an unexpected error.", detail: String((e as any)?.name ?? "Error").slice(0, 60) } };
}

/** The network's own verdict on the funder's transaction, in the funder's terms. */
function judgeInvalid(e: RpcError, funder: Funder): Reply | null {
  let raw = e.message;
  try {
    raw += " " + JSON.stringify(e.detail ?? "");
  } catch {}
  const who = shortId(funder.id);
  if (/NotEnoughBalance|LackBalanceForState|balance/i.test(raw)) {
    const r = problem("funder_empty", "NEAT's testnet funder has run out of tokens.", `Funder ${who} doesn't hold enough testnet NEAR for a name plus network fees. Send it more.`, { funder: funder.id });
    return r.reply;
  }
  if (/SignerDoesNotExist|does not exist/i.test(raw)) return problem("funder_unfunded", "The funder account does not exist on testnet yet.", `Account ${who} (NEAT_FUNDER_ID) doesn't exist on the network. Send it testnet NEAR first.`, { funder: funder.id }).reply;
  if (/InvalidSignature|AccessKeyNotFound|DepositWithFunctionCall|NotEnoughAllowance|signature was rejected/i.test(raw)) {
    return problem("funder_key", "NEAT_FUNDER_KEY was refused by the network.", `The network refused the funder's signature. NEAT_FUNDER_KEY must be a full-access key of ${who}.`, { funder: funder.id }).reply;
  }
  return null;
}

export async function handleRegister(body: any, env: Env, ip: string, rpc: Rpc): Promise<Reply> {
  const cfg = await readFunder(env);
  if (!cfg.ok) return cfg.reply;
  const { funder } = cfg;
  if (rateLimited(ip)) return { status: 429, body: { code: "rate", error: "Too many attempts." } };

  const label = typeof body?.label === "string" ? body.label : "";
  const v = validateNameLabel(label);
  if (!v.ok) return { status: 422, body: { code: "invalid", error: v.reason } };
  let pk: Uint8Array;
  try {
    pk = keyFromString(String(body?.publicKey));
  } catch {
    return { status: 422, body: { code: "invalid", error: "Invalid public key." } };
  }
  const newId = nameToAccountId(label);

  try {
    if (await rpc.viewAccount(newId)) return { status: 409, body: { code: "taken", error: "Name already taken." } };

    const state = await checkFunder(funder, env, rpc);
    if (!state.ok) return state.reply;

    const signer = await signerFromSeed(funder.seed, funder.publicKey);
    const args = utf8.enc(JSON.stringify({ new_account_id: newId, new_public_key: keyToString(pk) }));
    let nonce = state.nonce;

    for (let attempt = 0; attempt < 2; attempt++) {
      const block = await rpc.finalBlock();
      const signed = await signTransaction(
        { signerId: funder.id, publicKey: funder.publicKey, nonce: nonce + 1n, receiverId: REGISTRAR, blockHash: block.hash, actions: [{ type: "functionCall", method: "create_account", args, gas: GAS, deposit: state.deposit }] },
        signer
      );
      try {
        await rpc.broadcast(signed.bytes);
        return { status: 200, body: { txHash: signed.hash, accountId: newId, signerId: funder.id } };
      } catch (e) {
        if (e instanceof RpcError && e.kind === "invalid_tx" && attempt === 0 && /nonce/i.test(e.message)) {
          const fresh = await rpc.viewAccessKey(funder.id, funder.publicKeyStr);
          if (fresh) nonce = fresh.nonce;
          continue;
        }
        throw e;
      }
    }
    return { status: 502, body: { code: "network", error: "Could not submit registration." } };
  } catch (e: any) {
    if (e instanceof RpcError && e.kind === "invalid_tx") {
      // the funder (not the user) is the account the network judged: say so
      return judgeInvalid(e, funder) ?? { status: 502, body: { code: "rejected", error: e.message } };
    }
    return networkReply(e);
  }
}

/**
 * GET /api/register: is registration ready? Opening the address in a browser answers in one look, without
 * registering anything. Shows only what is already public on the chain (the funder id and its balance).
 * It never includes a secret.
 */
export async function funderStatus(env: Env, rpc: Rpc, ip = "unknown"): Promise<Reply> {
  if (rateLimited("status:" + ip, Date.now(), 20)) return { status: 429, body: { ready: false, code: "rate", error: "Too many checks. Wait a minute." } };
  const notReady = (r: Reply): Reply => ({ status: r.status, body: { ready: false, ...r.body } });
  try {
    const cfg = await readFunder(env);
    if (!cfg.ok) return notReady(cfg.reply);
    const st = await checkFunder(cfg.funder, env, rpc);
    if (!st.ok) return notReady(st.reply);
    return { status: 200, body: { ready: true, network: "testnet", funder: cfg.funder.id, balance: `${formatNear(st.balance, 4)} NEAR`, perName: `${formatNear(st.deposit, 4)} NEAR` } };
  } catch (e) {
    return notReady(networkReply(e));
  }
}
