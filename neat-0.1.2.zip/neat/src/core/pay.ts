// Payment lifecycle: build → sign (explicit authorization happens in the UI before this is called)
// → persist → broadcast → track. A transaction is never reported complete until the network says FINAL.

import { base58Encode, fromBase64, toBase64 } from "./encoding";
import type { FeeEstimate } from "./fees";
import { decodeTransaction, hashOfSigned, keyToString, sha256, signTransaction, Signer } from "./near";
import type { PaymentRequest } from "./payload";
import { Rpc, RpcError, transferOf } from "./rpc";
import { getTx, load, TxRecord, update, upsertTx } from "./store";

export class PayError extends Error {
  constructor(message: string, public code: "insufficient" | "duplicate" | "offline" | "invalid" | "rejected" | "network") {
    super(message);
  }
}

export type SendInput = {
  rpc: Rpc;
  signer: Signer;
  fromId: string;
  toId: string;
  amount: bigint;
  estimate: FeeEstimate;
  request?: PaymentRequest;
  note?: string;
};

/**
 * A request that carries an amount is a single-use invoice. An "open" QR (no amount) is a standing
 * "pay me" code: the same person can legitimately pay it again and again, so it is never deduplicated.
 */
export const singleUse = (req?: PaymentRequest): boolean => !!req && req.amt !== undefined;

/** Is there already a non-failed payment for this request id? (client-side already-paid detection) */
export function alreadyPaid(requestId: string): TxRecord | undefined {
  return load().txs.find((t) => t.requestId === requestId && t.dir === "out" && t.status !== "failed");
}

export function checkAffordable(amount: bigint, est: FeeEstimate): { ok: true } | { ok: false; message: string } {
  if (amount <= 0n) return { ok: false, message: "Enter an amount greater than zero." };
  if (amount + est.reserve > est.spendable) {
    return { ok: false, message: "Your balance can't cover this amount plus the network fee." };
  }
  return { ok: true };
}

/**
 * Sign and submit. The signed bytes are written to storage BEFORE broadcast, so a refresh, crash or
 * timeout can never cause a second, different payment: recovery only ever re-sends identical bytes
 * (same hash ⇒ the network can execute it at most once).
 */
export async function authorizeAndSend(inp: SendInput, onStage?: (s: "signing" | "submitting") => void): Promise<TxRecord> {
  const { rpc, signer, fromId, toId, amount, estimate } = inp;
  if (singleUse(inp.request) && alreadyPaid(inp.request!.id)) throw new PayError("This payment request has already been paid from this wallet.", "duplicate");
  const ok = checkAffordable(amount, estimate);
  if (!ok.ok) throw new PayError(ok.message, "insufficient");

  onStage?.("signing");
  let nonce: bigint, blockHash: Uint8Array;
  try {
    const [key, block] = await Promise.all([rpc.viewAccessKey(fromId, keyToString(signer.publicKey)), rpc.finalBlock()]);
    if (!key) throw new PayError("This wallet's key is not authorized on its account.", "invalid");
    const local = load().lastNonce ? BigInt(load().lastNonce!) : 0n;
    nonce = (key.nonce > local ? key.nonce : local) + 1n;
    blockHash = block.hash;
  } catch (e) {
    if (e instanceof PayError) throw e;
    throw new PayError("Couldn't reach NEAR Testnet. Nothing was signed or sent.", "offline");
  }

  const signed = await signTransaction({ signerId: fromId, publicKey: signer.publicKey, nonce, receiverId: toId, blockHash, actions: [{ type: "transfer", deposit: amount }] }, signer);
  const now = Date.now();
  const rec: TxRecord = {
    id: signed.hash,
    dir: "out",
    from: fromId,
    to: toId,
    amount: amount.toString(),
    feeEstimate: estimate.fee.toString(),
    status: "signed",
    requestId: singleUse(inp.request) ? inp.request!.id : undefined, // only invoices are tracked for "already paid"
    note: inp.note ?? inp.request?.note,
    createdAt: now,
    updatedAt: now,
    signed: toBase64(signed.bytes),
    source: "local",
  };
  update((s) => (s.lastNonce = nonce.toString()));
  upsertTx(rec); // persisted before the network ever sees it

  onStage?.("submitting");
  try {
    await rpc.broadcast(signed.bytes);
    rec.status = "submitted";
    rec.updatedAt = Date.now();
    upsertTx(rec);
  } catch (e) {
    if (e instanceof RpcError && e.kind === "invalid_tx") {
      rec.status = "failed";
      rec.failure = e.message;
      rec.signed = undefined;
      rec.updatedAt = Date.now();
      upsertTx(rec);
      throw new PayError(e.message, "rejected");
    }
    // Unknown outcome: leave as "signed". The tracker will look the hash up before anyone retries.
  }
  return getTx(rec.id)!;
}

export type Tracked = { tx: TxRecord; settled: boolean };

/**
 * True when we hold the signed bytes and the network has not reported this hash for a while: either the
 * submission never arrived, or the node acknowledged it and later dropped it. Re-sending the identical
 * bytes is safe in both cases (same hash ⇒ it can execute at most once).
 */
export function resendable(t: TxRecord, now = Date.now()): boolean {
  if (!t.signed || t.dir !== "out") return false;
  if (t.status === "signed") return true;
  return t.status === "submitted" && !t.finality && now - t.updatedAt > 10_000;
}

/** One poll step. Safe to call repeatedly and after reloads. Never re-broadcasts. */
export async function refreshTx(rpc: Rpc, id: string): Promise<Tracked> {
  const cur = getTx(id);
  if (!cur) throw new Error("Unknown transaction");
  if (cur.status === "completed" || cur.status === "failed") return { tx: cur, settled: true };
  let st;
  try {
    st = await rpc.txStatus(id, cur.from);
  } catch {
    return { tx: cur, settled: false }; // network trouble: keep state, try again later
  }
  if (!st) {
    // not known to the network (yet). Expire very old unresolved txs: block-hash validity is ~1 day.
    if ((cur.status === "signed" || cur.status === "submitted") && !cur.finality && Date.now() - cur.createdAt > 26 * 3600_000) {
      upsertTx({ ...cur, status: "failed", failure: "Never reached the network and has now expired. No funds moved.", signed: undefined, updatedAt: Date.now() });
    }
    return { tx: getTx(id)!, settled: getTx(id)!.status === "failed" };
  }
  const next: TxRecord = { ...cur, finality: st.finality, updatedAt: Date.now() };
  const outcomeBlock = st.raw?.transaction_outcome?.block_hash;
  if (outcomeBlock) next.blockHash = outcomeBlock;
  if (st.success === false) {
    next.status = "failed";
    next.failure = friendlyFailure(st.failure);
    next.feeActual = st.tokensBurnt.toString();
    next.signed = undefined;
  } else if (st.success === true && st.receiptsDone && st.finality === "FINAL") {
    next.status = "completed";
    next.feeActual = st.tokensBurnt.toString();
    next.signed = undefined;
    // what the network says was moved, and between whom: this (not our own record) is the evidence for "received"
    const facts = transferOf(st.raw);
    if (facts && facts.from === cur.from && facts.to === cur.to) next.onchainAmount = facts.amount.toString();
  } else {
    next.status = "processing";
    if (st.tokensBurnt > 0n) next.feeActual = st.tokensBurnt.toString();
  }
  upsertTx(next);
  return { tx: getTx(id)!, settled: next.status === "completed" || next.status === "failed" };
}

/** Re-send the identical stored transaction. Only offered when the network does not know the hash. */
export async function resendStored(rpc: Rpc, id: string): Promise<void> {
  const cur = getTx(id);
  if (!cur?.signed) throw new PayError("There's nothing to resend.", "invalid");
  const bytes = fromBase64(cur.signed);
  if ((await hashOfSigned(bytes)) !== id) throw new PayError("Stored transaction failed its integrity check.", "invalid");
  // Safety: check the network first. If it already knows the hash, never broadcast again.
  const known = await rpc.txStatus(id, cur.from).catch(() => null);
  if (known) return void (await refreshTx(rpc, id));
  try {
    await rpc.broadcast(bytes);
  } catch (e) {
    if (e instanceof RpcError && e.kind === "invalid_tx") {
      upsertTx({ ...cur, status: "failed", failure: e.message, signed: undefined, updatedAt: Date.now() });
      throw new PayError(e.message, "rejected");
    }
    throw new PayError("Couldn't reach NEAR Testnet. Try again in a moment.", "network");
  }
  upsertTx({ ...cur, status: "submitted", updatedAt: Date.now() });
}

export function friendlyFailure(raw?: string): string {
  if (!raw) return "The network reported that the transaction failed.";
  if (/NotEnoughBalance|LackBalanceForState/i.test(raw)) return "The account didn't have enough balance to complete this payment.";
  if (/AccountDoesNotExist/i.test(raw)) return "The recipient account doesn't exist on testnet.";
  return "The network reported that the transaction failed.";
}

/** Verify a stored tx's integrity and content before showing it as "what you signed". */
export async function describeSigned(b64: string) {
  const bytes = fromBase64(b64);
  const tx = decodeTransaction(bytes);
  const t = tx.actions.find((a) => a.type === "transfer");
  return { hash: base58Encode(await sha256(bytes.slice(0, tx._len))), to: tx.receiverId, from: tx.signerId, amount: t && t.type === "transfer" ? t.deposit : 0n };
}
