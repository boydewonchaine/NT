// NEAT names are real NEAR Testnet accounts: <label>.testnet.
// Registration is performed by the `testnet` registrar contract (create_account), paid for by a NEAT
// funder service. The service only ever receives a PUBLIC key; the new account is controlled solely by
// the user's own key. A name is considered registered only after the chain confirms it.

import { keyToString, nameToAccountId, validateNameLabel } from "./near";
import { Rpc } from "./rpc";

export type Availability = { state: "invalid"; reason: string } | { state: "available" } | { state: "taken" } | { state: "yours" } | { state: "unknown"; reason: string };

/**
 * Is this name free? When `publicKey` is given, a name that already exists is reported as "yours" if that key is a
 * full-access key on it: that is how a person reclaims a name that was registered for them but never recorded
 * on this device (a crash between the network confirming it and the app saving it, or a backup made before).
 */
export async function checkAvailability(rpc: Rpc, label: string, publicKey?: Uint8Array): Promise<Availability> {
  const v = validateNameLabel(label);
  if (!v.ok) return { state: "invalid", reason: v.reason };
  try {
    const id = nameToAccountId(label);
    const acct = await rpc.viewAccount(id);
    if (!acct) return { state: "available" };
    if (publicKey && (await rpc.viewAccessKey(id, keyToString(publicKey)))?.fullAccess) return { state: "yours" };
    return { state: "taken" };
  } catch {
    return { state: "unknown", reason: "Couldn't reach NEAR Testnet to check this name." };
  }
}

/**
 * `message` is what went wrong, in a sentence. `detail` (funder problems only) is the specific fix for whoever runs
 * this deployment: it names the setting, never a secret. It comes from our own /api/register, not the network.
 */
export type RegisterFailure = "unconfigured" | "funder_config" | "funder_unfunded" | "funder_key" | "funder_empty" | "taken" | "invalid" | "rate" | "network" | "unavailable" | "failed";
export type RegisterResult = { ok: true; txHash: string; accountId: string; signerId?: string } | { ok: false; code: RegisterFailure; message: string; detail?: string };

export async function requestRegistration(label: string, publicKey: Uint8Array, endpoint = "/api/register", f: typeof fetch = fetch): Promise<RegisterResult> {
  let res: Response;
  try {
    res = await f(endpoint, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ label, publicKey: keyToString(publicKey) }) });
  } catch {
    return { ok: false, code: "network", message: "Couldn't reach the NEAT registration service. Check your connection." };
  }
  let j: any = null;
  try {
    j = await res.json();
  } catch {}
  if (res.ok && j?.txHash) return { ok: true, txHash: String(j.txHash), accountId: nameToAccountId(label), signerId: typeof j.signerId === "string" ? j.signerId : undefined };
  if (!j || typeof j !== "object") {
    // Not our function's JSON (a platform error page, a missing route, a gateway): say what was seen instead of guessing a cause.
    return { ok: false, code: "unavailable", message: `The NEAT registration service didn't answer properly (HTTP ${res.status}). Try again in a moment.`, detail: res.status === 404 || res.status === 405 || res.ok ? "If you run this deployment: /api/register isn't being served. Check that the api folder was deployed." : undefined };
  }
  const detail = typeof j.detail === "string" && j.detail ? j.detail.slice(0, 400) : undefined;
  const fail =(code: RegisterFailure, message: string, withDetail = false): RegisterResult => ({ ok: false, code, message, ...(withDetail && detail ? { detail } : {}) });
  switch (typeof j.code === "string" ? j.code : "") {
    case "taken": return fail("taken", "That name was just taken. Choose another.");
    case "invalid": return fail("invalid", j.error ?? "That name isn't valid.");
    case "rate": return fail("rate", "Too many attempts. Wait a minute and try again.");
    case "unconfigured": return fail("unconfigured", "Name registration isn't set up on this deployment yet (the NEAT funder account isn't configured).", true);
    case "funder_config": return fail("funder_config", "Name registration is set up incorrectly on this deployment (a NEAT funder setting isn't valid).", true);
    case "funder_unfunded": return fail("funder_unfunded", "Name registration can't start yet: NEAT's funder account hasn't been given any testnet tokens.", true);
    case "funder_key": return fail("funder_key", "Name registration is set up incorrectly on this deployment: the funder key doesn't work for the funder account.", true);
    case "funder_empty": return fail("funder_empty", "NEAT's testnet funder has run out of tokens, so names can't be created right now. Try again later.", true);
    case "network": return fail("network", "NEAT couldn't reach NEAR Testnet. Try again in a moment.", true);
  }
  // a JSON answer without a code we know: the status alone says only so much
  if (res.status === 409) return fail("taken", "That name was just taken. Choose another.");
  if (res.status === 422) return fail("invalid", j.error ?? "That name isn't valid.");
  if (res.status === 429) return fail("rate", "Too many attempts. Wait a minute and try again.");
  return fail("failed", j.error ?? "Registration failed. No name was registered.");
}

export type RegistrationState = { state: "registered" } | { state: "failed"; reason: string; nameTaken: boolean } | { state: "pending" };

/** Words for an on-chain registration failure. The raw reason is a JSON blob from the network. */
export function describeRegistrationFailure(raw?: string): { reason: string; nameTaken: boolean } {
  if (raw && /AccountAlreadyExists|already exists/i.test(raw)) return { reason: "Someone registered that name moments before you. Choose another.", nameTaken: true };
  if (raw && /NotEnoughBalance|LackBalanceForState|NotEnoughAllowance/i.test(raw)) return { reason: "NEAT's testnet funder has run out of tokens, so the name couldn't be created. Try again later.", nameTaken: false };
  return { reason: "The network rejected the registration, so no name was created.", nameTaken: false };
}

/**
 * One look at the chain: registered (our key is a full-access key on the account), failed (the registration
 * transaction reports failure) or still pending. "registered" is only ever returned on on-chain evidence.
 */
export async function checkRegistration(rpc: Rpc, accountId: string, publicKey: Uint8Array, tx?: { hash: string; signerId?: string }): Promise<RegistrationState> {
  try {
    const key = await rpc.viewAccessKey(accountId, keyToString(publicKey));
    if (key?.fullAccess) return { state: "registered" };
  } catch {
    /* network trouble: fall through to pending */
  }
  if (tx?.signerId) {
    try {
      const st = await rpc.txStatus(tx.hash, tx.signerId);
      if (st && st.success === false) return { state: "failed", ...describeRegistrationFailure(st.failure) };
    } catch {
      /* ignore: still pending */
    }
  }
  return { state: "pending" };
}

/** Poll until registered, failed, or the timeout (then "pending": nothing is claimed). */
export async function awaitRegistration(rpc: Rpc, accountId: string, publicKey: Uint8Array, tx: { hash: string; signerId?: string } | undefined, opts: { timeoutMs?: number; intervalMs?: number; sleep?: (ms: number) => Promise<void> } = {}): Promise<RegistrationState> {
  const timeout = opts.timeoutMs ?? 60_000;
  const interval = opts.intervalMs ?? 2_000;
  const sleep = opts.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const start = Date.now();
  do {
    const r = await checkRegistration(rpc, accountId, publicKey, tx);
    if (r.state !== "pending") return r;
    await sleep(interval);
  } while (Date.now() - start < timeout);
  return { state: "pending" };
}

/** Wait until the chain shows the account with our key as a full-access key. True only on genuine on-chain evidence. */
export async function confirmRegistered(rpc: Rpc, accountId: string, publicKey: Uint8Array, opts: { timeoutMs?: number; intervalMs?: number; sleep?: (ms: number) => Promise<void> } = {}): Promise<boolean> {
  return (await awaitRegistration(rpc, accountId, publicKey, undefined, opts)).state === "registered";
}
