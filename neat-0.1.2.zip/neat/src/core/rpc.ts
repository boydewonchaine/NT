// Minimal NEAR JSON-RPC client with endpoint failover and typed error classification.

import { base58Decode, toBase64 } from "./encoding";

export const DEFAULT_ENDPOINTS = ["https://rpc.testnet.fastnear.com", "https://rpc.testnet.near.org"];
export const NETWORK_ID = "testnet";

export class RpcError extends Error {
  constructor(
    message: string,
    public kind: "network" | "timeout" | "rpc" | "unknown_account" | "unknown_key" | "unknown_tx" | "invalid_tx" | "method_missing",
    public detail?: unknown
  ) {
    super(message);
  }
}

export type AccountView = { amount: bigint; locked: bigint; storageUsage: number; codeHash: string };

export type TxOutcomeStatus = {
  finality: string; // NONE | INCLUDED | INCLUDED_FINAL | EXECUTED | EXECUTED_OPTIMISTIC | FINAL
  success: boolean | null; // null while undetermined
  failure?: string;
  tokensBurnt: bigint; // sum across transaction + receipts so far
  receiptsDone: boolean;
  raw: any;
};

export type RpcOptions = { endpoints?: string[]; fetchImpl?: typeof fetch; timeoutMs?: number; apiKey?: string };

export class Rpc {
  endpoints: string[];
  private f: typeof fetch;
  private timeoutMs: number;
  private apiKey?: string;
  private seq = 1;
  private protoCache?: { at: number; value: any };

  constructor(opts: RpcOptions = {}) {
    this.endpoints = opts.endpoints?.length ? opts.endpoints : DEFAULT_ENDPOINTS;
    this.f = opts.fetchImpl ?? ((...a) => fetch(...a));
    this.timeoutMs = opts.timeoutMs ?? 12000;
    this.apiKey = opts.apiKey;
  }

  async call<T = any>(method: string, params: unknown, timeoutMs = this.timeoutMs): Promise<T> {
    let lastErr: unknown;
    for (const url of this.endpoints) {
      const ctrl = new AbortController();
      const timer = setTimeout(() => ctrl.abort(), timeoutMs);
      try {
        const headers: Record<string, string> = { "content-type": "application/json" };
        if (this.apiKey) headers.authorization = `Bearer ${this.apiKey}`;
        const res = await this.f(url, {
          method: "POST",
          headers,
          body: JSON.stringify({ jsonrpc: "2.0", id: this.seq++, method, params }),
          signal: ctrl.signal,
        });
        if (!res.ok && res.status >= 500) throw new RpcError(`RPC ${res.status}`, "network");
        if (res.status === 401 || res.status === 403 || res.status === 429) throw new RpcError(`RPC ${res.status}`, "network");
        const body = await res.json();
        if (body.error) throw classify(body.error);
        const r = body.result;
        if (r && typeof r === "object" && typeof r.error === "string") throw classifyLegacy(r.error);
        return r as T;
      } catch (e: any) {
        if (e instanceof RpcError && e.kind !== "network" && e.kind !== "timeout") throw e; // real answer from the chain: do not fail over
        lastErr = e instanceof RpcError ? e : e?.name === "AbortError" ? new RpcError("RPC timed out", "timeout") : new RpcError(String(e?.message ?? e), "network");
      } finally {
        clearTimeout(timer);
      }
    }
    throw lastErr ?? new RpcError("No RPC endpoints", "network");
  }

  async viewAccount(accountId: string): Promise<AccountView | null> {
    try {
      const r = await this.call("query", { request_type: "view_account", finality: "final", account_id: accountId });
      return { amount: BigInt(r.amount), locked: BigInt(r.locked ?? "0"), storageUsage: Number(r.storage_usage ?? 0), codeHash: String(r.code_hash ?? "") };
    } catch (e) {
      if (e instanceof RpcError && e.kind === "unknown_account") return null;
      throw e;
    }
  }

  /** Returns the access key (nonce + permission) or null when the key is not on the account. */
  async viewAccessKey(accountId: string, publicKey: string): Promise<{ nonce: bigint; fullAccess: boolean } | null> {
    try {
      const r = await this.call("query", { request_type: "view_access_key", finality: "final", account_id: accountId, public_key: publicKey });
      return { nonce: BigInt(r.nonce), fullAccess: r.permission === "FullAccess" };
    } catch (e) {
      if (e instanceof RpcError && (e.kind === "unknown_key" || e.kind === "unknown_account")) return null;
      throw e;
    }
  }

  async gasPrice(): Promise<bigint> {
    const r = await this.call("gas_price", [null]);
    return BigInt(r.gas_price);
  }

  async finalBlock(): Promise<{ hash: Uint8Array; height: number; timestampMs: number }> {
    const r = await this.call("block", { finality: "final" });
    return { hash: base58Decode(r.header.hash), height: Number(r.header.height), timestampMs: Number(BigInt(r.header.timestamp) / 1_000_000n) };
  }

  async protocolConfig(): Promise<any> {
    if (this.protoCache && Date.now() - this.protoCache.at < 10 * 60_000) return this.protoCache.value;
    const value = await this.call("EXPERIMENTAL_protocol_config", { finality: "final" });
    this.protoCache = { at: Date.now(), value };
    return value;
  }

  /** Broadcast without waiting for execution. Returns once the node has accepted the transaction. */
  async broadcast(signedBytes: Uint8Array): Promise<void> {
    const b64 = toBase64(signedBytes);
    try {
      await this.call("send_tx", { signed_tx_base64: b64, wait_until: "NONE" });
    } catch (e) {
      if (e instanceof RpcError && e.kind === "method_missing") {
        await this.call("broadcast_tx_async", [b64]);
        return;
      }
      throw e;
    }
  }

  async txStatus(txHash: string, senderId: string): Promise<TxOutcomeStatus | null> {
    let r: any;
    try {
      r = await this.call("tx", { tx_hash: txHash, sender_account_id: senderId, wait_until: "EXECUTED_OPTIMISTIC" }, 25000);
    } catch (e) {
      if (e instanceof RpcError && (e.kind === "unknown_tx" || e.kind === "timeout")) return null;
      throw e;
    }
    return summarizeTx(r);
  }

  async rawBlockTime(): Promise<number> {
    return (await this.finalBlock()).timestampMs;
  }
}

export function summarizeTx(r: any): TxOutcomeStatus {
  const status = r?.status ?? {};
  let success: boolean | null = null;
  let failure: string | undefined;
  if (status.Failure) {
    success = false;
    failure = JSON.stringify(status.Failure);
  } else if (status.SuccessValue !== undefined || status.SuccessReceiptId !== undefined) success = true;
  let burnt = BigInt(r?.transaction_outcome?.outcome?.tokens_burnt ?? "0");
  let receiptsDone = true;
  for (const ro of r?.receipts_outcome ?? []) {
    burnt += BigInt(ro?.outcome?.tokens_burnt ?? "0");
    const s = ro?.outcome?.status ?? {};
    if (s.Failure) {
      success = false;
      failure = failure ?? JSON.stringify(s.Failure);
    }
    if (s.Unknown !== undefined) receiptsDone = false;
  }
  return { finality: String(r?.final_execution_status ?? "NONE"), success, failure, tokensBurnt: burnt, receiptsDone, raw: r };
}

/**
 * The facts a `tx` result states about a plain NEAR transfer: who signed it, who it was addressed to and
 * how much it moved. Returns null for anything that is not exactly one Transfer action, so callers can
 * never mistake a contract call or an account creation for a payment.
 */
export function transferOf(raw: any): { from: string; to: string; amount: bigint } | null {
  const t = raw?.transaction;
  const acts = Array.isArray(t?.actions) ? t.actions : [];
  if (acts.length !== 1) return null;
  const dep = acts[0]?.Transfer?.deposit;
  if (dep === undefined || dep === null) return null;
  try {
    const amount = BigInt(String(dep));
    if (amount <= 0n || typeof t.signer_id !== "string" || typeof t.receiver_id !== "string") return null;
    return { from: t.signer_id, to: t.receiver_id, amount };
  } catch {
    return null;
  }
}

function classify(err: any): RpcError {
  const name: string = err?.cause?.name ?? err?.name ?? "";
  const msg: string = err?.data && typeof err.data === "string" ? err.data : err?.message ?? "RPC error";
  switch (name) {
    case "UNKNOWN_ACCOUNT":
      return new RpcError("Account does not exist", "unknown_account", err);
    case "UNKNOWN_ACCESS_KEY":
      return new RpcError("Access key not found", "unknown_key", err);
    case "UNKNOWN_TRANSACTION":
      return new RpcError("Transaction not found yet", "unknown_tx", err);
    case "TIMEOUT_ERROR":
      return new RpcError("Timed out waiting for the network", "timeout", err);
    case "INVALID_TRANSACTION":
      return new RpcError(describeInvalid(err?.cause?.info), "invalid_tx", err);
    case "METHOD_NOT_FOUND":
      return new RpcError("Method not found", "method_missing", err);
  }
  if (err?.code === -32601) return new RpcError("Method not found", "method_missing", err);
  return new RpcError(msg, "rpc", err);
}

function classifyLegacy(msg: string): RpcError {
  if (/does not exist/i.test(msg)) return new RpcError("Account does not exist", "unknown_account", msg);
  if (/access key .* does not exist/i.test(msg)) return new RpcError("Access key not found", "unknown_key", msg);
  return new RpcError(msg, "rpc", msg);
}

function describeInvalid(info: any): string {
  const e = info?.InvalidTxError ?? info;
  if (e?.NotEnoughBalance) return "Not enough balance to cover the amount and fees.";
  if (e?.InvalidNonce) return "The wallet nonce was out of date. Try again.";
  if (e?.Expired) return "The transaction expired before it was accepted.";
  if (e?.InvalidReceiver) return "The recipient account is not valid.";
  if (e?.InvalidSignature) return "The signature was rejected.";
  if (e?.SignerDoesNotExist) return "The sending account does not exist on testnet.";
  if (e?.ShardCongested) return "The network shard is congested. Try again shortly.";
  return "The network rejected the transaction.";
}
