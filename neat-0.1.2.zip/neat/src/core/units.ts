// NEAR amounts are integers in yoctoNEAR (1 NEAR = 10^24). Never use floating point for money.

export const YOCTO_PER_NEAR = 10n ** 24n;

/** Parse a user-entered decimal NEAR string into yocto. Returns null when invalid. */
export function parseNear(input: string, maxDecimals = 6): bigint | null {
  const s = input.trim().replace(/,/g, ".");
  if (!/^\d*\.?\d*$/.test(s) || s === "" || s === ".") return null;
  const [whole, frac = ""] = s.split(".");
  if (frac.length > maxDecimals) return null;
  const f = (frac + "0".repeat(24)).slice(0, 24);
  return BigInt(whole || "0") * YOCTO_PER_NEAR + BigInt(f || "0");
}

/** Format yocto as a NEAR decimal string with at most `maxDecimals` places (trailing zeros trimmed). */
export function formatNear(yocto: bigint, maxDecimals = 5, minDecimals = 0): string {
  const neg = yocto < 0n;
  const v = neg ? -yocto : yocto;
  const whole = v / YOCTO_PER_NEAR;
  const frac = (v % YOCTO_PER_NEAR).toString().padStart(24, "0");
  let f = frac.slice(0, maxDecimals);
  f = f.replace(/0+$/, "");
  while (f.length < minDecimals) f += "0";
  const w = whole.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  return (neg ? "-" : "") + w + (f ? "." + f : "");
}

/**
 * Fees are tiny (≈0.00005 NEAR). Show enough significant digits that they never read as zero.
 */
export function formatFee(yocto: bigint): string {
  if (yocto <= 0n) return "0";
  if (yocto >= 10n ** 21n) return formatNear(yocto, 5);
  // below 0.001 NEAR: show 2 significant digits
  const s = formatNear(yocto, 9);
  return s === "0" ? "<0.000000001" : s;
}
