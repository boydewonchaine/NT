// Incoming-payment discovery and request reconciliation.
//
// NEAR RPC cannot list an account's history, so DISCOVERY of incoming transfers uses a NearBlocks-compatible
// index. The index is only ever a hint: it supplies candidate transaction hashes. Every fact that is shown
// (who sent it, who received it, how much, whether it succeeded, whether it is final) is read from the
// network's own `tx` result, and anything that is not exactly one plain Transfer to this account is discarded.
// Coverage is therefore "recent activity", not full history, and the UI says so.

import { Rpc, transferOf } from "./rpc";
import { getTx, RequestRecord, TxRecord, update, upsertTx } from "./store";
import { refreshTx } from "./pay";

export let INDEX_BASE = "https://api-testnet.nearblocks.io";
/** Set once at startup from build configuration. */
export function setIndexBase(url: string) {
  INDEX_BASE = url.replace(/\/+$/, "");
}

export type IndexHit = { hash: string; sender: string; tsMs: number };

const HASH_RE = /^[1-9A-HJ-NP-Za-km-z]{32,50}$/; // base58 of a 32-byte hash

/**
 * Defensive parse of the index's `txns` list into candidate (hash, sender hint, time) triples.
 * Amounts, actions and outcomes in the index are deliberately ignored.
 */
export function parseIndexTxns(j: any, me: string): IndexHit[] {
  const out: IndexHit[] = [];
  const seen = new Set<string>();
  for (const t of Array.isArray(j?.txns) ? j.txns : []) {
    try {
      const hash = t?.transaction_hash;
      const sender = t?.signer_account_id ?? t?.predecessor_account_id;
      if (typeof hash !== "string" || !HASH_RE.test(hash) || typeof sender !== "string") continue;
      if (t.receiver_account_id !== me || sender === me || seen.has(hash)) continue;
      seen.add(hash);
      const ns = String(t.block_timestamp ?? t.receipt_block?.block_timestamp ?? "0").split(".")[0];
      out.push({ hash, sender, tsMs: Number(BigInt(ns) / 1_000_000n) });
    } catch {
      /* skip malformed entry */
    }
  }
  return out;
}

type Fetched = { hits: IndexHit[] } | { error: "rate" | "unavailable" };

async function fetchIndex(me: string, f: typeof fetch): Promise<Fetched> {
  try {
    const res = await f(`${INDEX_BASE}/v1/account/${encodeURIComponent(me)}/txns?page=1&per_page=25&order=desc`, { headers: { accept: "application/json" } });
    if (res.status === 429) return { error: "rate" };
    if (!res.ok) return { error: "unavailable" };
    return { hits: parseIndexTxns(await res.json(), me) };
  } catch {
    return { error: "unavailable" };
  }
}

// The free index tier is small (NearBlocks' free plan is about 6 calls a minute and a few hundred a day), so lookups
// are rationed rather than polled:
//   - never more often than MIN_GAP_MS;
//   - background polling asks only every IDLE_GAP_MS, UNLESS the wallet's balance has just risen (the app watches the
//     balance over RPC, which is cheap): `expectIncoming()` then allows lookups at MIN_GAP_MS for EXPECT_MS, because
//     the index can trail the chain by a while;
//   - a 429 backs off 1, 2, 4, … minutes (capped), and a success resets it.
// Opening a screen that shows payments is not "background": it always gets a lookup (subject to MIN_GAP_MS).
const MIN_GAP_MS = 15_000;
const IDLE_GAP_MS = 5 * 60_000;
const EXPECT_MS = 3 * 60_000;
const MAX_BACKOFF_MS = 30 * 60_000;
const gate = { last: 0, backoffUntil: 0, strikes: 0, expectUntil: 0, ok: true };
const rejected = new Set<string>(); // hashes the chain says are not a plain transfer to us
const misses = new Map<string, number>(); // hashes the RPC doesn't know (yet)

/** The balance went up, so something probably arrived: let the next few lookups through at the normal pace. */
export function expectIncoming(now = Date.now()) {
  gate.expectUntil = now + EXPECT_MS;
}

/** Test hook. */
export function resetIndexState() {
  gate.last = 0;
  gate.backoffUntil = 0;
  gate.strikes = 0;
  gate.expectUntil = 0;
  gate.ok = true;
  rejected.clear();
  misses.clear();
}

async function adopt(rpc: Rpc, me: string, h: IndexHit): Promise<boolean> {
  let st;
  try {
    st = await rpc.txStatus(h.hash, h.sender);
  } catch {
    return false; // network trouble: try again on the next sync
  }
  if (!st) {
    const n = (misses.get(h.hash) ?? 0) + 1;
    misses.set(h.hash, n);
    if (n >= 3) rejected.add(h.hash);
    return false;
  }
  const facts = transferOf(st.raw);
  if (!facts || facts.to !== me || facts.from === me) {
    rejected.add(h.hash); // a contract call, an account creation, a payment to someone else…
    return false;
  }
  const now = Date.now();
  const rec: TxRecord = { id: h.hash, dir: "in", from: facts.from, to: me, amount: facts.amount.toString(), status: "processing", createdAt: h.tsMs || now, updatedAt: now, source: "index" };
  upsertTx(rec);
  const r = await refreshTx(rpc, h.hash).catch(() => null);
  if (r?.tx.status === "failed") {
    update((s) => (s.txs = s.txs.filter((t) => t.id !== h.hash))); // nothing arrived, so nothing is shown
    rejected.add(h.hash);
    return false;
  }
  return true;
}

/** Pull recent incoming transfers, verify each one through RPC, and record the verified ones. */
export async function syncIncoming(rpc: Rpc, me: string, f: typeof fetch = fetch, opts: { now?: number; force?: boolean; background?: boolean } = {}): Promise<{ added: number; indexOk: boolean }> {
  const now = opts.now ?? Date.now();
  const gap = opts.background && now >= gate.expectUntil ? IDLE_GAP_MS : MIN_GAP_MS;
  if (!opts.force && (now < gate.backoffUntil || now - gate.last < gap)) return { added: 0, indexOk: gate.ok };
  gate.last = now; // set first so concurrent callers share one lookup
  const r = await fetchIndex(me, f);
  if ("error" in r) {
    gate.ok = false;
    if (r.error === "rate") {
      gate.strikes++;
      gate.backoffUntil = now + Math.min(MAX_BACKOFF_MS, 60_000 * 2 ** (gate.strikes - 1));
    }
    return { added: 0, indexOk: false };
  }
  gate.ok = true;
  gate.strikes = 0;
  gate.backoffUntil = 0;
  let added = 0;
  for (const h of r.hits) {
    if (getTx(h.hash) || rejected.has(h.hash)) continue;
    if (await adopt(rpc, me, h)) added++;
  }
  return { added, indexOk: true };
}

/**
 * Mark open requests paid ONLY when a chain-verified (FINAL, successful) incoming transfer matches:
 * created after the request, at least the requested amount, and not already used by another request.
 * NEAR transfers carry no memo, so two simultaneous same-amount requests can't be told apart; the
 * oldest open request is matched first.
 */
export function reconcileRequests(now = Date.now()): number {
  let changed = 0;
  update((s) => {
    const used = new Set(s.requests.filter((r) => r.paidTx).map((r) => r.paidTx));
    const incoming = s.txs.filter((t) => t.dir === "in" && t.status === "completed" && t.onchainAmount !== undefined && !used.has(t.id)).sort((a, b) => a.createdAt - b.createdAt);
    const open = s.requests.filter((r) => r.state === "open" && r.kind === "amount").sort((a, b) => a.createdAt - b.createdAt);
    for (const r of open) {
      if (r.request.exp && now / 1000 > r.request.exp) {
        r.state = "expired";
        changed++;
        continue;
      }
      const want = BigInt(r.request.amt ?? "0");
      const hit = incoming.find((t) => t.createdAt >= r.request.iat * 1000 - 60_000 && BigInt(t.onchainAmount!) >= want && !used.has(t.id));
      if (hit) {
        r.state = "paid";
        r.paidTx = hit.id;
        used.add(hit.id);
        changed++;
      }
    }
  });
  return changed;
}

export const requestLabel = (r: RequestRecord) => (r.state === "paid" ? "Paid" : r.state === "expired" ? "Expired" : r.state === "cancelled" ? "Cancelled" : "Open");
