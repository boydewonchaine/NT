// NEAT payment-request QR payload (compact binary, version 1 = NEAR Testnet, asset NEAR).
//
// QR text:  "NEAT1." + base64url(body ‖ signature)
//   body = u8 version(1) ‖ u8 flags ‖ id[8] ‖ u8 len ‖ to ‖ pk[32]
//          ‖ (amount: u8 len ‖ big-endian magnitude)? ‖ u32 iat ‖ (u32 exp)? ‖ (u8 len ‖ note)?
//   flags: 1 = has amount, 2 = amount is fixed, 4 = has expiry, 8 = has note
// It holds ONLY public data. The receiver signs  "NEAT1/testnet/NEAR" ‖ body  with the ed25519 key that
// controls their account; the sender checks (a) that signature and (b) on-chain that this key is a
// full-access key of the named account. A QR therefore cannot be silently re-targeted at another account.

import { concat, fromBase64Url, toBase64Url, toHex, fromHex, utf8, base58Encode } from "./encoding";
import { isValidAccountId, keyToString, verifySignature, Signer } from "./near";
import { Rpc } from "./rpc";

export const PREFIX = "NEAT1.";
export const MAX_NOTE = 40;
const DOMAIN = utf8.enc("NEAT1/testnet/NEAR");

export type PaymentRequest = {
  v: 1;
  id: string; // random request id (16 hex)
  to: string; // receiving account (the NEAT name)
  pk: string; // ed25519:… key that controls `to`
  amt?: string; // yocto, decimal string; omitted = sender chooses
  fix?: 0 | 1; // 1 = amount may not be changed
  asset: "NEAR";
  net: "testnet";
  note?: string;
  iat: number; // unix seconds
  exp?: number; // unix seconds; omitted = does not expire
  sig: string; // base64url ed25519 signature
};

function bigToBytes(n: bigint): Uint8Array {
  const out: number[] = [];
  while (n > 0n) {
    out.unshift(Number(n & 0xffn));
    n >>= 8n;
  }
  return Uint8Array.from(out);
}
const bytesToBig = (b: Uint8Array) => b.reduce((a, x) => (a << 8n) | BigInt(x), 0n);
const u32 = (n: number) => Uint8Array.of((n >>> 24) & 255, (n >>> 16) & 255, (n >>> 8) & 255, n & 255);

function body(r: Omit<PaymentRequest, "sig">): Uint8Array {
  const to = utf8.enc(r.to);
  const note = r.note ? utf8.enc(r.note) : undefined;
  const flags = (r.amt !== undefined ? 1 : 0) | (r.fix ? 2 : 0) | (r.exp !== undefined ? 4 : 0) | (note ? 8 : 0);
  const parts: Uint8Array[] = [Uint8Array.of(1, flags), fromHex(r.id), Uint8Array.of(to.length), to, keyBytes(r.pk)];
  if (r.amt !== undefined) {
    const a = bigToBytes(BigInt(r.amt));
    parts.push(Uint8Array.of(a.length), a);
  }
  parts.push(u32(r.iat));
  if (r.exp !== undefined) parts.push(u32(r.exp));
  if (note) parts.push(Uint8Array.of(note.length), note);
  return concat(...parts);
}

function keyBytes(pk: string): Uint8Array {
  // pk is "ed25519:<base58>"; imported lazily to avoid a cycle
  return keyFromStringLocal(pk);
}
import { keyFromString as keyFromStringLocal } from "./near";

export function newRequestId(): string {
  return toHex(crypto.getRandomValues(new Uint8Array(8)));
}

export async function createRequest(
  signer: Signer,
  accountId: string,
  opts: { amountYocto?: bigint; fixed?: boolean; note?: string; expiresInSec?: number; now?: number }
): Promise<{ request: PaymentRequest; qrText: string }> {
  const now = Math.floor((opts.now ?? Date.now()) / 1000);
  const note = opts.note?.trim() || undefined;
  if (note && utf8.enc(note).length > MAX_NOTE) throw new Error("Note too long");
  if (opts.amountYocto !== undefined && (opts.amountYocto <= 0n || opts.amountYocto >= 1n << 128n)) throw new Error("Invalid amount");
  const base: Omit<PaymentRequest, "sig"> = {
    v: 1,
    id: newRequestId(),
    to: accountId,
    pk: keyToString(signer.publicKey),
    ...(opts.amountYocto !== undefined ? { amt: opts.amountYocto.toString(), fix: opts.fixed ? (1 as const) : (0 as const) } : {}),
    asset: "NEAR",
    net: "testnet",
    ...(note ? { note } : {}),
    iat: now,
    ...(opts.expiresInSec ? { exp: now + opts.expiresInSec } : {}),
  };
  const sig = toBase64Url(await signer.sign(concat(DOMAIN, body(base))));
  const request = { ...base, sig };
  return { request, qrText: encodeRequest(request) };
}

export function encodeRequest(r: PaymentRequest): string {
  return PREFIX + toBase64Url(concat(body(r), fromBase64Url(r.sig)));
}

export type ParseResult = { ok: true; request: PaymentRequest } | { ok: false; error: string };

/** Structural validation only. Authenticity needs `verifyRequest`. */
export function parseRequest(text: string): ParseResult {
  if (!text.startsWith(PREFIX)) return { ok: false, error: "This isn't a NEAT payment QR." };
  let b: Uint8Array;
  try {
    b = fromBase64Url(text.slice(PREFIX.length));
  } catch {
    return { ok: false, error: "This QR is damaged or isn't a NEAT payment." };
  }
  const damaged = { ok: false as const, error: "This QR is damaged or isn't a NEAT payment." };
  if (b.length < 2 + 8 + 1 + 2 + 32 + 4 + 64) return damaged;
  if (b[0] !== 1) return { ok: false, error: "This QR was made by a newer version of NEAT, or for another network. NEAT supports NEAR Testnet only." };
  try {
    let o = 1;
    const flags = b[o++];
    if (flags & ~15) return damaged;
    const id = toHex(b.slice(o, o + 8));
    o += 8;
    const tl = b[o++];
    const to = utf8.dec(b.slice(o, o + tl));
    o += tl;
    if (!isValidAccountId(to)) return { ok: false, error: "This QR has an invalid recipient." };
    const pkRaw = b.slice(o, o + 32);
    o += 32;
    const r: any = { v: 1, id, to, pk: "ed25519:" + base58Encode(pkRaw), asset: "NEAR", net: "testnet" };
    if (flags & 1) {
      const al = b[o++];
      if (al < 1 || al > 16) return damaged;
      const amt = bytesToBig(b.slice(o, o + al));
      o += al;
      if (amt <= 0n) return { ok: false, error: "This QR has an invalid amount." };
      r.amt = amt.toString();
      r.fix = flags & 2 ? 1 : 0;
    } else if (flags & 2) return damaged;
    r.iat = ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
    o += 4;
    if (flags & 4) {
      r.exp = ((b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]) >>> 0;
      o += 4;
    }
    if (flags & 8) {
      const nl = b[o++];
      if (nl > MAX_NOTE) return damaged;
      r.note = utf8.dec(b.slice(o, o + nl));
      o += nl;
    }
    if (b.length - o !== 64) return damaged;
    r.sig = toBase64Url(b.slice(o));
    return { ok: true, request: r as PaymentRequest };
  } catch {
    return damaged;
  }
}

export type VerifyOutcome =
  | { ok: true }
  | { ok: false; reason: "expired" | "bad_signature" | "unknown_account" | "key_mismatch" | "offline"; message: string };

/** Full authenticity check: expiry, signature, and on-chain key ownership. */
export async function verifyRequest(r: PaymentRequest, rpc: Rpc, nowMs = Date.now()): Promise<VerifyOutcome> {
  if (r.exp !== undefined && nowMs / 1000 > r.exp) return { ok: false, reason: "expired", message: "This payment request has expired. Ask for a new QR." };
  const { sig, ...rest } = r;
  let good = false;
  try {
    good = await verifySignature(keyBytes(r.pk), concat(DOMAIN, body(rest)), fromBase64Url(sig));
  } catch {}
  if (!good) return { ok: false, reason: "bad_signature", message: "This QR's signature is invalid. Don't pay it." };
  try {
    const acct = await rpc.viewAccount(r.to);
    if (!acct) return { ok: false, reason: "unknown_account", message: `${r.to} doesn't exist on testnet.` };
    const key = await rpc.viewAccessKey(r.to, r.pk);
    if (!key || !key.fullAccess) return { ok: false, reason: "key_mismatch", message: `This QR wasn't issued by the owner of ${r.to}. Don't pay it.` };
  } catch (e: any) {
    return { ok: false, reason: "offline", message: "Couldn't reach NEAR Testnet to verify this QR. Check your connection and scan again." };
  }
  return { ok: true };
}
