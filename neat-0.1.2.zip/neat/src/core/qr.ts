// QR Code (Model 2) encoder: byte mode, error-correction levels L and M, versions 1–20.
// Structure follows the ISO/IEC 18004 algorithm (data → Reed-Solomon blocks → interleave → place → mask).
// Verified in tests/qr.test.ts against an independent decoder (OpenCV) for every version/level it supports.

export type Ecl = "L" | "M";

export const ECC_PER_BLOCK: Record<Ecl, number[]> = {
  L: [-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28],
  M: [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26],
};
export const NUM_BLOCKS: Record<Ecl, number[]> = {
  L: [-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8],
  M: [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16],
};
const ECL_BITS: Record<Ecl, number> = { L: 1, M: 0 };
export const MAX_VERSION = 20;

const bit = (x: number, i: number) => ((x >>> i) & 1) !== 0;

export function numRawDataModules(ver: number): number {
  let r = (16 * ver + 128) * ver + 64;
  if (ver >= 2) {
    const na = Math.floor(ver / 7) + 2;
    r -= (25 * na - 10) * na - 55;
    if (ver >= 7) r -= 36;
  }
  return r;
}

export function numDataCodewords(ver: number, ecl: Ecl): number {
  return Math.floor(numRawDataModules(ver) / 8) - ECC_PER_BLOCK[ecl][ver] * NUM_BLOCKS[ecl][ver];
}

// ---- GF(256) / Reed-Solomon ----
function gfMul(x: number, y: number): number {
  let z = 0;
  for (let i = 7; i >= 0; i--) {
    z = (z << 1) ^ ((z >>> 7) * 0x11d);
    z ^= ((y >>> i) & 1) * x;
  }
  return z & 0xff;
}

function rsDivisor(degree: number): number[] {
  const result = new Array(degree).fill(0);
  result[degree - 1] = 1;
  let root = 1;
  for (let i = 0; i < degree; i++) {
    for (let j = 0; j < result.length; j++) {
      result[j] = gfMul(result[j], root);
      if (j + 1 < result.length) result[j] ^= result[j + 1];
    }
    root = gfMul(root, 0x02);
  }
  return result;
}

function rsRemainder(data: number[], divisor: number[]): number[] {
  const result = divisor.map(() => 0);
  for (const b of data) {
    const factor = b ^ (result.shift() as number);
    result.push(0);
    divisor.forEach((coef, i) => (result[i] ^= gfMul(coef, factor)));
  }
  return result;
}

export type QrMatrix = { size: number; version: number; ecl: Ecl; mask: number; get(x: number, y: number): boolean };

export function encodeQr(text: string, preferred: Ecl = "M"): QrMatrix {
  const bytes = Array.from(new TextEncoder().encode(text));
  for (const ecl of preferred === "M" ? (["M", "L"] as Ecl[]) : (["L"] as Ecl[])) {
    for (let ver = 1; ver <= MAX_VERSION; ver++) {
      const countBits = ver < 10 ? 8 : 16;
      const needBits = 4 + countBits + bytes.length * 8;
      if (needBits <= numDataCodewords(ver, ecl) * 8) return build(bytes, ver, ecl);
    }
  }
  throw new Error("Payload too large for a scannable QR");
}

function build(bytes: number[], ver: number, ecl: Ecl): QrMatrix {
  const size = ver * 4 + 17;
  // 1. bit stream
  const bits: number[] = [];
  const push = (val: number, n: number) => {
    for (let i = n - 1; i >= 0; i--) bits.push((val >>> i) & 1);
  };
  push(0b0100, 4);
  push(bytes.length, ver < 10 ? 8 : 16);
  bytes.forEach((b) => push(b, 8));
  const cap = numDataCodewords(ver, ecl) * 8;
  push(0, Math.min(4, cap - bits.length));
  push(0, (8 - (bits.length % 8)) % 8);
  for (let pad = 0xec; bits.length < cap; pad ^= 0xec ^ 0x11) push(pad, 8);
  const data: number[] = [];
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(""), 2));

  // 2. RS + interleave
  const nBlocks = NUM_BLOCKS[ecl][ver];
  const eccLen = ECC_PER_BLOCK[ecl][ver];
  const raw = Math.floor(numRawDataModules(ver) / 8);
  const nShort = nBlocks - (raw % nBlocks);
  const shortLen = Math.floor(raw / nBlocks);
  const div = rsDivisor(eccLen);
  const blocks: number[][] = [];
  for (let i = 0, k = 0; i < nBlocks; i++) {
    const dat = data.slice(k, k + shortLen - eccLen + (i < nShort ? 0 : 1));
    k += dat.length;
    const ecc = rsRemainder(dat, div);
    if (i < nShort) dat.push(0);
    blocks.push(dat.concat(ecc));
  }
  const all: number[] = [];
  for (let i = 0; i < blocks[0].length; i++) {
    blocks.forEach((blk, j) => {
      if (i !== shortLen - eccLen || j >= nShort) all.push(blk[i]);
    });
  }

  // 3. matrix with function patterns
  const { mods, isFn, drawFormat } = drawFunctionPatterns(ver, ecl);

  // 4. place codewords
  let idx = 0;
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++)
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!isFn[y][x] && idx < all.length * 8) {
          mods[y][x] = bit(all[idx >>> 3], 7 - (idx & 7));
          idx++;
        }
      }
  }

  // 5. choose mask
  const applyMask = (m: number) => {
    for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) if (!isFn[y][x] && maskBit(m, x, y)) mods[y][x] = !mods[y][x];
  };
  let best = 0,
    bestPen = Infinity;
  for (let m = 0; m < 8; m++) {
    applyMask(m);
    drawFormat(m);
    const p = penalty(mods, size);
    if (p < bestPen) {
      bestPen = p;
      best = m;
    }
    applyMask(m); // undo
  }
  applyMask(best);
  drawFormat(best);
  const frozen = mods.map((r) => r.slice());
  return { size, version: ver, ecl, mask: best, get: (x, y) => x >= 0 && y >= 0 && x < size && y < size && frozen[y][x] };
}


/** Lay out every non-data module (finders, timing, alignment, format/version areas). Shared with the decoder. */
export function drawFunctionPatterns(ver: number, ecl: Ecl) {
  const size = ver * 4 + 17;
  const mods: boolean[][] = Array.from({ length: size }, () => new Array(size).fill(false));
  const isFn: boolean[][] = Array.from({ length: size }, () => new Array(size).fill(false));
  const setFn = (x: number, y: number, dark: boolean) => {
    mods[y][x] = dark;
    isFn[y][x] = true;
  };
  for (let i = 0; i < size; i++) {
    setFn(6, i, i % 2 === 0);
    setFn(i, 6, i % 2 === 0);
  }
  const finder = (cx: number, cy: number) => {
    for (let dy = -4; dy <= 4; dy++)
      for (let dx = -4; dx <= 4; dx++) {
        const d = Math.max(Math.abs(dx), Math.abs(dy));
        const x = cx + dx,
          y = cy + dy;
        if (x >= 0 && x < size && y >= 0 && y < size) setFn(x, y, d !== 2 && d !== 4);
      }
  };
  finder(3, 3);
  finder(size - 4, 3);
  finder(3, size - 4);
  const align = alignPositions(ver, size);
  for (let a = 0; a < align.length; a++)
    for (let b = 0; b < align.length; b++) {
      if ((a === 0 && b === 0) || (a === 0 && b === align.length - 1) || (a === align.length - 1 && b === 0)) continue;
      for (let dy = -2; dy <= 2; dy++)
        for (let dx = -2; dx <= 2; dx++) setFn(align[a] + dx, align[b] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
  const drawFormat = (mask: number) => {
    const d = (ECL_BITS[ecl] << 3) | mask;
    let rem = d;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    const f = ((d << 10) | rem) ^ 0x5412;
    for (let i = 0; i <= 5; i++) setFn(8, i, bit(f, i));
    setFn(8, 7, bit(f, 6));
    setFn(8, 8, bit(f, 7));
    setFn(7, 8, bit(f, 8));
    for (let i = 9; i < 15; i++) setFn(14 - i, 8, bit(f, i));
    for (let i = 0; i < 8; i++) setFn(size - 1 - i, 8, bit(f, i));
    for (let i = 8; i < 15; i++) setFn(8, size - 15 + i, bit(f, i));
    setFn(8, size - 8, true);
  };
  drawFormat(0); // reserve the area
  if (ver >= 7) {
    let rem = ver;
    for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1f25);
    const v = (ver << 12) | rem;
    for (let i = 0; i < 18; i++) {
      const a = size - 11 + (i % 3),
        b = Math.floor(i / 3);
      setFn(a, b, bit(v, i));
      setFn(b, a, bit(v, i));
    }
  }
  return { size, mods, isFn, drawFormat };
}

export function maskBit(m: number, x: number, y: number): boolean {
  switch (m) {
    case 0: return (x + y) % 2 === 0;
    case 1: return y % 2 === 0;
    case 2: return x % 3 === 0;
    case 3: return (x + y) % 3 === 0;
    case 4: return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0;
    case 5: return ((x * y) % 2) + ((x * y) % 3) === 0;
    case 6: return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0;
    default: return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0;
  }
}

export function alignPositions(ver: number, size: number): number[] {
  if (ver === 1) return [];
  const n = Math.floor(ver / 7) + 2;
  const step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
  const r = [6];
  for (let pos = size - 7, k = n - 1; k > 0; k--, pos -= step) r.splice(1, 0, pos);
  return r;
}

function penalty(m: boolean[][], size: number): number {
  let p = 0;
  const line = (get: (i: number) => boolean) => {
    let run = 1;
    for (let i = 1; i < size; i++) {
      if (get(i) === get(i - 1)) run++;
      else {
        if (run >= 5) p += 3 + (run - 5);
        run = 1;
      }
    }
    if (run >= 5) p += 3 + (run - 5);
  };
  for (let y = 0; y < size; y++) line((i) => m[y][i]);
  for (let x = 0; x < size; x++) line((i) => m[i][x]);
  for (let y = 0; y < size - 1; y++)
    for (let x = 0; x < size - 1; x++) if (m[y][x] === m[y][x + 1] && m[y][x] === m[y + 1][x] && m[y][x] === m[y + 1][x + 1]) p += 3;
  const pat = [true, false, true, true, true, false, true];
  const hit = (get: (i: number) => boolean, i: number) => {
    for (let k = 0; k < 7; k++) if (get(i + k) !== pat[k]) return false;
    const lightBefore = [1, 2, 3, 4].every((d) => i - d < 0 || !get(i - d));
    const lightAfter = [7, 8, 9, 10].every((d) => i + d >= size || !get(i + d));
    return (i - 4 >= 0 && lightBefore) || (i + 10 < size && lightAfter);
  };
  for (let y = 0; y < size; y++) for (let i = 0; i + 7 <= size; i++) if (hit((k) => m[y][k], i)) p += 40;
  for (let x = 0; x < size; x++) for (let i = 0; i + 7 <= size; i++) if (hit((k) => m[k][x], i)) p += 40;
  let dark = 0;
  for (const r of m) for (const v of r) if (v) dark++;
  const total = size * size;
  p += (Math.ceil(Math.abs(dark * 20 - total * 10) / total) - 1) * 10;
  return p;
}

/** Render to an SVG string. Dark modules are merged into one path; quiet zone is part of the viewBox. */
export function qrToSvg(q: QrMatrix, opts: { quiet?: number; fg?: string; bg?: string } = {}): string {
  const quiet = opts.quiet ?? 4;
  const n = q.size + quiet * 2;
  let d = "";
  for (let y = 0; y < q.size; y++) {
    let x = 0;
    while (x < q.size) {
      if (!q.get(x, y)) {
        x++;
        continue;
      }
      let w = 1;
      while (x + w < q.size && q.get(x + w, y)) w++;
      d += `M${x + quiet} ${y + quiet}h${w}v1h-${w}z`;
      x += w;
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${n} ${n}" shape-rendering="crispEdges"><rect width="${n}" height="${n}" fill="${opts.bg ?? "#fff"}"/><path d="${d}" fill="${opts.fg ?? "#000"}"/></svg>`;
}
