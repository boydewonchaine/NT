// Persistent, secret-free app state. The vault ciphertext and public metadata live here; keys never do.

import type { VaultRecord, AttemptState } from "./vault";
import type { PaymentRequest } from "./payload";

export type TxStatus = "signed" | "submitted" | "processing" | "completed" | "failed";

export type TxRecord = {
  id: string; // tx hash (base58) — also the idempotency key
  dir: "out" | "in";
  from: string;
  to: string;
  amount: string; // yocto
  feeEstimate?: string; // yocto
  feeActual?: string; // yocto, once reconciled
  onchainAmount?: string; // yocto: the Transfer deposit the NETWORK reports for this tx (set only once it completed)
  status: TxStatus;
  finality?: string;
  failure?: string;
  requestId?: string;
  note?: string;
  createdAt: number; // ms
  updatedAt: number;
  signed?: string; // base64 of signed tx while unresolved, so a retry re-sends the IDENTICAL transaction
  blockHash?: string; // block that included the tx's outcome (evidence)
  blockTimestamp?: number;
  source: "local" | "index";
};

export type RequestRecord = {
  request: PaymentRequest;
  kind: "open" | "amount";
  state: "open" | "paid" | "expired" | "cancelled";
  paidTx?: string;
  createdAt: number;
};

export type Prefs = { autoLockMin: number };

export type AppState = {
  v: 1;
  vault: VaultRecord | null;
  attempts: AttemptState;
  txs: TxRecord[];
  requests: RequestRecord[];
  prefs: Prefs;
  lastNonce?: string; // highest nonce we have used (guards against stale RPC views)
  /** A name registration that was submitted but not yet confirmed on-chain. Survives reloads; never re-submitted automatically. */
  pending?: { label: string; txHash: string; signerId?: string; at: number };
};

const KEY = "neat.state.v1";

export const emptyState = (): AppState => ({ v: 1, vault: null, attempts: { fails: 0, lockedUntil: 0 }, txs: [], requests: [], prefs: { autoLockMin: 5 } });

let mem: AppState | null = null;
let storage: Pick<Storage, "getItem" | "setItem"> | null = null;

export function useStorage(s: Pick<Storage, "getItem" | "setItem"> | null) {
  storage = s;
  mem = null;
}

function defaultStorage() {
  try {
    return typeof localStorage !== "undefined" ? localStorage : null;
  } catch {
    return null;
  }
}

export function load(): AppState {
  if (mem) return mem;
  const st = storage ?? defaultStorage();
  let s: AppState = emptyState();
  try {
    const raw = st?.getItem(KEY);
    if (raw) s = migrate(JSON.parse(raw));
  } catch {
    // Corrupt state must never be silently replaced if it holds a vault: keep the raw blob for recovery.
    try {
      const raw = st?.getItem(KEY);
      if (raw) st?.setItem(KEY + ".corrupt." + Date.now(), raw);
    } catch {}
  }
  mem = s;
  return s;
}

export function save(): void {
  if (!mem) return;
  try {
    (storage ?? defaultStorage())?.setItem(KEY, JSON.stringify(mem));
  } catch {
    // storage full / blocked: state stays in memory for this session
  }
}

export function update(fn: (s: AppState) => void): AppState {
  const s = load();
  fn(s);
  save();
  return s;
}

function migrate(j: any): AppState {
  const base = emptyState();
  if (!j || typeof j !== "object") return base;
  // v1 is current. Future migrations go here and must never drop `vault`.
  return { ...base, ...j, prefs: { ...base.prefs, ...(j.prefs ?? {}) }, attempts: { ...base.attempts, ...(j.attempts ?? {}) }, txs: j.txs ?? [], requests: j.requests ?? [] };
}

export function upsertTx(t: TxRecord) {
  update((s) => {
    const i = s.txs.findIndex((x) => x.id === t.id);
    if (i >= 0) s.txs[i] = { ...s.txs[i], ...t };
    else s.txs.unshift(t);
    s.txs.sort((a, b) => b.createdAt - a.createdAt);
    if (s.txs.length > 500) s.txs.length = 500;
  });
}

export function getTx(id: string): TxRecord | undefined {
  return load().txs.find((t) => t.id === id);
}
