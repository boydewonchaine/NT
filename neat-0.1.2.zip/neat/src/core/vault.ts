// Encrypted wallet storage.
//
//  • The wallet's ed25519 seed is generated independently by the platform CSPRNG. It is NEVER derived
//    from the recovery sentence.
//  • The sentence only derives a key-encryption key (PBKDF2-HMAC-SHA256, random 16-byte salt).
//  • The seed is sealed with AES-256-GCM (random 12-byte IV). The public key is bound in as additional
//    authenticated data so a record cannot be silently re-labelled with another key. The account id is
//    public, unauthenticated metadata: tampering with it can only make the wallet fail to sign.
//  • Only ciphertext + public metadata are persisted. Nothing here ever touches a network.

import { bs, fromBase64, toBase64, utf8 } from "./encoding";

export const KDF_ITERATIONS = 600_000; // OWASP guidance for PBKDF2-HMAC-SHA256
export const SENTENCE_MIN = 20;
export const SENTENCE_MAX = 100;

export type VaultRecord = {
  v: 1;
  kdf: "PBKDF2-SHA256";
  iter: number;
  salt: string; // b64
  iv: string; // b64
  ct: string; // b64 (seed + GCM tag)
  publicKey: string; // "ed25519:…" (public)
  accountId: string | null; // set once the NEAT name is registered
};

export class WrongSentence extends Error {
  constructor() {
    super("That sentence doesn't match this wallet.");
  }
}

export function normalizeSentence(s: string): string {
  return s.normalize("NFKC").trim().replace(/\s+/g, " ");
}

export type SentenceCheck = { ok: boolean; problems: string[]; level: 0 | 1 | 2 | 3 };

/** Honest strength gate. A sentence can never be stronger than the attacker's guessing cost allows. */
export function checkSentence(raw: string): SentenceCheck {
  const s = normalizeSentence(raw);
  const problems: string[] = [];
  if (s.length < SENTENCE_MIN) problems.push(`Use at least ${SENTENCE_MIN} characters.`);
  if (raw.length > SENTENCE_MAX) problems.push(`Keep it to ${SENTENCE_MAX} characters or fewer.`);
  const words = s.split(" ").filter(Boolean);
  if (words.length < 4) problems.push("Use at least 4 words.");
  if (new Set(s.toLowerCase().replace(/\s/g, "")).size < 8) problems.push("Too repetitive.");
  if (/^(password|letmein|qwerty|123456|iloveyou)/i.test(s.replace(/\s/g, ""))) problems.push("Too common.");
  let level: 0 | 1 | 2 | 3 = 0;
  if (!problems.length) {
    const unique = new Set(words.map((w) => w.toLowerCase())).size;
    level = s.length >= 60 && unique >= 8 ? 3 : s.length >= 40 && unique >= 6 ? 2 : 1;
  }
  return { ok: problems.length === 0, problems, level };
}

async function kek(sentence: string, salt: Uint8Array, iter: number): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey("raw", bs(utf8.enc(normalizeSentence(sentence))), "PBKDF2", false, ["deriveKey"]);
  return crypto.subtle.deriveKey({ name: "PBKDF2", hash: "SHA-256", salt: bs(salt), iterations: iter }, base, { name: "AES-GCM", length: 256 }, false, ["encrypt", "decrypt"]);
}

const aad = (publicKey: string) => utf8.enc(`neat/v1|${publicKey}`);

export async function seal(seed: Uint8Array, publicKey: string, accountId: string | null, sentence: string, iter = KDF_ITERATIONS): Promise<VaultRecord> {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await kek(sentence, salt, iter);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv: bs(iv), additionalData: bs(aad(publicKey)) }, key, bs(seed)));
  return { v: 1, kdf: "PBKDF2-SHA256", iter, salt: toBase64(salt), iv: toBase64(iv), ct: toBase64(ct), publicKey, accountId };
}

/** Returns the seed, or throws WrongSentence. Caller must zero the returned buffer when done. */
export async function open(rec: VaultRecord, sentence: string): Promise<Uint8Array> {
  const key = await kek(sentence, fromBase64(rec.salt), rec.iter);
  try {
    const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv: bs(fromBase64(rec.iv)), additionalData: bs(aad(rec.publicKey)) }, key, bs(fromBase64(rec.ct)));
    return new Uint8Array(pt);
  } catch {
    throw new WrongSentence();
  }
}

// ---------- attempt limiter (client-side deterrent only; see README for the honest threat model) ----------

export type AttemptState = { fails: number; lockedUntil: number };

export function nextDelayMs(fails: number): number {
  if (fails < 3) return 0;
  return Math.min(15 * 60_000, 5_000 * 2 ** (fails - 3));
}

export function registerFailure(s: AttemptState, now = Date.now()): AttemptState {
  const fails = s.fails + 1;
  return { fails, lockedUntil: now + nextDelayMs(fails) };
}
