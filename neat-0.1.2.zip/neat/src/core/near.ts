// NEAR protocol primitives: account-id rules, Borsh transaction encoding, signing.
// Wire format reference: near-primitives Transaction / SignedTransaction (Borsh).
//
//   Transaction { signer_id: string, public_key: PublicKey, nonce: u64, receiver_id: string,
//                 block_hash: [u8;32], actions: Vec<Action> }
//   PublicKey   = u8 key_type (0 = ed25519) + 32 bytes
//   Action      = u8 tag + body    (0 CreateAccount, 2 FunctionCall, 3 Transfer)
//   SignedTx    = Transaction + Signature (u8 key_type + 64 bytes)
//   hash        = sha256(borsh(Transaction)); the signature is over that hash.

import { base58Decode, base58Encode, bs, concat, toHex, utf8 } from "./encoding";

export type Signer = {
  publicKey: Uint8Array; // 32 bytes
  sign(message: Uint8Array): Promise<Uint8Array>; // 64-byte ed25519 signature
};

export type Action =
  | { type: "createAccount" }
  | { type: "transfer"; deposit: bigint }
  | { type: "functionCall"; method: string; args: Uint8Array; gas: bigint; deposit: bigint };

export type Transaction = {
  signerId: string;
  publicKey: Uint8Array;
  nonce: bigint;
  receiverId: string;
  blockHash: Uint8Array;
  actions: Action[];
};

// ---------- account ids ----------

const ACCOUNT_RE = /^(([a-z\d]+[-_])*[a-z\d]+\.)*([a-z\d]+[-_])*[a-z\d]+$/;

export function isValidAccountId(id: string): boolean {
  return id.length >= 2 && id.length <= 64 && ACCOUNT_RE.test(id);
}

export const TESTNET_SUFFIX = ".testnet";

/** Validate the label a user types for their NEAT name (the part before `.testnet`). */
export function validateNameLabel(label: string): { ok: true } | { ok: false; reason: string } {
  if (label.length < 3) return { ok: false, reason: "Use at least 3 characters." };
  if (label.length > 32) return { ok: false, reason: "Use at most 32 characters." };
  if (!/^[a-z0-9_-]+$/.test(label)) return { ok: false, reason: "Lowercase letters, numbers, - and _ only." };
  if (!/^[a-z0-9]/.test(label) || !/[a-z0-9]$/.test(label)) return { ok: false, reason: "Start and end with a letter or number." };
  if (/[-_]{2}/.test(label)) return { ok: false, reason: "No doubled - or _ ." };
  if (/^[0-9a-f]{64}$/.test(label)) return { ok: false, reason: "That looks like an address, not a name." };
  return { ok: true };
}

export function nameToAccountId(label: string): string {
  return label + TESTNET_SUFFIX;
}

/** "dimeji.testnet" -> "dimeji" for display. Falls back to the id for anything else. */
export function displayName(accountId: string): string {
  return accountId.endsWith(TESTNET_SUFFIX) ? accountId.slice(0, -TESTNET_SUFFIX.length) : accountId;
}

// ---------- public key strings ----------

export const keyToString = (pk: Uint8Array) => "ed25519:" + base58Encode(pk);

export function keyFromString(s: string): Uint8Array {
  if (!s.startsWith("ed25519:")) throw new Error("Unsupported key type");
  const b = base58Decode(s.slice(8));
  if (b.length !== 32) throw new Error("Bad public key length");
  return b;
}

// ---------- Borsh writer ----------

class Writer {
  private chunks: number[] = [];
  u8(v: number) {
    this.chunks.push(v & 0xff);
    return this;
  }
  u32(v: number) {
    for (let i = 0; i < 4; i++) this.chunks.push((v >>> (8 * i)) & 0xff);
    return this;
  }
  big(v: bigint, bytes: number) {
    if (v < 0n || v >= 1n << BigInt(8 * bytes)) throw new Error("Integer out of range");
    for (let i = 0; i < bytes; i++) this.chunks.push(Number((v >> BigInt(8 * i)) & 0xffn));
    return this;
  }
  raw(b: Uint8Array) {
    for (const x of b) this.chunks.push(x);
    return this;
  }
  bytes(b: Uint8Array) {
    return this.u32(b.length).raw(b);
  }
  string(s: string) {
    return this.bytes(utf8.enc(s));
  }
  done() {
    return Uint8Array.from(this.chunks);
  }
}

export function encodeTransaction(tx: Transaction): Uint8Array {
  if (tx.publicKey.length !== 32) throw new Error("Public key must be 32 bytes");
  if (tx.blockHash.length !== 32) throw new Error("Block hash must be 32 bytes");
  const w = new Writer();
  w.string(tx.signerId);
  w.u8(0).raw(tx.publicKey);
  w.big(tx.nonce, 8);
  w.string(tx.receiverId);
  w.raw(tx.blockHash);
  w.u32(tx.actions.length);
  for (const a of tx.actions) {
    if (a.type === "createAccount") w.u8(0);
    else if (a.type === "functionCall") {
      w.u8(2).string(a.method).bytes(a.args).big(a.gas, 8).big(a.deposit, 16);
    } else if (a.type === "transfer") w.u8(3).big(a.deposit, 16);
    else throw new Error("Unsupported action");
  }
  return w.done();
}

// ---------- Borsh reader (used to decode and re-verify what we are about to sign / have stored) ----------

class Reader {
  o = 0;
  constructor(private b: Uint8Array) {}
  u8() {
    return this.b[this.o++];
  }
  u32() {
    const v = this.b[this.o] | (this.b[this.o + 1] << 8) | (this.b[this.o + 2] << 16) | (this.b[this.o + 3] << 24);
    this.o += 4;
    return v >>> 0;
  }
  big(n: number) {
    let v = 0n;
    for (let i = 0; i < n; i++) v |= BigInt(this.b[this.o + i]) << BigInt(8 * i);
    this.o += n;
    return v;
  }
  raw(n: number) {
    const s = this.b.slice(this.o, this.o + n);
    if (s.length !== n) throw new Error("Truncated");
    this.o += n;
    return s;
  }
  string() {
    return utf8.dec(this.raw(this.u32()));
  }
  get eof() {
    return this.o >= this.b.length;
  }
}

export function decodeTransaction(bytes: Uint8Array): Transaction & { _len: number } {
  const r = new Reader(bytes);
  const signerId = r.string();
  if (r.u8() !== 0) throw new Error("Unsupported key type");
  const publicKey = r.raw(32);
  const nonce = r.big(8);
  const receiverId = r.string();
  const blockHash = r.raw(32);
  const n = r.u32();
  const actions: Action[] = [];
  for (let i = 0; i < n; i++) {
    const tag = r.u8();
    if (tag === 0) actions.push({ type: "createAccount" });
    else if (tag === 2) {
      const method = r.string();
      const args = r.raw(r.u32());
      const gas = r.big(8);
      const deposit = r.big(16);
      actions.push({ type: "functionCall", method, args, gas, deposit });
    } else if (tag === 3) actions.push({ type: "transfer", deposit: r.big(16) });
    else throw new Error("Unsupported action tag " + tag);
  }
  return { signerId, publicKey, nonce, receiverId, blockHash, actions, _len: r.o };
}

export type SignedTransaction = {
  bytes: Uint8Array; // borsh(SignedTransaction)
  hash: string; // base58 tx hash
  txBytes: Uint8Array;
  signature: Uint8Array;
};

export async function sha256(data: Uint8Array): Promise<Uint8Array> {
  return new Uint8Array(await crypto.subtle.digest("SHA-256", bs(data)));
}

export async function signTransaction(tx: Transaction, signer: Signer): Promise<SignedTransaction> {
  const txBytes = encodeTransaction(tx);
  const digest = await sha256(txBytes);
  const signature = await signer.sign(digest);
  if (signature.length !== 64) throw new Error("Bad signature length");
  return {
    bytes: concat(txBytes, Uint8Array.of(0), signature),
    hash: base58Encode(digest),
    txBytes,
    signature,
  };
}

/** Recompute the transaction hash from signed bytes. Used to re-derive the id of a stored pending tx. */
export async function hashOfSigned(signed: Uint8Array): Promise<string> {
  const { _len } = decodeTransaction(signed);
  return base58Encode(await sha256(signed.slice(0, _len)));
}

export function implicitAccountId(publicKey: Uint8Array): string {
  return toHex(publicKey);
}

// ---------- ed25519 via WebCrypto ----------

const PKCS8_PREFIX = Uint8Array.from([0x30, 0x2e, 0x02, 0x01, 0x00, 0x30, 0x05, 0x06, 0x03, 0x2b, 0x65, 0x70, 0x04, 0x22, 0x04, 0x20]);

export class Ed25519Unsupported extends Error {
  constructor() {
    super("This browser does not support Ed25519 signing. Use a current Chrome, Edge, Safari or Firefox.");
  }
}

/** Generate a fresh keypair with the platform CSPRNG. Returns the 32-byte seed and public key. */
export async function generateKeypair(): Promise<{ seed: Uint8Array; publicKey: Uint8Array }> {
  try {
    const kp = (await crypto.subtle.generateKey({ name: "Ed25519" } as any, true, ["sign", "verify"])) as CryptoKeyPair;
    const pkcs8 = new Uint8Array(await crypto.subtle.exportKey("pkcs8", kp.privateKey));
    const publicKey = new Uint8Array(await crypto.subtle.exportKey("raw", kp.publicKey));
    return { seed: pkcs8.slice(pkcs8.length - 32), publicKey };
  } catch (e) {
    throw new Ed25519Unsupported();
  }
}

/** Import a seed as a NON-extractable signing key. The seed itself should be zeroed by the caller afterwards. */
export async function signerFromSeed(seed: Uint8Array, publicKey: Uint8Array): Promise<Signer> {
  let key: CryptoKey;
  try {
    key = await crypto.subtle.importKey("pkcs8", bs(concat(PKCS8_PREFIX, seed)), { name: "Ed25519" } as any, false, ["sign"]);
  } catch {
    throw new Ed25519Unsupported();
  }
  return {
    publicKey,
    async sign(message) {
      return new Uint8Array(await crypto.subtle.sign({ name: "Ed25519" } as any, key, bs(message)));
    },
  };
}

export async function verifySignature(publicKey: Uint8Array, message: Uint8Array, signature: Uint8Array): Promise<boolean> {
  try {
    const key = await crypto.subtle.importKey("raw", bs(publicKey), { name: "Ed25519" } as any, false, ["verify"]);
    return await crypto.subtle.verify({ name: "Ed25519" } as any, key, bs(signature), bs(message));
  } catch {
    return false;
  }
}

/** Derive the public key from a 32-byte seed (used by the server funder, whose key is supplied as ed25519:<b58 seed+pub>). */
export function parseSecretKey(s: string): { seed: Uint8Array; publicKey: Uint8Array } {
  if (!s.startsWith("ed25519:")) throw new Error("Unsupported key type");
  const b = base58Decode(s.slice(8));
  if (b.length !== 64) throw new Error("Secret key must be 64 bytes (seed + public key)");
  return { seed: b.slice(0, 32), publicKey: b.slice(32) };
}
