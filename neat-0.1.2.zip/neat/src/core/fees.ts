// Fee estimation from live protocol parameters. No figure here is hard-coded: gas unit costs come
// from the node's protocol config, and the gas price from the latest block.

import { Rpc } from "./rpc";

export type FeeEstimate = {
  gasUnits: bigint;
  gasPrice: bigint;
  fee: bigint; // expected network fee in yocto (gasUnits × gasPrice)
  reserve: bigint; // what the runtime holds up front (fee × pessimistic inflation); unused part is refunded
  receiverExists: boolean;
  source: "protocol-config";
  spendable: bigint; // sender balance minus storage stake
  balance: bigint;
};

type Costs = { send_sir: number | string; send_not_sir: number | string; execution: number | string };
const c = (x: Costs, sir: boolean) => BigInt(sir ? x.send_sir : x.send_not_sir) + BigInt(x.execution);

export class FeeError extends Error {}

/**
 * NEAR serialises its rational numbers as a two-element array ([103, 100]); an object form
 * ({numerator, denominator}) is accepted too. Returns null when the value can't be read.
 */
export function parseRatio(x: unknown): { num: bigint; den: bigint } | null {
  try {
    let n: unknown, d: unknown;
    if (Array.isArray(x) && x.length === 2) [n, d] = x;
    else if (x && typeof x === "object") ({ numerator: n, denominator: d } = x as any);
    else return null;
    const num = BigInt(n as any), den = BigInt(d as any);
    return den > 0n && num >= den ? { num, den } : null; // an inflation ratio is never below 1
  } catch {
    return null;
  }
}

export function costsFromConfig(cfg: any) {
  const rc = cfg?.runtime_config;
  const t = rc?.transaction_costs ?? rc?.fees;
  if (!t?.action_receipt_creation_config || !t?.action_creation_config?.transfer_cost) {
    throw new FeeError("The network's fee schedule could not be read.");
  }
  return {
    receipt: t.action_receipt_creation_config as Costs,
    transfer: t.action_creation_config.transfer_cost as Costs,
    createAccount: t.action_creation_config.create_account_cost as Costs | undefined,
    addFullKey: t.action_creation_config.add_key_cost?.full_access_cost as Costs | undefined,
    ratio: parseRatio(t.pessimistic_gas_price_inflation_ratio),
    storagePerByte: BigInt(rc?.storage_amount_per_byte ?? "10000000000000000000"),
  };
}

export async function estimateTransferFee(rpc: Rpc, senderId: string, receiverId: string): Promise<FeeEstimate> {
  const [cfg, price, sender, receiver] = await Promise.all([rpc.protocolConfig(), rpc.gasPrice(), rpc.viewAccount(senderId), rpc.viewAccount(receiverId)]);
  if (!sender) throw new FeeError("Your account was not found on testnet.");
  const k = costsFromConfig(cfg);
  const sir = senderId === receiverId;
  let gas = c(k.receipt, sir) + c(k.transfer, sir);
  const implicit = /^[0-9a-f]{64}$/.test(receiverId);
  if (!receiver && implicit && k.createAccount && k.addFullKey) {
    // transferring to a not-yet-existing implicit account also creates it
    gas += c(k.createAccount, sir) + c(k.addFullKey, sir);
  }
  const fee = gas * price;
  // The runtime holds fee × the "pessimistic" inflation ratio up front and refunds the unused part. The ratio
  // comes from the live config; 103/100 is the protocol's long-standing value, used only if the config omits it
  // (it only sizes a refundable safety margin on the balance check, never the fee we display).
  const { num, den } = k.ratio ?? { num: 103n, den: 100n };
  const reserve = (fee * num) / den + 1n;
  const stake = BigInt(sender.storageUsage) * k.storagePerByte;
  const lockedForStorage = stake > sender.locked ? stake - sender.locked : 0n;
  const spendable = sender.amount > lockedForStorage ? sender.amount - lockedForStorage : 0n;
  return { gasUnits: gas, gasPrice: price, fee, reserve, receiverExists: !!receiver, source: "protocol-config", spendable, balance: sender.amount };
}

export function maxSendable(est: FeeEstimate): bigint {
  return est.spendable > est.reserve ? est.spendable - est.reserve : 0n;
}

/**
 * The one fee line people see, the "stamp fee": what the payment cost in fees. Today that is the NEAR network fee alone
 * (NEAT charges nothing of its own). It is the amount the network actually charged once that is known; until then the
 * estimate, flagged as one. Null when neither exists.
 */
export function stampFee(t: { feeActual?: string; feeEstimate?: string }): { yocto: bigint; actual: boolean } | null {
  if (t.feeActual) return { yocto: BigInt(t.feeActual), actual: true };
  if (t.feeEstimate) return { yocto: BigInt(t.feeEstimate), actual: false };
  return null;
}
