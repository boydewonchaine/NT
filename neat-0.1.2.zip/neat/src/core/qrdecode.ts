// QR decoder for camera frames / uploaded images (byte-mode, ECC L and M, versions 1–20 — what NEAT emits).
// Used when the browser has no native BarcodeDetector (notably iOS Safari). Pipeline:
//   grayscale → adaptive threshold → finder patterns (1:1:3:1:1) → geometry (affine, then homography
//   anchored on the alignment pattern) → grid sampling → format info (BCH) → unmask → de-interleave →
//   Reed-Solomon (Berlekamp–Massey / Chien / Forney) → byte-mode text.

import { drawFunctionPatterns, ECC_PER_BLOCK, MAX_VERSION, maskBit, NUM_BLOCKS, numRawDataModules } from "./qr";

export type RGBA = { data: Uint8ClampedArray | Uint8Array; width: number; height: number };

// ---------------- GF(256) ----------------
const EXP = new Uint8Array(512);
const LOG = new Uint8Array(256);
(() => {
  let x = 1;
  for (let i = 0; i < 255; i++) {
    EXP[i] = x;
    LOG[x] = i;
    x <<= 1;
    if (x & 0x100) x ^= 0x11d;
  }
  for (let i = 255; i < 512; i++) EXP[i] = EXP[i - 255];
})();
const mul = (a: number, b: number) => (a === 0 || b === 0 ? 0 : EXP[LOG[a] + LOG[b]]);
const div = (a: number, b: number) => (a === 0 ? 0 : EXP[(LOG[a] + 255 - LOG[b]) % 255]);

/** Correct `cw` (data then ecc, highest degree first) in place. Returns false if uncorrectable. */
export function rsCorrect(cw: number[], eccLen: number): boolean {
  const n = cw.length;
  const synd: number[] = new Array(eccLen).fill(0);
  let clean = true;
  for (let i = 0; i < eccLen; i++) {
    let s = 0;
    for (let j = 0; j < n; j++) s = mul(s, EXP[i]) ^ cw[j]; // Horner at α^i
    synd[i] = s;
    if (s) clean = false;
  }
  if (clean) return true;

  // Berlekamp–Massey (coefficients lowest degree first)
  let C = [1],
    B = [1];
  let L = 0,
    m = 1,
    b = 1;
  for (let k = 0; k < eccLen; k++) {
    let d = synd[k];
    for (let i = 1; i <= L; i++) d ^= mul(C[i] ?? 0, synd[k - i]);
    if (d === 0) {
      m++;
      continue;
    }
    const T = C.slice();
    const coef = div(d, b);
    while (C.length < B.length + m) C.push(0);
    for (let i = 0; i < B.length; i++) C[i + m] ^= mul(coef, B[i]);
    if (2 * L <= k) {
      L = k + 1 - L;
      B = T;
      b = d;
      m = 1;
    } else m++;
  }
  while (C.length > 1 && C[C.length - 1] === 0) C.pop();
  if (C.length - 1 !== L || L * 2 > eccLen) return false;

  // Chien search: error at array index p ⇔ Λ(α^-(n-1-p)) = 0
  const pos: number[] = [];
  for (let p = 0; p < n; p++) {
    const deg = n - 1 - p;
    const xinv = EXP[(255 - (deg % 255)) % 255];
    let v = 0;
    for (let i = C.length - 1; i >= 0; i--) v = mul(v, xinv) ^ C[i];
    if (v === 0) pos.push(p);
  }
  if (pos.length !== L) return false;

  // Ω(x) = S(x)Λ(x) mod x^eccLen
  const omega: number[] = new Array(eccLen).fill(0);
  for (let i = 0; i < eccLen; i++) for (let j = 0; j < C.length && i + j < eccLen; j++) omega[i + j] ^= mul(synd[i], C[j]);

  for (const p of pos) {
    const deg = n - 1 - p;
    const X = EXP[deg % 255];
    const xinv = EXP[(255 - (deg % 255)) % 255];
    let num = 0;
    for (let i = omega.length - 1; i >= 0; i--) num = mul(num, xinv) ^ omega[i];
    let den = 0; // Λ'(xinv): in characteristic 2 only odd-degree terms survive
    for (let i = 1; i < C.length; i += 2) {
      let pw = 1;
      for (let t = 0; t < i - 1; t++) pw = mul(pw, xinv);
      den ^= mul(C[i], pw);
    }
    if (den === 0) return false;
    cw[p] ^= mul(X, div(num, den)); // fcr = 0  ⇒  e = X · Ω(X⁻¹) / Λ'(X⁻¹)
  }
  for (let i = 0; i < eccLen; i++) {
    let s = 0;
    for (let j = 0; j < n; j++) s = mul(s, EXP[i]) ^ cw[j];
    if (s) return false;
  }
  return true;
}

// ---------------- image → binary ----------------
type Bin = { w: number; h: number; d: Uint8Array }; // 1 = dark

function binarize(img: RGBA): Bin {
  const { width: w, height: h, data } = img;
  const g = new Uint8Array(w * h);
  for (let i = 0, j = 0; i < w * h; i++, j += 4) g[i] = (data[j] * 77 + data[j + 1] * 150 + data[j + 2] * 29) >> 8;
  const integral = new Float64Array((w + 1) * (h + 1));
  for (let y = 0; y < h; y++) {
    let row = 0;
    for (let x = 0; x < w; x++) {
      row += g[y * w + x];
      integral[(y + 1) * (w + 1) + x + 1] = integral[y * (w + 1) + x + 1] + row;
    }
  }
  const half = Math.max(7, Math.round(Math.min(w, h) / 12));
  const d = new Uint8Array(w * h);
  for (let y = 0; y < h; y++) {
    const y0 = Math.max(0, y - half),
      y1 = Math.min(h, y + half + 1);
    for (let x = 0; x < w; x++) {
      const x0 = Math.max(0, x - half),
        x1 = Math.min(w, x + half + 1);
      const sum = integral[y1 * (w + 1) + x1] - integral[y0 * (w + 1) + x1] - integral[y1 * (w + 1) + x0] + integral[y0 * (w + 1) + x0];
      const mean = sum / ((x1 - x0) * (y1 - y0));
      d[y * w + x] = g[y * w + x] < mean * 0.9 ? 1 : 0;
    }
  }
  return { w, h, d };
}

// ---------------- finder patterns ----------------
type Finder = { x: number; y: number; m: number; n: number };

function ratioOk(runs: number[]): number {
  const total = runs[0] + runs[1] + runs[2] + runs[3] + runs[4];
  if (total < 7) return 0;
  const m = total / 7;
  const tol = m * 0.75;
  if (Math.abs(runs[0] - m) > tol || Math.abs(runs[1] - m) > tol || Math.abs(runs[3] - m) > tol || Math.abs(runs[4] - m) > tol) return 0;
  if (Math.abs(runs[2] - 3 * m) > 3 * tol) return 0;
  return m;
}

function crossCheck(b: Bin, x: number, y: number, vertical: boolean, maxModule: number): { c: number; m: number } | null {
  // walk from (x,y) outwards along the axis counting: centre dark, then light, dark, and the opposite
  const get = (t: number) => (vertical ? (t >= 0 && t < b.h ? b.d[t * b.w + x] : -1) : t >= 0 && t < b.w ? b.d[y * b.w + t] : -1);
  const p = vertical ? y : x;
  const runs = [0, 0, 0, 0, 0];
  let t = p;
  while (get(t) === 1) { runs[2]++; t--; if (runs[2] > maxModule * 5) return null; }
  const lo = t;
  while (get(t) === 0) { runs[1]++; t--; if (runs[1] > maxModule * 5) return null; }
  while (get(t) === 1) { runs[0]++; t--; if (runs[0] > maxModule * 5) return null; }
  t = p + 1;
  while (get(t) === 1) { runs[2]++; t++; if (runs[2] > maxModule * 5) return null; }
  const hi = t;
  while (get(t) === 0) { runs[3]++; t++; if (runs[3] > maxModule * 5) return null; }
  while (get(t) === 1) { runs[4]++; t++; if (runs[4] > maxModule * 5) return null; }
  const m = ratioOk(runs);
  if (!m) return null;
  return { c: (lo + 1 + hi) / 2, m };
}

function findFinders(b: Bin): Finder[] {
  const found: Finder[] = [];
  for (let y = 0; y < b.h; y++) {
    const runs: number[] = [];
    const starts: number[] = [];
    let cur = b.d[y * b.w],
      start = 0;
    for (let x = 1; x <= b.w; x++) {
      const v = x < b.w ? b.d[y * b.w + x] : -1;
      if (v !== cur) {
        runs.push(x - start);
        starts.push(start);
        if (runs.length >= 5 && cur === 1) {
          const k = runs.length - 5; // window of 5 runs ending with a dark run
          const w5 = runs.slice(k);
          const m = ratioOk(w5);
          if (m) {
            const cx = starts[k] + w5[0] + w5[1] + w5[2] / 2;
            const vy = crossCheck(b, Math.round(cx), y, true, Math.max(m * 2, 4));
            if (vy) {
              const hx = crossCheck(b, Math.round(cx), Math.round(vy.c), false, Math.max(m * 2, 4));
              if (hx) {
                const f = { x: hx.c, y: vy.c, m: (vy.m + hx.m) / 2, n: 1 };
                const near = found.find((q) => Math.hypot(q.x - f.x, q.y - f.y) < Math.max(q.m, f.m) * 3 && Math.abs(q.m - f.m) < Math.max(q.m, f.m) * 0.5);
                if (near) {
                  near.x = (near.x * near.n + f.x) / (near.n + 1);
                  near.y = (near.y * near.n + f.y) / (near.n + 1);
                  near.m = (near.m * near.n + f.m) / (near.n + 1);
                  near.n++;
                } else found.push(f);
              }
            }
          }
        }
        cur = v;
        start = x;
      }
    }
  }
  return found.filter((f) => f.n >= 2).sort((a, b) => b.n - a.n);
}

type Pt = { x: number; y: number };
type Triple = { tl: Finder; tr: Finder; bl: Finder; m: number };

/** Module size measured along the code's own axes (immune to rotation, unlike scan-line runs). */
function axisModule(b: Bin, f: Finder, ax: Pt, ay: Pt): number {
  const ests: number[] = [];
  for (const dir of [ax, ay, { x: -ax.x, y: -ax.y }, { x: -ay.x, y: -ay.y }]) {
    let last = 1, edges = 0;
    for (let t = 0; t < f.m * 7; t += 0.25) {
      const px = Math.round(f.x + dir.x * t), py = Math.round(f.y + dir.y * t);
      if (px < 0 || py < 0 || px >= b.w || py >= b.h) break;
      const v = b.d[py * b.w + px];
      if (v !== last) {
        last = v;
        if (++edges === 3) { ests.push(t / 3.5); break; }
      }
    }
  }
  if (ests.length < 2) return f.m;
  ests.sort((x, y) => x - y);
  return ests[Math.floor(ests.length / 2)];
}

function finderMatch(b: Bin, f: Finder, ax: Pt, ay: Pt): number {
  // compare a 7×7 window around the candidate with the ideal finder pattern (dark ring, light ring, dark core)
  let ok = 0;
  for (let j = -3; j <= 3; j++)
    for (let i = -3; i <= 3; i++) {
      const px = Math.round(f.x + (i * ax.x + j * ay.x) * f.m);
      const py = Math.round(f.y + (i * ax.y + j * ay.y) * f.m);
      if (px < 0 || py < 0 || px >= b.w || py >= b.h) continue;
      const want = Math.max(Math.abs(i), Math.abs(j)) !== 2 ? 1 : 0;
      if (b.d[py * b.w + px] === want) ok++;
    }
  return ok; // max 49
}

function pickTriples(fs: Finder[], b?: Bin): Triple[] {
  const out: { t: Triple; score: number }[] = [];
  const n = Math.min(fs.length, 14);
  for (let i = 0; i < n; i++)
    for (let j = i + 1; j < n; j++)
      for (let k = j + 1; k < n; k++) {
        const t = [fs[i], fs[j], fs[k]];
        const ms = t.map((f) => f.m);
        if (Math.max(...ms) / Math.min(...ms) > 1.6) continue;
        const d = (a: Finder, b: Finder) => Math.hypot(a.x - b.x, a.y - b.y);
        const dab = d(t[0], t[1]), dbc = d(t[1], t[2]), dac = d(t[0], t[2]);
        // corner = vertex opposite the longest side
        let tl: Finder, a: Finder, c: Finder, hyp: number, s1: number, s2: number;
        if (dab >= dbc && dab >= dac) { tl = t[2]; a = t[0]; c = t[1]; hyp = dab; s1 = dac; s2 = dbc; }
        else if (dbc >= dab && dbc >= dac) { tl = t[0]; a = t[1]; c = t[2]; hyp = dbc; s1 = dab; s2 = dac; }
        else { tl = t[1]; a = t[0]; c = t[2]; hyp = dac; s1 = dab; s2 = dbc; }
        const ratio = s1 / s2;
        if (ratio < 0.7 || ratio > 1.4) continue;
        const cosv = (s1 * s1 + s2 * s2 - hyp * hyp) / (2 * s1 * s2);
        if (Math.abs(cosv) > 0.45) continue; // not roughly 90°
        const cross = (a.x - tl.x) * (c.y - tl.y) - (a.y - tl.y) * (c.x - tl.x);
        const tr = cross > 0 ? a : c;
        const bl = cross > 0 ? c : a;
        const dTR = Math.hypot(tr.x - tl.x, tr.y - tl.y), dBL = Math.hypot(bl.x - tl.x, bl.y - tl.y);
        const ax = { x: (tr.x - tl.x) / dTR, y: (tr.y - tl.y) / dTR };
        const ay = { x: (bl.x - tl.x) / dBL, y: (bl.y - tl.y) / dBL };
        const mA = b ? (axisModule(b, tl, ax, ay) + axisModule(b, tr, ax, ay) + axisModule(b, bl, ax, ay)) / 3 : (tl.m + tr.m + bl.m) / 3;
        // the implied symbol size must be (close to) a real QR dimension 17 + 4v
        const est = (dTR + dBL) / 2 / mA + 7;
        const v = Math.round((est - 17) / 4);
        if (v < 1 || v > MAX_VERSION + 2 || Math.abs(est - (17 + 4 * v)) > 3) continue;
        let score = -Math.abs(cosv) * 4 - Math.abs(1 - ratio) * 4 - Math.abs(est - (17 + 4 * v));
        if (b) {
          const m3 = finderMatch(b, { ...tl, m: mA }, ax, ay) + finderMatch(b, { ...tr, m: mA }, ax, ay) + finderMatch(b, { ...bl, m: mA }, ax, ay);
          if (m3 < 100) continue; // of 147; a wrong triple is harmless because Reed-Solomon rejects it
          score += m3;
        }
        out.push({ t: { tl, tr, bl, m: mA }, score });
      }
  return out.sort((x, y) => y.score - x.score).map((o) => o.t);
}

// ---------------- geometry ----------------
type Xform = (u: number, v: number) => Pt; // module coords → pixel

function affine(t: Triple, dim: number): Xform {
  const sx = (t.tr.x - t.tl.x) / (dim - 7),
    sy = (t.tr.y - t.tl.y) / (dim - 7);
  const ux = (t.bl.x - t.tl.x) / (dim - 7),
    uy = (t.bl.y - t.tl.y) / (dim - 7);
  return (u, v) => ({ x: t.tl.x + (u - 3.5) * sx + (v - 3.5) * ux, y: t.tl.y + (u - 3.5) * sy + (v - 3.5) * uy });
}

function homography(src: Pt[], dst: Pt[]): Xform | null {
  // solve 8x8 for h (h33 = 1): module (u,v) → pixel (x,y)
  const A: number[][] = [];
  for (let i = 0; i < 4; i++) {
    const { x: u, y: v } = src[i];
    const { x, y } = dst[i];
    A.push([u, v, 1, 0, 0, 0, -u * x, -v * x, x]);
    A.push([0, 0, 0, u, v, 1, -u * y, -v * y, y]);
  }
  for (let c = 0; c < 8; c++) {
    let piv = c;
    for (let r = c + 1; r < 8; r++) if (Math.abs(A[r][c]) > Math.abs(A[piv][c])) piv = r;
    if (Math.abs(A[piv][c]) < 1e-9) return null;
    [A[c], A[piv]] = [A[piv], A[c]];
    for (let r = 0; r < 8; r++) {
      if (r === c) continue;
      const f = A[r][c] / A[c][c];
      for (let k = c; k < 9; k++) A[r][k] -= f * A[c][k];
    }
  }
  const h = A.map((row, i) => row[8] / row[i]);
  return (u, v) => {
    const w = h[6] * u + h[7] * v + 1;
    return { x: (h[0] * u + h[1] * v + h[2]) / w, y: (h[3] * u + h[4] * v + h[5]) / w };
  };
}

function findAlignment(b: Bin, aff: Xform, dim: number, mpx: number): Pt | null {
  const target = { u: dim - 6.5, v: dim - 6.5 };
  const guess = aff(target.u, target.v);
  const pat = (du: number, dv: number) => (Math.max(Math.abs(du), Math.abs(dv)) !== 1 ? 1 : 0); // 5×5 ring pattern, dark = 1
  let best: Pt | null = null,
    bestScore = -1;
  const r = 8; // perspective can displace the far corner by several modules
  for (let su = -r; su <= r; su += 0.5)
    for (let sv = -r; sv <= r; sv += 0.5) {
      const c = aff(target.u + su, target.v + sv);
      let s = 0;
      for (let dv = -2; dv <= 2; dv++)
        for (let du = -2; du <= 2; du++) {
          const p = aff(target.u + su + du, target.v + sv + dv);
          const px = Math.round(p.x), py = Math.round(p.y);
          if (px < 0 || py < 0 || px >= b.w || py >= b.h) continue;
          if (b.d[py * b.w + px] === pat(du, dv)) s++;
        }
      const adj = s - 0.01 * Math.hypot(su, sv); // prefer the candidate nearest the prediction on ties
      if (adj > bestScore) { bestScore = adj; best = c; }
    }
  void guess;
  void mpx;
  return bestScore >= 21 ? best : null;
}

// ---------------- decoding the sampled grid ----------------
const FORMAT_CODES: { bits: number; data: number }[] = (() => {
  const out: { bits: number; data: number }[] = [];
  for (let d = 0; d < 32; d++) {
    let rem = d;
    for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
    out.push({ bits: ((d << 10) | rem) ^ 0x5412, data: d });
  }
  return out;
})();
const popcount = (x: number) => { let c = 0; while (x) { c += x & 1; x >>>= 1; } return c; };

function readFormat(g: (x: number, y: number) => boolean, size: number): { ecl: "L" | "M" | "Q" | "H"; mask: number } | null {
  const bit = (v: boolean) => (v ? 1 : 0);
  let a = 0;
  for (let i = 0; i <= 5; i++) a |= bit(g(8, i)) << i;
  a |= bit(g(8, 7)) << 6; a |= bit(g(8, 8)) << 7; a |= bit(g(7, 8)) << 8;
  for (let i = 9; i < 15; i++) a |= bit(g(14 - i, 8)) << i;
  let c = 0;
  for (let i = 0; i < 8; i++) c |= bit(g(size - 1 - i, 8)) << i;
  for (let i = 8; i < 15; i++) c |= bit(g(8, size - 15 + i)) << i;
  let best: { d: number; data: number } | null = null;
  for (const f of FORMAT_CODES) {
    const d = Math.min(popcount(f.bits ^ a), popcount(f.bits ^ c));
    if (!best || d < best.d) best = { d, data: f.data };
  }
  if (!best || best.d > 3) return null;
  const eclBits = best.data >> 3;
  return { ecl: ({ 1: "L", 0: "M", 3: "Q", 2: "H" } as const)[eclBits as 0 | 1 | 2 | 3], mask: best.data & 7 };
}

function decodeGrid(g: (x: number, y: number) => boolean, ver: number): string | null {
  const size = ver * 4 + 17;
  const fmt = readFormat(g, size);
  if (!fmt || (fmt.ecl !== "L" && fmt.ecl !== "M")) return null;
  const ecl = fmt.ecl;
  const { isFn } = drawFunctionPatterns(ver, ecl);
  // read codeword bits
  const bits: number[] = [];
  for (let right = size - 1; right >= 1; right -= 2) {
    if (right === 6) right = 5;
    for (let vert = 0; vert < size; vert++)
      for (let j = 0; j < 2; j++) {
        const x = right - j;
        const upward = ((right + 1) & 2) === 0;
        const y = upward ? size - 1 - vert : vert;
        if (!isFn[y][x]) bits.push((g(x, y) !== maskBit(fmt.mask, x, y) ? 1 : 0));
      }
  }
  const raw = Math.floor(numRawDataModules(ver) / 8);
  const bytes: number[] = [];
  for (let i = 0; i < raw; i++) {
    let v = 0;
    for (let k = 0; k < 8; k++) v = (v << 1) | (bits[i * 8 + k] ?? 0);
    bytes.push(v);
  }
  // de-interleave
  const nBlocks = NUM_BLOCKS[ecl][ver], eccLen = ECC_PER_BLOCK[ecl][ver];
  const nShort = nBlocks - (raw % nBlocks), shortLen = Math.floor(raw / nBlocks);
  const dataLen = (j: number) => shortLen - eccLen + (j < nShort ? 0 : 1);
  const blocks: number[][] = Array.from({ length: nBlocks }, () => []);
  let p = 0;
  for (let i = 0; i < shortLen - eccLen + 1; i++) for (let j = 0; j < nBlocks; j++) if (i < dataLen(j)) blocks[j].push(bytes[p++]);
  for (let i = 0; i < eccLen; i++) for (let j = 0; j < nBlocks; j++) blocks[j].push(bytes[p++]);
  const data: number[] = [];
  for (let j = 0; j < nBlocks; j++) {
    if (!rsCorrect(blocks[j], eccLen)) return null;
    data.push(...blocks[j].slice(0, dataLen(j)));
  }
  return parseStream(data, ver);
}

function parseStream(data: number[], ver: number): string | null {
  let pos = 0;
  const total = data.length * 8;
  const read = (n: number) => {
    let v = 0;
    for (let i = 0; i < n; i++, pos++) v = (v << 1) | ((data[pos >> 3] >> (7 - (pos & 7))) & 1);
    return v;
  };
  const out: number[] = [];
  while (pos + 4 <= total) {
    const mode = read(4);
    if (mode === 0) break;
    if (mode === 7) { // ECI designator: skip
      const first = read(8);
      if (first & 0x80) read(8);
      continue;
    }
    if (mode !== 4) return null; // only byte mode is produced by NEAT
    const n = read(ver < 10 ? 8 : 16);
    if (pos + n * 8 > total) return null;
    for (let i = 0; i < n; i++) out.push(read(8));
  }
  try {
    return new TextDecoder("utf-8", { fatal: true }).decode(Uint8Array.from(out));
  } catch {
    return null;
  }
}

// ---------------- entry point ----------------
function sampleGrid(b: Bin, xf: Xform, size: number): (x: number, y: number) => boolean {
  const cache = new Uint8Array(size * size);
  const off = [[0, 0], [0.22, 0], [-0.22, 0], [0, 0.22], [0, -0.22]];
  for (let v = 0; v < size; v++)
    for (let u = 0; u < size; u++) {
      let dark = 0;
      for (const [du, dv] of off) {
        const p = xf(u + 0.5 + du, v + 0.5 + dv);
        const px = Math.round(p.x - 0.5), py = Math.round(p.y - 0.5);
        if (px >= 0 && py >= 0 && px < b.w && py < b.h && b.d[py * b.w + px]) dark++;
      }
      cache[v * size + u] = dark >= 3 ? 1 : 0;
    }
  return (x, y) => cache[y * size + x] === 1;
}

export function decodeQr(img: RGBA): string | null {
  const b = binarize(img);
  const finders = findFinders(b);
  if (finders.length < 3) return null;
  for (const t of pickTriples(finders, b).slice(0, 6)) {
    const m = t.m;
    const d1 = Math.hypot(t.tr.x - t.tl.x, t.tr.y - t.tl.y), d2 = Math.hypot(t.bl.x - t.tl.x, t.bl.y - t.tl.y);
    const est = (d1 + d2) / 2 / m + 7;
    const baseVer = Math.round((est - 17) / 4);
    for (const dv of [0, -1, 1, -2, 2]) {
      const ver = baseVer + dv;
      if (ver < 1 || ver > MAX_VERSION) continue;
      const size = ver * 4 + 17;
      const aff = affine(t, size);
      const tries: Xform[] = [aff];
      if (ver >= 2) {
        const al = findAlignment(b, aff, size, m);
        if (al) {
          const H = homography(
            [{ x: 3.5, y: 3.5 }, { x: size - 3.5, y: 3.5 }, { x: 3.5, y: size - 3.5 }, { x: size - 6.5, y: size - 6.5 }],
            [t.tl, t.tr, t.bl, al]
          );
          if (H) tries.unshift(H);
        }
      }
      for (const xf of tries) {
        const text = decodeGrid(sampleGrid(b, xf, size), ver);
        if (text !== null) return text;
      }
    }
  }
  return null;
}

/** exposed for tests/diagnostics only */
export const _internals = { binarize, findFinders, pickTriples, affine, decodeGrid, sampleGrid, readFormat };
