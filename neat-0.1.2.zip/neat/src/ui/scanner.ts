// Camera + image QR reading. Uses the native BarcodeDetector where available (Chrome/Android/Edge) and
// falls back to NEAT's own decoder (src/core/qrdecode.ts) everywhere else, notably iOS Safari.
import { decodeQr } from "../core/qrdecode";

type NativeDetector = { detect(src: any): Promise<{ rawValue: string }[]> };
let native: NativeDetector | null | undefined;

async function nativeDetector(): Promise<NativeDetector | null> {
  if (native !== undefined) return native;
  native = null;
  try {
    const BD = (globalThis as any).BarcodeDetector;
    if (BD) {
      const formats: string[] = (await BD.getSupportedFormats?.()) ?? ["qr_code"];
      if (formats.includes("qr_code")) native = new BD({ formats: ["qr_code"] });
    }
  } catch {
    native = null;
  }
  return native ?? null;
}

export const hasCamera = () => !!navigator.mediaDevices?.getUserMedia;

function toImageData(src: CanvasImageSource, w: number, h: number, maxSide: number): ImageData {
  const scale = Math.min(1, maxSide / Math.max(w, h));
  const cw = Math.max(1, Math.round(w * scale)), ch = Math.max(1, Math.round(h * scale));
  const c = document.createElement("canvas");
  c.width = cw;
  c.height = ch;
  const ctx = c.getContext("2d", { willReadFrequently: true })!;
  ctx.drawImage(src, 0, 0, cw, ch);
  return ctx.getImageData(0, 0, cw, ch);
}

/** Decode one frame/bitmap. `deep` also retries at several scales (for uploaded photos). */
export async function decodeSource(src: CanvasImageSource & { width?: number; height?: number }, w: number, h: number, deep = false): Promise<string | null> {
  const nd = await nativeDetector();
  if (nd) {
    try {
      const r = await nd.detect(src);
      if (r[0]?.rawValue) return r[0].rawValue;
    } catch {
      /* fall through to software decoder */
    }
  }
  for (const side of deep ? [1000, 1600, 640, 420] : [720]) {
    const text = decodeQr(toImageData(src, w, h, side));
    if (text) return text;
  }
  return null;
}

export async function decodeImageFile(file: File): Promise<string | null> {
  let bmp: ImageBitmap;
  try {
    bmp = await createImageBitmap(file);
  } catch {
    throw new Error("That file couldn't be read as an image.");
  }
  try {
    return await decodeSource(bmp, bmp.width, bmp.height, true);
  } finally {
    bmp.close?.();
  }
}

export type Camera = { stop(): void };

export async function startCamera(video: HTMLVideoElement, onText: (t: string) => void): Promise<Camera> {
  const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: "environment" }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
  video.srcObject = stream;
  video.setAttribute("playsinline", "");
  video.muted = true;
  await video.play();
  let stopped = false;
  let busy = false;
  const tick = async () => {
    if (stopped) return;
    if (!busy && video.videoWidth) {
      busy = true;
      try {
        const t = await decodeSource(video, video.videoWidth, video.videoHeight);
        if (t && !stopped) onText(t);
      } catch {
        /* keep scanning */
      }
      busy = false;
    }
    if (!stopped) setTimeout(tick, 110);
  };
  tick();
  return {
    stop() {
      stopped = true;
      stream.getTracks().forEach((t) => t.stop());
      video.srcObject = null;
    },
  };
}
