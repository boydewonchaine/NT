// Shared UI building blocks.
import { h } from "./dom";
import { icon, chevron } from "./icons";
import { AppCtx, CONFIG, Route } from "./app";
import { formatFee, formatNear } from "../core/units";
import type { TxRecord, TxStatus } from "../core/store";
import type { VaultRecord } from "../core/vault";

/**
 * The bar at the top of a screen. Its title is the screen's <h1> unless the screen has a bigger heading of its own
 * (`heading: false`), so every screen has exactly one top-level heading for assistive technology.
 */
export function top(A: AppCtx, title: string, back?: Route | (() => void), right?: HTMLElement | null, heading = true) {
  const go = () => (typeof back === "function" ? back() : back ? A.go(back) : undefined);
  return h(
    "header",
    { class: "top" },
    back ? h("button", { class: "iconbtn", "aria-label": "Back", onClick: go }, icon("back")) : h("span", { style: { width: "44px" } }),
    h(heading ? "h1" : "div", { class: "t" }, title),
    right ?? h("span", { style: { width: "44px" } })
  );
}

export const netChip = (online = true) => h("span", { class: "net" + (online ? "" : " off"), title: "NEAR Testnet" }, h("i"), "Testnet");

export const brand = () => h("div", { class: "brandrow" }, chevron(), h("b", { style: { letterSpacing: "0.14em", fontSize: "15px" } }, "NEAT"));

export const nearAmt = (yocto: bigint | string, d = 5) => formatNear(BigInt(yocto), d);

export function statusChip(status: TxStatus | "open" | "paid" | "expired" | "cancelled") {
  const map: Record<string, [string, string]> = {
    signed: ["Not confirmed sent", "ring"],
    submitted: ["Submitted", "ring"],
    processing: ["Confirming", "half"],
    completed: ["Completed", "ok"],
    failed: ["Failed", "bad"],
    open: ["Open", "ring"],
    paid: ["Paid", "ok"],
    expired: ["Expired", "bad"],
    cancelled: ["Cancelled", "ring"],
  };
  const [label, cls] = map[status];
  return h("span", { class: "chip " + cls }, h("i"), label);
}

/** One printed line on a receipt slip: the label on the left, the value on the right. */
export function ln(k: string, v: string | Node, cls = "") {
  return h("div", { class: "ln " + cls }, h("span", { class: "k" }, k), h("span", { class: "v" }, v));
}

/** The date and the time printed on a receipt, in the reader's own locale and time zone (the zone is shown so the time is unambiguous). */
export function stampTime(ms: number) {
  const d = new Date(ms);
  return {
    date: d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" }),
    time: d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", second: "2-digit", timeZoneName: "short" }),
  };
}

/** The boxed status mark at the foot of a receipt. Only a payment the network has finalised reads "Completed". */
export function statusStamp(status: TxStatus) {
  const map: Record<TxStatus, [string, string]> = {
    signed: ["Not confirmed sent", "wait"],
    submitted: ["Submitted", "wait"],
    processing: ["Confirming", "wait"],
    completed: ["Completed", "ok"],
    failed: ["Failed", "bad"],
  };
  const [label, cls] = map[status];
  return h("span", { class: "stamp " + cls }, label);
}

export const explorerUrl = (hash: string) => `${CONFIG.explorer}/txns/${encodeURIComponent(hash)}`;

export function explorerLink(hash: string, label = "View on NearBlocks") {
  return h("a", { class: "kv-link", href: explorerUrl(hash), target: "_blank", rel: "noopener noreferrer" }, label);
}

/** What we can truthfully say about a payment that didn't complete. A failed execution still burns gas. */
export function failureSummary(t: TxRecord): string {
  const why = t.failure ?? "The network reported a failure.";
  const fee = t.feeActual && BigInt(t.feeActual) > 0n ? ` The stamp fee (${formatFee(BigInt(t.feeActual))} NEAR) was still charged.` : "";
  return `${why} The amount was not delivered.${fee}`;
}

export const shortHash = (s: string) => (s.length > 18 ? s.slice(0, 8) + "…" + s.slice(-6) : s);

export function row(k: string, v: string | Node, cls = "") {
  return h("div", { class: "row " + cls }, h("span", { class: "k" }, k), h("span", { class: "v" }, v));
}

export function spinnerLine(text: string) {
  return h("div", { class: "muted small", style: { display: "flex", alignItems: "center", gap: "10px" }, role: "status" }, h("span", { class: "spin" }), text);
}

/** Save the encrypted vault as a file. It is useless without the sentence. */
export function downloadBackup(rec: VaultRecord, name?: string | null) {
  const payload = JSON.stringify({ app: "neat", format: 1, network: "testnet", vault: rec }, null, 1);
  const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
  const a = h("a", { href: url, download: `neat-${name ?? "wallet"}.neat` });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}

export function parseBackup(text: string): VaultRecord | null {
  try {
    const j = JSON.parse(text);
    const v = j?.vault;
    if (j?.app !== "neat" || j?.format !== 1 || !v) return null;
    const okStr = (x: any, max = 4096) => typeof x === "string" && x.length > 0 && x.length < max;
    if (v.v !== 1 || v.kdf !== "PBKDF2-SHA256" || !Number.isInteger(v.iter) || v.iter < 100_000 || v.iter > 10_000_000) return null;
    if (![v.salt, v.iv, v.ct, v.publicKey].every((x) => okStr(x))) return null;
    if (!(v.accountId === null || (typeof v.accountId === "string" && v.accountId.length < 70))) return null;
    return { v: 1, kdf: "PBKDF2-SHA256", iter: v.iter, salt: v.salt, iv: v.iv, ct: v.ct, publicKey: v.publicKey, accountId: v.accountId };
  } catch {
    return null;
  }
}

export function txTitle(t: TxRecord) {
  return t.dir === "out" ? t.to : t.from;
}

export function confirmSheet(A: AppCtx, o: { title: string; body: (Node | string)[]; confirm: string; danger?: boolean; onConfirm: () => void | Promise<void> }) {
  let close = () => {};
  const content = h(
    "div",
    { class: "stack" },
    h("h2", { class: "title", style: { fontSize: "24px" } }, o.title),
    h("div", { class: "prose" }, ...o.body.map((b) => (typeof b === "string" ? h("p", null, b) : b))),
    h(
      "div",
      { class: "actions" },
      h("button", { class: "btn" + (o.danger ? " danger" : ""), onClick: async () => { close(); await o.onConfirm(); } }, o.confirm),
      h("button", { class: "btn sec", onClick: () => close() }, "Cancel")
    )
  );
  close = A.sheet(content, o.title);
}
