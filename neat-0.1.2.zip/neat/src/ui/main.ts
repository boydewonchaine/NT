import "./styles.css";
import { AppCtx, CONFIG } from "./app";
import { setIndexBase } from "../core/history";
import { h, reducedMotion, sleep } from "./dom";
import { chevron } from "./icons";
import * as store from "../core/store";
import { createView, identityView, restoreView, unlockView } from "./views-auth";
import { amountView, processingView, receiptView, receiveView, reviewView, scanView } from "./views-pay";
import { activityView, homeView, settingsView } from "./views-main";

declare const __NEAT_SW__: boolean | undefined;

const root = document.getElementById("app")!;
const A = new AppCtx(root);
setIndexBase(CONFIG.index);

A.register("create", createView);
A.register("restore", restoreView);
A.register("unlock", unlockView);
A.register("identity", identityView);
A.register("home", homeView);
A.register("receive", receiveView);
A.register("scan", scanView);
A.register("amount", amountView);
A.register("review", reviewView);
A.register("processing", processingView);
A.register("receipt", receiptView);
A.register("activity", activityView);
A.register("settings", settingsView);
A.register("splash", () => h("main", { class: "screen splash", "aria-label": "NEAT" }, chevron("mark")));

window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  A.installEvent = e;
});
window.addEventListener("appinstalled", () => (A.installEvent = null));

async function boot() {
  A.renderBanner();
  await A.go({ r: "splash" });
  const t0 = Date.now();
  const state = store.load(); // load (and, if needed, migrate) before deciding where to go
  await sleep(reducedMotion() ? 150 : Math.max(0, 1050 - (Date.now() - t0)));
  const splash = root.querySelector(".splash");
  if (splash && !reducedMotion()) {
    splash.classList.add("out");
    await sleep(240);
  }
  A.go({ r: state.vault ? "unlock" : "create" });
}

if ("serviceWorker" in navigator && (typeof __NEAT_SW__ === "undefined" || __NEAT_SW__)) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}

boot();
