// Static, hand-authored SVG icons (stroke-based, inherit currentColor). No external icon set.
import { svgFrom } from "./dom";

const wrap = (inner: string, vb = "0 0 24 24") =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${vb}" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${inner}</svg>`;

const P = {
  receive: wrap('<path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>'),
  send: wrap('<path d="M12 20V9"/><path d="m7 13 5-5 5 5"/><path d="M5 4h14"/>'),
  back: wrap('<path d="m15 5-7 7 7 7"/>'),
  close: wrap('<path d="m6 6 12 12M18 6 6 18"/>'),
  settings: wrap('<circle cx="12" cy="12" r="3"/><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M18.4 5.6l-1.8 1.8M7.4 16.6l-1.8 1.8"/>'),
  activity: wrap('<path d="M4 12h4l2-6 4 12 2-6h4"/>'),
  lock: wrap('<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'),
  scan: wrap('<path d="M4 8V5a1 1 0 0 1 1-1h3M16 4h3a1 1 0 0 1 1 1v3M20 16v3a1 1 0 0 1-1 1h-3M8 20H5a1 1 0 0 1-1-1v-3"/><path d="M4 12h16"/>'),
  image: wrap('<rect x="4" y="5" width="16" height="14" rx="2"/><circle cx="9" cy="10" r="1.5"/><path d="m5 17 5-4 3 2 3-3 3 3"/>'),
  download: wrap('<path d="M12 4v11"/><path d="m7 11 5 5 5-5"/><path d="M5 20h14"/>'),
  check: wrap('<path d="m5 12.5 4.5 4.5L19 7.5"/>'),
  alert: wrap('<path d="M12 4 3 20h18L12 4Z"/><path d="M12 10v4M12 17.5v.01"/>'),
  external: wrap('<path d="M14 5h5v5"/><path d="M19 5 10 14"/><path d="M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4"/>'),
  share: wrap('<circle cx="6" cy="12" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="18" cy="18" r="2"/><path d="m8 11 8-4M8 13l8 4"/>'),
  wifi: wrap('<path d="M3 9a14 14 0 0 1 18 0M6 12.5a9 9 0 0 1 12 0M9 16a4.5 4.5 0 0 1 6 0"/><path d="M12 19.5v.01"/>'),
};

export type IconName = keyof typeof P;
export const icon = (n: IconName) => svgFrom(P[n]);

/** The NEAT chevron (traced from the official logo). */
export const chevron = (cls = "") =>
  svgFrom(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 76.1 78" class="${cls}" role="img" aria-label="NEAT"><path fill="currentColor" d="M.1 0 .5 10.5 61.1 40.5 .8 66.4.4 78 76.1 44.8 76 37.1Z"/></svg>`);
