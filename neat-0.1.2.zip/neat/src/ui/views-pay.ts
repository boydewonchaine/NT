import { AppCtx } from "./app";
import { compactAccount, h, sleep, svgFrom, put } from "./dom";
import { brand, explorerLink, failureSummary, ln, netChip, nearAmt, row, shortHash, spinnerLine, stampTime, statusChip, statusStamp, top } from "./parts";
import { chevron, icon } from "./icons";
import * as store from "../core/store";
import { encodeQr, qrToSvg } from "../core/qr";
import { createRequest, parseRequest, PaymentRequest, verifyRequest, MAX_NOTE } from "../core/payload";
import { displayName } from "../core/near";
import { formatFee, formatNear, parseNear } from "../core/units";
import { estimateTransferFee, FeeEstimate, FeeError, maxSendable, stampFee } from "../core/fees";
import { alreadyPaid, authorizeAndSend, checkAffordable, PayError, refreshTx, resendable, resendStored, singleUse } from "../core/pay";
import { reconcileRequests, syncIncoming } from "../core/history";
import { decodeImageFile, hasCamera, startCamera } from "./scanner";
import { utf8 } from "../core/encoding";

const guard = (A: AppCtx) => {
  if (A.session?.accountId) return true;
  queueMicrotask(() => A.go(A.session ? { r: "identity" } : { r: "unlock" }));
  return false;
};
const blank = () => h("main", { class: "screen" });

// ---------- QR rendering / export ----------
function qrSvg(text: string): string {
  return qrToSvg(encodeQr(text, "M"), { quiet: 3, fg: "#000", bg: "#fff" });
}

async function qrPng(text: string, size = 1024): Promise<Blob> {
  const svg = qrSvg(text).replace("<svg ", `<svg width="${size}" height="${size}" `);
  const url = URL.createObjectURL(new Blob([svg], { type: "image/svg+xml" }));
  try {
    const img = new Image();
    img.src = url;
    await img.decode();
    const c = document.createElement("canvas");
    c.width = c.height = size;
    const ctx = c.getContext("2d")!;
    ctx.imageSmoothingEnabled = false;
    ctx.drawImage(img, 0, 0, size, size);
    return await new Promise((res, rej) => c.toBlob((b) => (b ? res(b) : rej(new Error("png"))), "image/png"));
  } finally {
    URL.revokeObjectURL(url);
  }
}

function qrCard(text: string) {
  const card = h("div", { class: "qrcard", role: "img", "aria-label": "Payment QR code" });
  card.appendChild(svgFrom(qrSvg(text)));
  return card;
}

function qrActions(A: AppCtx, text: string, name: string) {
  const save = h("button", { class: "btn sec", onClick: async () => {
    try {
      const blob = await qrPng(text);
      const url = URL.createObjectURL(blob);
      const a = h("a", { href: url, download: `neat-${name}-qr.png` });
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
    } catch { A.toast("Couldn't save the image."); }
  } }, icon("download"), "Save image");
  const kids: Node[] = [save];
  const canShareFiles = typeof navigator.canShare === "function" && typeof File !== "undefined";
  if (canShareFiles) {
    kids.push(h("button", { class: "btn sec", onClick: async () => {
      try {
        const file = new File([await qrPng(text)], `neat-${name}-qr.png`, { type: "image/png" });
        if (!navigator.canShare({ files: [file] })) return A.toast("Sharing images isn't supported here.");
        await navigator.share({ files: [file], title: `Pay ${name} on NEAT` });
      } catch (e: any) { if (e?.name !== "AbortError") A.toast("Couldn't share the image."); }
    } }, icon("share"), "Share image"));
  }
  return h("div", { class: "actions " + (kids.length === 2 ? "two" : "") }, ...kids);
}

// =============== Receive ===============
export async function receiveView(A: AppCtx): Promise<HTMLElement> {
  if (!guard(A)) return blank();
  const sess = A.session!;
  const me = sess.accountId!;
  const name = displayName(me);
  const area = h("div");
  let tab: "open" | "request" = "open";
  const seg = h("div", { class: "seg", role: "tablist" });
  const mk = (id: "open" | "request", label: string) => {
    const b = h("button", { role: "tab", "aria-selected": String(tab === id), onClick: () => { tab = id; draw(); } }, label);
    return b;
  };
  let poll: any, tick: any;
  A.onLeave(() => { clearInterval(poll); clearInterval(tick); });

  async function openRecord() {
    const s = store.load();
    let rec = s.requests.find((r) => r.kind === "open" && r.request.to === me && r.request.pk === sess.pkStr);
    if (!rec) {
      const { request } = await createRequest(sess.signer, me, {});
      rec = { request, kind: "open", state: "open", createdAt: Date.now() };
      store.update((st) => st.requests.push(rec!));
    }
    return rec;
  }

  async function drawOpen() {
    clearInterval(poll); clearInterval(tick);
    const rec = await openRecord();
    const { encodeRequest } = await import("../core/payload");
    const text = encodeRequest(rec.request);
    put(area, 
      qrCard(text),
      h("div", { class: "qrmeta" }, h("div", { class: "display", style: { fontSize: "34px" } }, name, h("span", { class: "sfx" }, ".testnet")), h("p", { class: "muted small", style: { marginTop: "8px" } }, "Ask them to scan this with NEAT. They choose the amount.")),
      qrActions(A, text, name)
    );
  }

  function requestForm() {
    const amt = h("input", { class: "input big", inputmode: "decimal", autocomplete: "off", placeholder: "0", "aria-label": "Amount in NEAR", "data-autofocus": "" }) as HTMLInputElement;
    const note = h("input", { class: "input", maxlength: String(MAX_NOTE), placeholder: "What's it for? (optional)", autocomplete: "off", "aria-label": "Note" }) as HTMLInputElement;
    const exp = h("select", { class: "input", "aria-label": "Expires" }, h("option", { value: "900" }, "15 minutes"), h("option", { value: "3600", selected: true }, "1 hour"), h("option", { value: "86400" }, "24 hours"), h("option", { value: "0" }, "Never")) as HTMLSelectElement;
    const fix = h("input", { type: "checkbox", checked: true, id: "fix" }) as HTMLInputElement;
    const hint = h("div", { class: "hint", "aria-live": "polite" });
    const go = h("button", { class: "btn", disabled: true }, "Create request") as HTMLButtonElement;
    amt.addEventListener("input", () => {
      const v = parseNear(amt.value);
      hint.className = "hint" + (amt.value && v === null ? " bad" : "");
      hint.textContent = amt.value && v === null ? "Enter a number with up to 6 decimals." : "";
      go.disabled = !(v && v > 0n);
    });
    go.addEventListener("click", async () => {
      const v = parseNear(amt.value);
      if (!v || v <= 0n) return;
      if (utf8.enc(note.value).length > MAX_NOTE) return void (hint.textContent = "That note is too long.");
      go.disabled = true;
      const { request, qrText } = await createRequest(sess.signer, me, { amountYocto: v, fixed: fix.checked, note: note.value, expiresInSec: Number(exp.value) || undefined });
      const rec: store.RequestRecord = { request, kind: "amount", state: "open", createdAt: Date.now() };
      store.update((s) => s.requests.push(rec));
      showRequest(rec, qrText);
    });
    put(area, 
      h("div", { class: "stack" },
        h("label", { class: "field" }, h("span", { class: "lbl" }, "Amount"), h("div", { class: "suffix-wrap" }, amt, h("span", { class: "sfx" }, "NEAR")), hint),
        h("label", { class: "field" }, h("span", { class: "lbl" }, "Note"), note),
        h("label", { class: "field" }, h("span", { class: "lbl" }, "Expires"), exp),
        h("label", { class: "switch", for: "fix" }, h("span", null, "Sender can't change the amount"), fix)
      ),
      h("div", { class: "actions" }, go),
      h("p", { class: "muted small", style: { marginTop: "14px" } }, "A request is just a QR. Nothing moves until the payer scans it and authorizes the payment.")
    );
    amt.focus();
  }

  function showRequest(rec: store.RequestRecord, qrText: string) {
    const r = rec.request;
    const chipSlot = h("div");
    const expLine = h("div", { class: "muted small", style: { marginTop: "6px" } });
    const qrSlot = h("div");
    const paidInfo = h("div");
    const cancelBtn = h("button", { class: "btn ghost" }, "Cancel request") as HTMLButtonElement;
    const render = () => {
      const cur = store.load().requests.find((x) => x.request.id === r.id)!;
      put(chipSlot, statusChip(cur.state));
      const live = cur.state === "open";
      put(qrSlot, live ? qrCard(qrText) : h("div", { class: "card empty" }, cur.state === "paid" ? "Paid. This request is complete." : cur.state === "expired" ? "This request has expired." : "This request was cancelled."));
      put(paidInfo, cur.paidTx ? h("div", { class: "card", style: { marginTop: "14px" } }, row("Verified payment", shortHash(cur.paidTx)), h("div", { style: { marginTop: "8px" } }, h("button", { class: "link", onClick: () => A.go({ r: "receipt", txId: cur.paidTx!, from: "home" }) }, "View receipt"))) : null);
      cancelBtn.hidden = !live;
      if (r.exp && live) {
        const left = r.exp - Math.floor(Date.now() / 1000);
        expLine.textContent = left > 0 ? `Expires in ${Math.floor(left / 60)}:${String(left % 60).padStart(2, "0")}` : "Expired";
      } else expLine.textContent = "";
      if (!live) { clearInterval(poll); clearInterval(tick); }
    };
    cancelBtn.addEventListener("click", () => {
      let close = () => {};
      close = A.sheet(
        h("div", { class: "stack" },
          h("h2", { class: "title", style: { fontSize: "24px" } }, "Cancel this request?"),
          h("p", { class: "muted" }, "NEAT will stop tracking it. A request is only a QR, so anyone who already has the QR could still pay it until it expires."),
          h("div", { class: "actions" },
            h("button", { class: "btn danger", onClick: () => { store.update((s) => { const x = s.requests.find((q) => q.request.id === r.id); if (x) x.state = "cancelled"; }); close(); render(); } }, "Cancel request"),
            h("button", { class: "btn sec", onClick: () => close() }, "Keep it"))),
        "Cancel request");
    });
    const check = async () => {
      if (!A.online) return;
      // Watch the balance (cheap). When it rises, refreshBalance() opens the gate for payment-index lookups, which
      // are otherwise rationed; a request that stays on screen for hours must not use up the index's free quota.
      await A.refreshBalance();
      await syncIncoming(A.rpc, me, undefined, { background: true }).catch(() => null);
      if (reconcileRequests() > 0) { render(); if (store.load().requests.find((x) => x.request.id === r.id)?.state === "paid") A.toast("Payment received and verified."); }
    };
    render();
    clearInterval(poll); clearInterval(tick);
    poll = setInterval(check, 10_000);
    tick = setInterval(() => { reconcileRequests(); render(); }, 1000);
    void check();
    put(area, 
      h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px" } }, chipSlot, expLine),
      qrSlot,
      h("div", { class: "qrmeta" },
        h("div", { class: "display", style: { fontSize: "40px" } }, formatNear(BigInt(r.amt!), 6), h("span", { class: "sfx" }, " NEAR")),
        h("p", { class: "muted small", style: { marginTop: "8px" } }, `to ${displayName(me)}.testnet${r.note ? " · " + r.note : ""}`),
        r.fix ? h("p", { class: "muted small" }, "Fixed amount") : null),
      paidInfo,
      qrActions(A, qrText, name),
      h("div", { class: "actions", style: { marginTop: "6px" } }, cancelBtn, h("button", { class: "btn ghost", onClick: () => { clearInterval(poll); clearInterval(tick); draw(); } }, "New request"))
    );
  }

  async function draw() {
    put(seg, mk("open", "My QR"), mk("request", "Request amount"));
    if (tab === "open") await drawOpen(); else requestForm();
  }
  await draw();

  return h("main", { class: "screen" }, top(A, "Receive", { r: "home" }, netChip(A.online)), seg, h("div", { style: { marginTop: "20px" } }, area));
}

// =============== Scan ===============
export function scanView(A: AppCtx): HTMLElement {
  if (!guard(A)) return blank();
  const video = h("video", { playsinline: "", muted: "", "aria-label": "Camera preview" }) as HTMLVideoElement;
  const msg = h("div", { class: "msg", "aria-live": "polite" }, "Point the camera at a NEAT QR");
  const box = h("div", { class: "scanner idle" }, video, h("div", { class: "frame", hidden: true }), msg);
  const status = h("div", { style: { marginTop: "16px" }, "aria-live": "assertive" });
  const file = h("input", { type: "file", accept: "image/*", class: "sr", id: "qrfile" }) as HTMLInputElement;
  let cam: { stop(): void } | null = null;
  let handling = false;
  A.onLeave(() => cam?.stop());

  const fail = (text: string) => {
    handling = false;
    put(status, h("div", { class: "callout bad", role: "alert" }, text), h("div", { class: "actions" }, h("button", { class: "btn sec", onClick: () => { put(status); startScan(); } }, "Scan again")));
  };

  async function handle(text: string) {
    if (handling) return;
    handling = true;
    cam?.stop(); cam = null;
    box.classList.add("idle");
    put(status, spinnerLine("Checking this QR on NEAR Testnet…"));
    const parsed = parseRequest(text.trim());
    if (!parsed.ok) return fail(parsed.error);
    const req = parsed.request;
    if (req.to === A.session!.accountId) return fail("That's your own QR. Ask someone else to show theirs.");
    if (singleUse(req) && alreadyPaid(req.id)) return fail("You've already paid this request.");
    if (!A.online) return fail("You're offline. NEAT needs a connection to verify the QR.");
    const v = await verifyRequest(req, A.rpc);
    if (!v.ok) return fail(v.message);
    A.go({ r: "amount", req });
  }

  async function startScan() {
    handling = false;
    if (!hasCamera()) { msg.textContent = "Camera isn't available here. Upload a photo of the QR instead."; return; }
    try {
      box.classList.remove("idle");
      box.querySelector<HTMLElement>(".frame")!.hidden = false;
      cam = await startCamera(video, handle);
      msg.textContent = "Point the camera at a NEAT QR";
    } catch (e: any) {
      box.classList.add("idle");
      box.querySelector<HTMLElement>(".frame")!.hidden = true;
      msg.textContent = e?.name === "NotAllowedError" ? "Camera access was blocked. Allow it in your browser, or upload a photo of the QR." : "Couldn't start the camera. You can upload a photo of the QR instead.";
    }
  }

  file.addEventListener("change", async () => {
    const f = file.files?.[0];
    file.value = "";
    if (!f) return;
    cam?.stop(); cam = null;
    put(status, spinnerLine("Reading image…"));
    try {
      const t = await decodeImageFile(f);
      if (!t) return fail("No QR code found in that image. Try a sharper, closer photo.");
      handle(t);
    } catch (e: any) { fail(e?.message ?? "That image couldn't be read."); }
  });

  queueMicrotask(startScan);
  return h("main", { class: "screen" },
    top(A, "Scan to pay", { r: "home" }, netChip(A.online)),
    box,
    status,
    h("div", { class: "grow" }),
    h("div", { class: "actions" }, h("label", { class: "btn sec", for: "qrfile", style: { cursor: "pointer" } }, icon("image"), "Upload QR image"), file)
  );
}

// =============== Amount ===============
export async function amountView(A: AppCtx, route: { req: PaymentRequest }): Promise<HTMLElement> {
  if (!guard(A)) return blank();
  const req = route.req;
  const me = A.session!.accountId!;
  const fixed = req.amt !== undefined && req.fix === 1;
  const input = h("input", { class: "input big", inputmode: "decimal", autocomplete: "off", placeholder: "0", id: "amt", "aria-label": "Amount in NEAR", value: req.amt ? formatNear(BigInt(req.amt), 6) : "", readonly: fixed || null, "data-autofocus": "" }) as HTMLInputElement;
  const hint = h("div", { class: "hint", "aria-live": "polite" });
  const avail = h("span", { class: "muted small" }, "Checking balance…");
  const go = h("button", { class: "btn", disabled: true }, "Review") as HTMLButtonElement;
  let est: FeeEstimate | null = null;
  const maxBtn = h("button", { class: "link", hidden: fixed, type: "button" }, "Use max") as HTMLButtonElement;

  const validate = () => {
    const v = parseNear(input.value);
    hint.className = "hint";
    hint.textContent = "";
    go.disabled = true;
    if (!input.value) return;
    if (v === null) { hint.className = "hint bad"; hint.textContent = "Enter a number with up to 6 decimals."; return; }
    if (v <= 0n) { hint.className = "hint bad"; hint.textContent = "Enter an amount greater than zero."; return; }
    if (est) {
      const ok = checkAffordable(v, est);
      if (!ok.ok) { hint.className = "hint bad"; hint.textContent = ok.message; return; }
    }
    go.disabled = est === null; // wait until balance + fee data is known
  };
  input.addEventListener("input", validate);
  maxBtn.addEventListener("click", () => { if (est) { input.value = formatNear(maxSendable(est), 6); validate(); } });
  go.addEventListener("click", () => { const v = parseNear(input.value); if (v && v > 0n) A.go({ r: "review", req, amount: v }); });

  estimateTransferFee(A.rpc, me, req.to).then((e) => {
    est = e;
    avail.textContent = `Available ${nearAmt(maxSendable(e), 5)} NEAR after fees`;
    validate();
  }).catch((e) => {
    avail.textContent = e instanceof FeeError ? e.message : "Couldn't load your balance. Check your connection.";
  });

  return h("main", { class: "screen" },
    top(A, "Amount", { r: "scan" }, netChip(A.online), false),
    h("div", null, h("div", { class: "eyebrow" }, "Paying"), h("h1", { class: "display", style: { marginTop: "10px", fontSize: "clamp(34px, 11vw, 48px)" } }, displayName(req.to), h("span", { class: "sfx" }, ".testnet")),
      h("p", { class: "muted small", style: { marginTop: "10px", display: "flex", gap: "8px", alignItems: "center" } }, icon("check"), "Verified: this QR was issued by the owner of this account"),
      req.note ? h("p", { class: "lede", style: { marginTop: "8px" } }, `“${req.note}”`) : null),
    h("div", { class: "stack", style: { marginTop: "26px" } },
      h("div", { class: "field" }, h("div", { class: "lbl" }, h("label", { for: "amt" }, fixed ? "Requested amount" : req.amt ? "Suggested amount" : "Amount"), maxBtn), h("div", { class: "suffix-wrap" }, input, h("span", { class: "sfx" }, "NEAR")), hint),
      h("div", { style: { display: "flex", justifyContent: "space-between" } }, avail, h("span", { class: "muted small" }, "NEAR Testnet"))),
    h("div", { class: "grow" }),
    h("div", { class: "actions" }, go)
  );
}

// =============== Review ===============
export async function reviewView(A: AppCtx, route: { req: PaymentRequest; amount: bigint }): Promise<HTMLElement> {
  if (!guard(A)) return blank();
  const { req, amount } = route;
  const me = A.session!.accountId!;
  const body = h("div", null, spinnerLine("Estimating the network fee…"));
  const actions = h("div", { class: "actions" });
  let est: FeeEstimate | null = null, at = 0;

  async function load(): Promise<boolean> {
    try {
      est = await estimateTransferFee(A.rpc, me, req.to);
      at = Date.now();
      return true;
    } catch (e: any) {
      put(body, h("div", { class: "callout bad", role: "alert" }, e instanceof FeeError ? e.message : "Couldn't reach NEAR Testnet to estimate the fee. Nothing has been signed."));
      put(actions, h("button", { class: "btn", onClick: draw }, "Try again"), h("button", { class: "btn ghost", onClick: () => A.go({ r: "amount", req }) }, "Back"));
      return false;
    }
  }

  async function draw() {
    put(body, spinnerLine("Estimating the network fee…"));
    put(actions);
    if (!(await load())) return;
    const e = est!;
    const total = amount + e.fee;
    const ok = checkAffordable(amount, e);
    put(body, 
      h("div", { class: "rows card" },
        row("To", h("span", null, displayName(req.to) + ".testnet")),
        row("Account", h("span", { class: "mono" }, compactAccount(req.to))),
        row("Amount", `${formatNear(amount, 6)} NEAR`),
        row("Stamp fee (estimated)", `${formatFee(e.fee)} NEAR`),
        row("Total cost to you", `${formatNear(total, 9)} NEAR`, "total"),
        row("They receive", `${formatNear(amount, 6)} NEAR`),
        row("Network", "NEAR Testnet")),
      h("p", { class: "muted small", style: { marginTop: "12px" } }, `The stamp fee is the network's fee for this payment, worked out from the current gas price and fee schedule. Your balance must also cover a small hold of up to ${formatFee(e.reserve)} NEAR while the payment runs; the unused part is returned.`),
      !ok.ok ? h("div", { class: "callout bad", role: "alert", style: { marginTop: "14px" } }, h("b", null, "Not enough balance. "), ok.message, ` You can spend up to ${nearAmt(maxSendable(e), 5)} NEAR to this recipient.`) : null,
      !A.online ? h("div", { class: "callout bad", style: { marginTop: "14px" } }, "You're offline. You need a connection to send.") : null
    );
    const auth = h("button", { class: "btn", disabled: !ok.ok || !A.online, "data-autofocus": "" }, "Authorize payment") as HTMLButtonElement;
    auth.addEventListener("click", async () => {
      auth.disabled = true;
      // refresh a stale estimate rather than signing against old numbers
      if (Date.now() - at > 30_000) {
        const before = est!.fee;
        if (!(await load())) return;
        if (est!.fee !== before) { A.toast("The fee changed. Review it and authorize again."); return draw(); }
      }
      A.pendingSend = { rpc: A.rpc, signer: A.session!.signer, fromId: me, toId: req.to, amount, estimate: est!, request: req };
      A.go({ r: "processing" });
    });
    put(actions, auth, h("button", { class: "btn ghost", onClick: () => A.go({ r: "home" }) }, "Cancel"));
  }
  await draw();

  return h("main", { class: "screen" },
    top(A, "Review", { r: "amount", req }, netChip(A.online)),
    h("div", { style: { marginBottom: "16px" } }, h("div", { class: "eyebrow" }, "You're sending"), h("div", { class: "display", style: { marginTop: "8px", fontSize: "clamp(36px, 12vw, 52px)" } }, formatNear(amount, 6), h("span", { class: "sfx" }, " NEAR"))),
    body,
    h("div", { class: "grow" }),
    actions
  );
}

// =============== Processing ===============
export function processingView(A: AppCtx, route: { txId?: string }): HTMLElement {
  if (!guard(A)) return blank();
  const send = A.pendingSend;
  A.pendingSend = null; // a reload can never re-trigger a send
  let txId = route.txId;
  let alive = true;
  A.onLeave(() => (alive = false));
  const names = ["Signing on this device", "Sending to NEAR Testnet", "Confirming on the network"];
  const list = h("ol", { class: "steps" });
  const note = h("div", { style: { marginTop: "10px" }, "aria-live": "polite" });
  const actions = h("div", { class: "actions" });
  const setSteps = (now: number, bad = false) => put(list, ...names.map((n, i) => h("li", { class: i < now ? "done" : i === now ? (bad ? "bad" : "now") : "" }, h("span", { class: "dot" }, i < now ? icon("check") : null), n)));
  setSteps(send ? 0 : 2);

  const fail = (title: string, text: string, tx?: string) => {
    setSteps(txId ? 2 : 0, true);
    put(note, h("div", { class: "callout bad", role: "alert" }, h("b", null, title + " "), text));
    put(actions, 
      tx ? h("button", { class: "btn", onClick: () => A.go({ r: "receipt", txId: tx, from: "home" }) }, "View details") : null,
      h("button", { class: "btn sec", onClick: () => A.go({ r: "home" }) }, "Back to home")
    );
  };

  async function track() {
    setSteps(2);
    const started = Date.now();
    while (alive && Date.now() - started < 120_000) {
      const r = await refreshTx(A.rpc, txId!);
      if (!alive) return;
      if (r.tx.status === "completed") { await sleep(500); return void (alive && A.go({ r: "receipt", txId: txId!, from: "home" })); }
      if (r.tx.status === "failed") return fail("Payment failed.", failureSummary(r.tx), txId);
      await sleep(1500);
    }
    if (!alive) return;
    const cur = store.getTx(txId!)!;
    const lost = resendable(cur);
    setSteps(lost ? 1 : 2);
    put(note, h("div", { class: "callout" }, h("b", null, "Still waiting. "), lost ? "The network hasn't reported this payment yet. It may still be on its way, or it may have been dropped. Don't pay again." : "The network is slow to confirm. The payment may still complete. Don't send it again.", " NEAT keeps checking in the background. Your Activity list always shows its true status."));
    put(actions, 
      h("button", { class: "btn", onClick: () => { put(actions); put(note); track(); } }, "Check again"),
      lost ? h("button", { class: "btn sec", onClick: async () => { try { await resendStored(A.rpc, txId!); A.toast("Checked the network."); put(actions); track(); } catch (e: any) { A.toast(e?.message ?? "Couldn't resend."); } } }, "Resend the same payment") : null,
      h("button", { class: "btn ghost", onClick: () => A.go({ r: "home" }) }, "Close")
    );
  }

  (async () => {
    try {
      if (send) {
        const rec = await authorizeAndSend(send, (s) => alive && setSteps(s === "signing" ? 0 : 1));
        txId = rec.id;
        if (!alive) return;
      }
      if (!txId) return fail("Nothing to process.", "");
      await track();
    } catch (e: any) {
      if (e instanceof PayError) return fail(e.code === "offline" ? "Couldn't connect." : "Payment not sent.", e.message, e.code === "rejected" ? store.load().txs[0]?.id : undefined);
      fail("Something went wrong.", "Nothing was sent.");
    }
  })();

  return h("main", { class: "screen" },
    h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", minHeight: "44px" } }, brand(), netChip(A.online)),
    h("div", { style: { marginTop: "48px" } }, h("h1", { class: "title" }, "Sending payment"), h("p", { class: "lede" }, "Keep this screen open. You can leave it safely: the status is saved.")),
    list, note, h("div", { class: "grow" }), actions
  );
}

// =============== Receipt ===============
// A small printed slip, not a full screen: typewriter type, the date and time printed on it, names in bold, one stamp-fee
// line, the network's own evidence, and a status stamp at the foot. Every fact on it comes from the stored, network-checked record.
export function receiptView(A: AppCtx, route: { txId: string; from?: string }): HTMLElement {
  if (!guard(A)) return blank();
  const back = route.from === "activity" ? ({ r: "activity" } as const) : ({ r: "home" } as const);
  const wrap = h("div", { class: "slipcol" });
  const actions = h("div", { class: "actions" });
  let alive = true;
  A.onLeave(() => (alive = false));

  const draw = () => {
    const t = store.getTx(route.txId);
    if (!t) { put(wrap, h("div", { class: "empty" }, "Transaction not found.")); put(actions); return; }
    const out = t.dir === "out";
    const done = t.status === "completed";
    const failed = t.status === "failed";
    const lost = resendable(t);
    const headline = done ? (out ? "Payment sent" : "Payment received") : failed ? "Payment failed" : lost ? "Not confirmed yet" : "Processing";
    const when = stampTime(t.createdAt);
    const amount = BigInt(t.amount);
    const fee = stampFee(t);
    const feeText = !fee ? "Paid by sender" : `${fee.actual ? "" : "≈ "}${formatFee(fee.yocto)} NEAR`;
    const delivered = done && t.onchainAmount ? `${formatNear(BigInt(t.onchainAmount), 6)} NEAR (verified)` : failed ? "Nothing delivered" : "Not yet verified";
    const rule = () => h("div", { class: "rule", "aria-hidden": "true" });

    const extra: Node[] = [];
    if (!done && !failed) {
      extra.push(h("button", { class: "btn sec", onClick: async (e: Event) => { const b = e.currentTarget as HTMLButtonElement; b.disabled = true; await refreshTx(A.rpc, t.id).catch(() => null); if (alive) draw(); } }, "Refresh status"));
      if (lost) extra.push(h("button", { class: "btn sec", onClick: async () => { try { await resendStored(A.rpc, t.id); } catch (e: any) { A.toast(e?.message ?? "Couldn't resend."); } if (alive) draw(); } }, "Resend the same payment"));
    }

    put(wrap,
      h("div", { class: "slip" },
        h("div", { class: "head" },
          h("span", { class: "mark", "aria-hidden": "true" }, chevron()),
          h("div", { class: "brand" }, "NEAT"),
          h("div", { class: "what" }, headline),
          h("div", { class: "amt num" }, (out ? "−" : "+") + formatNear(amount, 6), h("span", { class: "sfx" }, " NEAR"))),
        rule(),
        ln("Date", when.date),
        ln("Time", when.time),
        rule(),
        ln("From", h("b", null, displayName(t.from) + ".testnet")),
        ln("To", h("b", null, displayName(t.to) + ".testnet")),
        rule(),
        out ? ln("Amount", `${formatNear(amount, 6)} NEAR`) : null,
        out ? ln(fee && !fee.actual ? "Stamp fee (est.)" : "Stamp fee", feeText) : null,
        out && done && fee?.actual ? ln("Total", `${formatNear(amount + fee.yocto, 9)} NEAR`, "total") : null,
        ln(out ? "They received" : "Received", delivered),
        t.note ? ln("Note", t.note, t.note.length > 22 ? "block" : "") : null,
        ln("Network", "NEAR Testnet"),
        h("div", { class: "rule cap" }, h("span", null, "Evidence")),
        ln("Transaction", shortHash(t.id)),
        ln("Network status", t.finality ?? "Not reported yet"),
        t.blockHash ? ln("Block", shortHash(t.blockHash)) : null,
        h("div", { class: "foot" }, statusStamp(t.status), h("div", null, explorerLink(t.id)))),
      lost ? h("div", { class: "callout", style: { marginTop: "14px" } }, h("b", null, "The network hasn't reported this payment. "), "It may still be on its way, or it may have been dropped. Don't pay again: refresh the status first. If it still doesn't appear, you can resend the same transaction. It can only ever execute once.") : null,
      failed ? h("div", { class: "callout bad", style: { marginTop: "14px" } }, failureSummary(t)) : null
    );
    put(actions, ...extra, h("button", { class: "btn" + (extra.length ? " ghost" : ""), onClick: () => A.go(back) }, "Done"));
  };
  draw();
  // keep refreshing unresolved transactions while the receipt is open
  (async () => {
    for (let i = 0; i < 40 && alive; i++) {
      const t = store.getTx(route.txId);
      if (!t || t.status === "completed" || t.status === "failed") return;
      await refreshTx(A.rpc, t.id).catch(() => null);
      if (alive) draw();
      await sleep(3000);
    }
  })();
  return h("main", { class: "screen" }, top(A, "Receipt", back, netChip(A.online)), wrap, h("div", { class: "grow" }), actions);
}
