// App shell: routing, session, auto-lock, toasts/sheets, connectivity.
import { clear, h } from "./dom";
import { Rpc, DEFAULT_ENDPOINTS } from "../core/rpc";
import type { Signer } from "../core/near";
import type { PaymentRequest } from "../core/payload";
import type { SendInput } from "../core/pay";
import * as store from "../core/store";
import { expectIncoming } from "../core/history";

declare const __NEAT_RPC__: string[] | undefined;
declare const __NEAT_REGISTER__: string | undefined;
declare const __NEAT_INDEX__: string | undefined;
declare const __NEAT_VERSION__: string | undefined;

export const CONFIG = {
  rpc: typeof __NEAT_RPC__ !== "undefined" && __NEAT_RPC__?.length ? __NEAT_RPC__ : DEFAULT_ENDPOINTS,
  register: typeof __NEAT_REGISTER__ !== "undefined" && __NEAT_REGISTER__ ? __NEAT_REGISTER__ : "/api/register",
  index: typeof __NEAT_INDEX__ !== "undefined" && __NEAT_INDEX__ ? __NEAT_INDEX__ : "https://api-testnet.nearblocks.io",
  version: typeof __NEAT_VERSION__ !== "undefined" ? __NEAT_VERSION__ : "dev",
  explorer: "https://testnet.nearblocks.io",
};

export type Route =
  | { r: "splash" }
  | { r: "create" }
  | { r: "restore" }
  | { r: "identity" }
  | { r: "unlock" }
  | { r: "home" }
  | { r: "receive" }
  | { r: "scan" }
  | { r: "amount"; req: PaymentRequest }
  | { r: "review"; req: PaymentRequest; amount: bigint }
  | { r: "processing"; txId?: string }
  | { r: "receipt"; txId: string; from?: "activity" | "home" }
  | { r: "activity" }
  | { r: "settings" };

export type Session = { signer: Signer; publicKey: Uint8Array; pkStr: string; accountId: string | null };

const TITLES: Record<Route["r"], string> = {
  splash: "NEAT",
  create: "Create wallet",
  restore: "Restore wallet",
  identity: "Choose your name",
  unlock: "Locked",
  home: "Home",
  receive: "Receive",
  scan: "Scan to pay",
  amount: "Amount",
  review: "Review",
  processing: "Sending",
  receipt: "Receipt",
  activity: "Activity",
  settings: "Settings",
};

type View = (A: AppCtx, route: any) => HTMLElement | Promise<HTMLElement>;

export class AppCtx {
  rpc = new Rpc({ endpoints: CONFIG.rpc });
  session: Session | null = null;
  balance: bigint | null = null;
  installEvent: any = null;
  route: Route = { r: "splash" };
  private views = new Map<string, View>();
  private disposers: (() => void)[] = [];
  private lockTimer: any = null;
  private gen = 0;
  root: HTMLElement;
  online = typeof navigator === "undefined" ? true : navigator.onLine;

  constructor(root: HTMLElement) {
    this.root = root;
    addEventListener("online", () => this.setOnline(true));
    addEventListener("offline", () => this.setOnline(false));
    for (const ev of ["pointerdown", "keydown", "touchstart"]) addEventListener(ev, () => this.touch(), { passive: true });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") {
        this.hiddenAt = Date.now();
        return;
      }
      // back in view: lock if it was away longer than the chosen delay. "Only when I lock" (0) never locks by itself.
      const min = store.load().prefs.autoLockMin;
      if (this.session && this.hiddenAt && min > 0 && Date.now() - this.hiddenAt > min * 60_000) this.lock();
      this.hiddenAt = 0;
    });
  }
  private hiddenAt = 0;
  private sheets: (() => void)[] = [];
  /** A payment the person has just authorized on the Review screen, handed to the Processing screen. Dropped on lock. */
  pendingSend: SendInput | null = null;

  register(name: Route["r"], v: View) {
    this.views.set(name, v);
  }

  /** Run `fn` when the user leaves this screen (timers, camera streams…). */
  onLeave(fn: () => void) {
    this.disposers.push(fn);
  }

  async go(route: Route) {
    const my = ++this.gen;
    for (const d of this.disposers.splice(0)) {
      try {
        d();
      } catch {}
    }
    for (const close of [...this.sheets]) close(); // a sheet never outlives the screen it was opened on (e.g. across an auto-lock)
    this.route = route;
    const view = this.views.get(route.r);
    if (!view) throw new Error("No view " + route.r);
    const el = await view(this, route);
    if (my !== this.gen) return; // navigated elsewhere while building
    clear(this.root);
    this.root.appendChild(el);
    document.title = route.r === "splash" ? "NEAT" : `${TITLES[route.r]} · NEAT`; // generic on purpose: no name or amount in tab titles or history
    // Move focus into the new screen so keyboard and screen-reader users land at its start: the first field, or its heading.
    const focusTarget = el.querySelector<HTMLElement>("[data-autofocus]") ?? el.querySelector<HTMLElement>("h1");
    if (focusTarget && !focusTarget.hasAttribute("tabindex") && !focusTarget.matches("input, button, select, textarea, a[href]")) focusTarget.tabIndex = -1;
    focusTarget?.focus({ preventScroll: true });
    this.touch();
  }

  setOnline(on: boolean) {
    this.online = on;
    this.renderBanner();
  }

  renderBanner() {
    document.getElementById("net-banner")?.remove();
    if (!this.online) document.body.appendChild(h("div", { id: "net-banner", class: "banner", role: "status" }, "You're offline. Payments need a connection."));
  }

  // ----- session / lock -----
  setSession(s: Session | null) {
    this.session = s;
    this.touch();
  }

  touch() {
    clearTimeout(this.lockTimer);
    if (!this.session) return;
    const min = store.load().prefs.autoLockMin;
    if (min > 0) this.lockTimer = setTimeout(() => this.lock(), min * 60_000);
  }

  lock() {
    if (!this.session) return;
    this.session = null;
    this.balance = null;
    this.pendingSend = null; // holds a signer: never keep it past a lock
    clearTimeout(this.lockTimer);
    this.go({ r: "unlock" });
  }

  // ----- feedback -----
  toast(msg: string, ms = 2600) {
    document.querySelector(".toast")?.remove();
    const t = h("div", { class: "toast", role: "status" }, msg);
    document.body.appendChild(t);
    setTimeout(() => t.remove(), ms);
  }

  /**
   * A modal dialog. While it is open the rest of the app is inert (no focus, no clicks, hidden from screen readers),
   * Tab cycles inside it, Escape closes it, and focus returns to what opened it. Returns its `close` function.
   * `closeButton` adds a visible Close button for sheets that are read-only (they would otherwise have no control).
   */
  sheet(content: HTMLElement, label: string, opts: { closeButton?: boolean } = {}): () => void {
    const prev = document.activeElement as HTMLElement | null;
    const body = opts.closeButton ? h("div", { class: "stack" }, content, h("div", { class: "actions" }, h("button", { class: "btn sec", "data-autofocus": "", onClick: () => close() }, "Close"))) : content;
    const sheet = h("div", { class: "sheet", role: "dialog", "aria-modal": "true", "aria-label": label, tabindex: "-1" }, body);
    const scrim = h("div", { class: "scrim", onClick: (e: Event) => e.target === scrim && close() }, sheet);
    const focusables = () => [...sheet.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled]):not([type="hidden"]), select:not([disabled]), textarea:not([disabled]), a[href]')].filter((e) => e.getClientRects().length > 0);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        close();
        return;
      }
      if (e.key !== "Tab") return;
      const f = focusables();
      const at = document.activeElement;
      if (!f.length) {
        e.preventDefault();
        sheet.focus();
      } else if (e.shiftKey && (at === f[0] || at === sheet || !sheet.contains(at))) {
        e.preventDefault();
        f[f.length - 1].focus();
      } else if (!e.shiftKey && (at === f[f.length - 1] || !sheet.contains(at))) {
        e.preventDefault();
        f[0].focus();
      }
    };
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      document.removeEventListener("keydown", onKey, true);
      this.sheets = this.sheets.filter((c) => c !== close);
      scrim.remove();
      if (!this.sheets.length) this.root.inert = false;
      if (prev?.isConnected) prev.focus?.();
    };
    this.sheets.push(close);
    document.addEventListener("keydown", onKey, true);
    this.root.inert = true;
    document.body.appendChild(scrim);
    (sheet.querySelector<HTMLElement>("[data-autofocus], input, button") ?? sheet).focus();
    return close;
  }

  async refreshBalance(): Promise<bigint | null> {
    const id = this.session?.accountId;
    if (!id) return null;
    try {
      const a = await this.rpc.viewAccount(id);
      const next = a ? a.amount : null;
      if (next !== null && this.balance !== null && next > this.balance) expectIncoming(); // something arrived: lookups in the payment index are now worth spending
      this.balance = next;
    } catch {
      /* keep last known value; the UI marks it as stale when offline */
    }
    return this.balance;
  }
}
