import { AppCtx, CONFIG } from "./app";
import { clear, greeting, h, timeAgo, put } from "./dom";
import { brand, downloadBackup, netChip, nearAmt, statusChip, top, txTitle } from "./parts";
import { chevron, icon } from "./icons";
import * as store from "../core/store";
import { displayName } from "../core/near";
import { refreshTx } from "../core/pay";
import { reconcileRequests, syncIncoming } from "../core/history";
import { eraseFlow, recoveryExplainer } from "./views-auth";

const guard = (A: AppCtx) => {
  if (A.session?.accountId) return true;
  queueMicrotask(() => A.go(A.session ? { r: "identity" } : { r: "unlock" }));
  return false;
};
const blank = () => h("main", { class: "screen" });

function txItem(A: AppCtx, t: store.TxRecord, from: "home" | "activity") {
  const out = t.dir === "out";
  const sign = out ? "−" : "+";
  return h(
    "button",
    { class: "item", onClick: () => A.go({ r: "receipt", txId: t.id, from }) },
    h("span", { class: "ic" }, icon(out ? "send" : "receive")),
    h("span", { class: "m" }, h("b", null, displayName(txTitle(t))), h("span", null, (out ? "Sent" : "Received") + " · " + timeAgo(t.createdAt))),
    h("span", { class: "a" }, `${sign}${nearAmt(t.amount, 4)}`, t.status === "completed" ? h("small", null, "NEAR") : h("small", null, statusChip(t.status)))
  );
}

// =============== Home ===============
export function homeView(A: AppCtx): HTMLElement {
  if (!guard(A)) return blank();
  const sess = A.session!;
  const me = sess.accountId!;
  const balEl = h("span", { class: "amt num" }, A.balance !== null ? nearAmt(A.balance, 4) : "—");
  const balNote = h("span", { class: "muted small", style: { marginLeft: "8px" } });
  const listEl = h("div", { class: "list" });
  let alive = true;
  A.onLeave(() => (alive = false));

  const drawList = () => {
    clear(listEl);
    const txs = store.load().txs.slice(0, 4);
    if (!txs.length) listEl.append(h("div", { class: "empty" }, "No payments yet.", h("br"), "Receive or send to get started."));
    else for (const t of txs) listEl.append(txItem(A, t, "home"));
  };
  drawList();

  const setBal = () => {
    balEl.textContent = A.balance !== null ? nearAmt(A.balance, 4) : "—";
    balNote.textContent = !A.online ? "offline · may be out of date" : A.balance === null ? "" : "";
  };
  setBal();

  // Refresh balance, resolve anything unresolved, then look for incoming payments. Runs on arrival and then every
  // 15 s while this screen is visible, so a payment that lands while the wallet is open shows up by itself.
  // The balance is read from the network every time (cheap). The payment index is NOT: on arrival it is asked once,
  // and in the background only after the balance has risen (see AppCtx.refreshBalance / expectIncoming), plus a slow
  // safety net, so a long-open wallet cannot use up the index's small free quota.
  let busy = false;
  const refresh = async (background = false) => {
    if (busy || !alive) return;
    busy = true;
    try {
      await A.refreshBalance();
      if (alive) setBal();
      for (const t of store.load().txs.filter((x) => x.status !== "completed" && x.status !== "failed").slice(0, 8)) {
        await refreshTx(A.rpc, t.id).catch(() => null);
        if (!alive) return;
      }
      const r = await syncIncoming(A.rpc, me, undefined, { background }).catch(() => ({ added: 0, indexOk: false }));
      reconcileRequests();
      if (!alive) return;
      drawList();
      if (r.added) {
        await A.refreshBalance();
        if (alive) setBal();
      }
    } finally {
      busy = false;
    }
  };
  void refresh();
  const poll = setInterval(() => { if (document.visibilityState === "visible" && A.online) void refresh(true); }, 15_000);
  A.onLeave(() => clearInterval(poll));

  return h(
    "main",
    { class: "screen home" },
    h("div", { class: "watermark", "aria-hidden": "true" }, chevron()),
    h("header", { class: "top", style: { marginBottom: 0 } }, h("span", { style: { marginLeft: "8px" } }, brand()), h("div", { style: { display: "flex", alignItems: "center", gap: "4px" } }, netChip(A.online), h("button", { class: "iconbtn", "aria-label": "Lock", onClick: () => A.lock() }, icon("lock")), h("button", { class: "iconbtn", "aria-label": "Settings", onClick: () => A.go({ r: "settings" }) }, icon("settings")))),
    h("div", { class: "who" }, h("div", { class: "hello" }, greeting() + ","), h("h1", { class: "display", "data-autofocus": "", tabindex: "-1" }, displayName(me), h("span", { class: "sfx" }, ".testnet"))),
    h("div", { class: "balance" }, balEl, h("span", { class: "cur" }, "NEAR"), balNote),
    h("div", { class: "actions two", style: { marginTop: "26px" } }, h("button", { class: "btn", onClick: () => A.go({ r: "scan" }) }, icon("send"), "Send"), h("button", { class: "btn sec", onClick: () => A.go({ r: "receive" }) }, icon("receive"), "Receive")),
    h("div", { class: "section-h" }, h("span", { class: "eyebrow" }, "Recent"), h("button", { class: "link", onClick: () => A.go({ r: "activity" }) }, "See all")),
    listEl
  );
}

// =============== Activity ===============
export function activityView(A: AppCtx): HTMLElement {
  if (!guard(A)) return blank();
  const me = A.session!.accountId!;
  let tab: "payments" | "requests" = "payments";
  let filter: "all" | "in" | "out" = "all";
  const list = h("div", { class: "list" });
  const note = h("p", { class: "muted small", style: { marginTop: "10px" }, "aria-live": "polite" });
  const seg = h("div", { class: "seg", role: "tablist" });
  const sub = h("div", { class: "seg", role: "tablist", "aria-label": "Filter payments", style: { marginTop: "10px", gridTemplateColumns: "repeat(3, 1fr)" } });
  let alive = true;
  A.onLeave(() => (alive = false));

  const draw = () => {
    put(seg, 
      ...(["payments", "requests"] as const).map((id) => h("button", { role: "tab", "aria-selected": String(tab === id), onClick: () => { tab = id; draw(); } }, id === "payments" ? "Payments" : "Requests"))
    );
    sub.hidden = tab !== "payments";
    put(sub, ...(["all", "in", "out"] as const).map((id) => h("button", { role: "tab", "aria-selected": String(filter === id), onClick: () => { filter = id; draw(); } }, id === "all" ? "All" : id === "in" ? "Received" : "Sent")));
    clear(list);
    if (tab === "payments") {
      const txs = store.load().txs.filter((t) => filter === "all" || t.dir === filter);
      if (!txs.length) list.append(h("div", { class: "empty" }, "Nothing here yet."));
      for (const t of txs) list.append(txItem(A, t, "activity"));
    } else {
      const reqs = store.load().requests.filter((r) => r.kind === "amount").sort((a, b) => b.createdAt - a.createdAt);
      if (!reqs.length) list.append(h("div", { class: "empty" }, "No payment requests yet."));
      for (const r of reqs) {
        const st = r.state;
        list.append(h("button", { class: "item", onClick: () => (r.paidTx ? A.go({ r: "receipt", txId: r.paidTx, from: "activity" }) : A.go({ r: "receive" })) },
          h("span", { class: "ic" }, icon("receive")),
          h("span", { class: "m" }, h("b", null, r.request.note || "Payment request"), h("span", null, timeAgo(r.createdAt))),
          h("span", { class: "a" }, nearAmt(r.request.amt ?? "0", 4), h("small", null, statusChip(st)))));
      }
    }
  };
  draw();

  const refresh = async () => {
    note.textContent = "Checking the network…";
    for (const t of store.load().txs.filter((x) => x.status !== "completed" && x.status !== "failed").slice(0, 10)) await refreshTx(A.rpc, t.id).catch(() => null);
    const r = await syncIncoming(A.rpc, me).catch(() => ({ added: 0, indexOk: false }));
    reconcileRequests();
    if (!alive) return;
    note.textContent = r.indexOk ? "Incoming payments come from the NearBlocks index and are re-verified on the network. This shows recent activity, not complete history." : "Couldn't load incoming payments from the index. Showing payments made from this wallet.";
    draw();
  };
  void refresh();

  return h("main", { class: "screen" }, top(A, "Activity", { r: "home" }, h("button", { class: "iconbtn", "aria-label": "Refresh", onClick: refresh }, icon("activity"))), seg, sub, h("div", { style: { marginTop: "14px" } }, list), note);
}

// =============== Settings ===============
export function settingsView(A: AppCtx): HTMLElement {
  if (!guard(A)) return blank();
  const s = store.load();
  const vault = s.vault!;
  const me = A.session!.accountId!;
  const standalone = matchMedia("(display-mode: standalone)").matches || (navigator as any).standalone === true;
  const ua = navigator.userAgent;
  const isIOS = /iphone|ipad|ipod/i.test(ua) || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);

  const lockSel = h("select", { class: "input", "aria-label": "Auto-lock", onChange: (e: Event) => { const v = Number((e.target as HTMLSelectElement).value); store.update((st) => (st.prefs.autoLockMin = v)); A.touch(); A.toast("Auto-lock updated"); } },
    ...[[1, "After 1 minute"], [5, "After 5 minutes"], [15, "After 15 minutes"], [30, "After 30 minutes"], [0, "Only when I lock"]].map(([v, l]) => h("option", { value: String(v), selected: s.prefs.autoLockMin === v }, String(l)))) as HTMLSelectElement;

  const netState = h("span", { class: "muted small" }, "Checking…");
  A.rpc.finalBlock().then((b) => (netState.textContent = `Connected · block ${b.height.toLocaleString()}`)).catch(() => (netState.textContent = "Can't reach NEAR Testnet"));

  const installBlock = (() => {
    if (standalone) return h("p", { class: "muted small" }, "NEAT is installed on this device.");
    if (A.installEvent) return h("button", { class: "btn sec", onClick: async () => { const ev = A.installEvent; A.installEvent = null; await ev.prompt(); settingsRefresh(); } }, "Install NEAT");
    return h("p", { class: "muted small" }, isIOS ? "On iPhone or iPad: tap the Share button in Safari, then “Add to Home Screen”." : "In Chrome or Edge, open the browser menu and choose “Install app” (or the install icon in the address bar). On Android, choose “Add to Home screen”.");
  })();
  const settingsRefresh = () => A.go({ r: "settings" });

  const section = (title: string, ...kids: (Node | null)[]) => h("section", { style: { marginTop: "30px" } }, h("div", { class: "eyebrow", style: { marginBottom: "12px" } }, title), ...kids);

  return h(
    "main",
    { class: "screen" },
    top(A, "Settings", { r: "home" }),
    h("div", null, h("div", { class: "display", style: { fontSize: "34px" } }, displayName(me), h("span", { class: "sfx" }, ".testnet")), h("p", { class: "muted small", style: { marginTop: "8px" } }, "Registered on NEAR Testnet · key held on this device only")),
    h("div", { class: "actions" }, h("button", { class: "btn", onClick: () => A.lock() }, icon("lock"), "Lock now")),
    section("Security", h("label", { class: "field" }, h("span", { class: "lbl" }, "Auto-lock"), lockSel),
      h("div", { class: "stack", style: { marginTop: "14px" } },
        h("button", { class: "btn sec", onClick: () => downloadBackup(vault, displayName(me)) }, icon("download"), "Download encrypted backup"),
        h("p", { class: "muted small" }, "The backup is your wallet, encrypted with your sentence. With the file and your sentence you can restore on a new device. Without a backup, losing this device means losing the wallet."),
        h("button", { class: "link", onClick: () => A.sheet(recoveryExplainer(), "How your sentence works", { closeButton: true }) }, "How your sentence works"))),
    section("Install", installBlock),
    section("Network", h("div", { class: "rows card" }, h("div", { class: "row" }, h("span", { class: "k" }, "Network"), h("span", { class: "v" }, "NEAR Testnet")), h("div", { class: "row" }, h("span", { class: "k" }, "Status"), h("span", { class: "v" }, netState)), h("div", { class: "row" }, h("span", { class: "k" }, "RPC"), h("span", { class: "v mono" }, new URL(CONFIG.rpc[0]).host)))),
    section("About", h("p", { class: "muted small" }, `NEAT ${CONFIG.version}. Testnet tokens have no monetary value. Payments here are real testnet transactions; NEAT never holds your keys.`)),
    section("Danger zone", h("button", { class: "btn danger", onClick: () => eraseFlow(A) }, "Erase wallet from this device"))
  );
}
