// Tiny DOM helpers. All text goes through textContent / createTextNode — never innerHTML with data.

type Child = Node | string | number | null | undefined | false | Child[];
type Props = Record<string, any> | null;

export function h<K extends keyof HTMLElementTagNameMap>(tag: K, props?: Props, ...kids: Child[]): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === "class") el.className = v;
      else if (k === "dataset") Object.assign(el.dataset, v);
      else if (k.startsWith("on") && typeof v === "function") el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (k === "style" && typeof v === "object") Object.assign(el.style, v);
      else if (v === true) el.setAttribute(k, "");
      else el.setAttribute(k, String(v));
    }
  }
  append(el, kids);
  return el;
}

function append(el: Node, kids: Child[]) {
  for (const k of kids) {
    if (Array.isArray(k)) append(el, k);
    else if (k === null || k === undefined || k === false) continue;
    else el.appendChild(typeof k === "object" ? k : document.createTextNode(String(k)));
  }
}

/** Replace all children of `el`; like replaceChildren() but tolerant of null/false/arrays. */
export function put(el: Element, ...kids: Child[]) {
  clear(el);
  append(el, kids);
}

export function clear(el: Element) {
  while (el.firstChild) el.removeChild(el.firstChild);
}

/** Parse trusted, static SVG markup (icons / generated QR). Never pass user-controlled text. */
export function svgFrom(markup: string): SVGElement {
  const t = document.createElement("template");
  t.innerHTML = markup.trim();
  return t.content.firstElementChild as SVGElement;
}

export const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

export const reducedMotion = () => typeof matchMedia !== "undefined" && matchMedia("(prefers-reduced-motion: reduce)").matches;

export function compactAccount(id: string): string {
  return id.length > 24 ? id.slice(0, 8) + "…" + id.slice(-8) : id;
}

export function timeAgo(ms: number, now = Date.now()): string {
  const s = Math.max(0, Math.round((now - ms) / 1000));
  if (s < 45) return "just now";
  if (s < 3600) return Math.round(s / 60) + " min ago";
  if (s < 86400) return Math.round(s / 3600) + " h ago";
  return new Date(ms).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function greeting(d = new Date()): string {
  const hr = d.getHours();
  return hr < 5 ? "Still up" : hr < 12 ? "Good morning" : hr < 18 ? "Good afternoon" : "Good evening";
}
