import { AppCtx, CONFIG } from "./app";
import { h, sleep, put } from "./dom";
import { brand, confirmSheet, downloadBackup, explorerLink, netChip, parseBackup, shortHash, spinnerLine, top } from "./parts";
import { chevron, icon } from "./icons";
import * as store from "../core/store";
import { checkSentence, normalizeSentence, open, registerFailure, seal, SENTENCE_MAX, WrongSentence } from "../core/vault";
import { Ed25519Unsupported, displayName, generateKeypair, keyFromString, keyToString, nameToAccountId, signerFromSeed, validateNameLabel, verifySignature } from "../core/near";
import { awaitRegistration, checkAvailability, confirmRegistered, requestRegistration } from "../core/identity";
import { utf8 } from "../core/encoding";

// ---------- shared: the honest explanation of what the sentence is ----------
export function recoveryExplainer() {
  return h(
    "div",
    { class: "prose stack" },
    h("h2", { class: "title", style: { fontSize: "24px" } }, "How your sentence works"),
    h("p", null, h("b", null, "It locks your wallet. "), "Your wallet's real key is generated randomly on this device. Your sentence only scrambles (encrypts) that key so nobody can use it without the sentence."),
    h("p", null, h("b", null, "Nobody can reset it. "), "Your sentence and key never leave this device, so NEAT can't recover either one. A forgotten sentence can't be reset."),
    h("p", null, h("b", null, "A new device needs a backup file. "), "The sentence alone can't restore your wallet elsewhere. Download the encrypted backup in Settings, keep it safe, and you can restore it on another device with your sentence."),
    h("p", null, h("b", null, "Pick something long. "), "Anyone who gets your backup file can try to guess the sentence offline. Four or more unrelated words are far safer than one clever phrase.")
  );
}

/** `note` is a smaller second line: the specific fix, for whoever runs this deployment. */
function errorBox(msg: string, note?: string) {
  return h("div", { class: "callout bad", role: "alert" }, msg, note ? h("div", { class: "note" }, note) : null);
}

// =============== Create ===============
export function createView(A: AppCtx): HTMLElement {
  if (store.load().vault) {
    queueMicrotask(() => A.go({ r: "unlock" }));
    return h("main", { class: "screen" });
  }
  const s1 = h("input", { class: "input", type: "password", autocomplete: "off", autocapitalize: "none", spellcheck: "false", maxlength: String(SENTENCE_MAX), id: "s1", "aria-label": "Personal sentence", "data-autofocus": "" }) as HTMLInputElement;
  const s2 = h("input", { class: "input", type: "password", autocomplete: "off", autocapitalize: "none", spellcheck: "false", maxlength: String(SENTENCE_MAX), id: "s2", "aria-label": "Repeat your sentence" }) as HTMLInputElement;
  const count = h("span", null, `0/${SENTENCE_MAX}`);
  const meter = h("div", { class: "meter", "aria-hidden": "true" }, h("i"), h("i"), h("i"));
  const hint = h("div", { class: "hint", "aria-live": "polite" }, "At least 20 characters and 4 words.");
  const hint2 = h("div", { class: "hint", "aria-live": "polite" });
  const err = h("div", { "aria-live": "assertive" });
  const btn = h("button", { class: "btn", disabled: true }, "Create wallet") as HTMLButtonElement;
  const toggle = h("button", { class: "link inline", type: "button", "aria-pressed": "false" }, "Show") as HTMLButtonElement;

  const validate = () => {
    const c = checkSentence(s1.value);
    count.textContent = `${s1.value.length}/${SENTENCE_MAX}`;
    [...meter.children].forEach((el, i) => el.classList.toggle("on", c.ok && i < c.level));
    hint.className = "hint";
    hint.textContent = s1.value ? (c.ok ? ["", "OK. Longer is stronger.", "Good.", "Strong."][c.level] : c.problems[0]) : "At least 20 characters and 4 words.";
    const match = normalizeSentence(s1.value) === normalizeSentence(s2.value);
    hint2.className = "hint" + (s2.value ? (match ? " ok" : " bad") : "");
    hint2.textContent = s2.value ? (match ? "Matches." : "Doesn't match yet.") : "";
    btn.disabled = !(c.ok && match);
  };
  s1.addEventListener("input", validate);
  s2.addEventListener("input", validate);
  toggle.addEventListener("click", () => {
    const show = s1.type === "password";
    s1.type = s2.type = show ? "text" : "password";
    toggle.textContent = show ? "Hide" : "Show";
    toggle.setAttribute("aria-pressed", String(show));
  });

  btn.addEventListener("click", async () => {
    if (store.load().vault) return A.go({ r: "unlock" }); // never overwrite an existing wallet
    const sentence = s1.value;
    btn.disabled = true;
    s1.disabled = s2.disabled = true;
    put(err);
    put(btn, h("span", { class: "spin", style: { borderTopColor: "var(--paper)" } }), "Securing your wallet…");
    await sleep(30);
    try {
      const { seed, publicKey } = await generateKeypair();
      const pk = keyToString(publicKey);
      const rec = await seal(seed, pk, null, sentence);
      // prove the sentence really unlocks what we just made before anything is stored
      const back = await open(rec, sentence);
      if (back.length !== 32 || back.some((b, i) => b !== seed[i])) throw new Error("self-check failed");
      back.fill(0);
      const signer = await signerFromSeed(seed, publicKey);
      seed.fill(0);
      store.update((s) => {
        s.vault = rec;
        s.attempts = { fails: 0, lockedUntil: 0 };
      });
      A.setSession({ signer, publicKey, pkStr: pk, accountId: null });
      A.go({ r: "identity" });
    } catch (e: any) {
      put(err, errorBox(e instanceof Ed25519Unsupported ? e.message : "Couldn't create the wallet on this device. Nothing was saved."));
      s1.disabled = s2.disabled = false;
      btn.textContent = "Create wallet";
      validate();
    }
  });

  return h(
    "main",
    { class: "screen" },
    h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", minHeight: "44px" } }, brand(), netChip()),
    h("div", { style: { marginTop: "34px" } }, h("h1", { class: "title" }, "Create your wallet"), h("p", { class: "lede" }, "Choose a sentence only you would remember. It unlocks your wallet on this device.")),
    h(
      "div",
      { class: "stack", style: { marginTop: "26px" } },
      h("div", { class: "field" }, h("div", { class: "lbl" }, h("label", { for: "s1" }, "Personal sentence"), h("span", { class: "num", style: { fontWeight: 500 } }, count, " · ", toggle)), s1, meter, hint),
      h("div", { class: "field" }, h("div", { class: "lbl" }, h("label", { for: "s2" }, "Repeat it")), s2, hint2),
      h("div", { class: "callout" }, h("b", null, "No reset. "), "NEAT can't recover your sentence or your wallet. Forget it, or lose this device without a backup, and the wallet is gone. ", h("button", { class: "link inline", onClick: () => A.sheet(recoveryExplainer(), "How your sentence works", { closeButton: true }) }, "How it works")),
      err
    ),
    h("div", { class: "grow" }),
    h("div", { class: "actions" }, btn, h("button", { class: "btn ghost", onClick: () => A.go({ r: "restore" }) }, "Restore from a backup file"))
  );
}

// =============== Restore ===============
export function restoreView(A: AppCtx): HTMLElement {
  if (store.load().vault) {
    queueMicrotask(() => A.go({ r: "unlock" }));
    return h("main", { class: "screen" });
  }
  let rec: ReturnType<typeof parseBackup> = null;
  const fileInput = h("input", { type: "file", accept: ".neat,application/json", class: "sr", id: "bk" }) as HTMLInputElement;
  const fileLabel = h("div", { class: "hint" }, "Choose the .neat file you downloaded from NEAT Settings.");
  const sentence = h("input", { class: "input", type: "password", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Your sentence", disabled: true }) as HTMLInputElement;
  const err = h("div", { "aria-live": "assertive" });
  const btn = h("button", { class: "btn", disabled: true }, "Restore wallet") as HTMLButtonElement;

  fileInput.addEventListener("change", async () => {
    put(err);
    const f = fileInput.files?.[0];
    if (!f) return;
    rec = f.size < 20_000 ? parseBackup(await f.text()) : null;
    if (!rec) {
      fileLabel.className = "hint bad";
      fileLabel.textContent = "That isn't a NEAT backup file.";
      sentence.disabled = true;
      btn.disabled = true;
      return;
    }
    fileLabel.className = "hint ok";
    // The file's own claim about its name is not shown: a name is only displayed once the chain confirms this key controls it.
    fileLabel.textContent = "Backup found. Enter its sentence.";
    sentence.disabled = false;
    sentence.focus();
  });
  sentence.addEventListener("input", () => (btn.disabled = !rec || sentence.value.length === 0));

  btn.addEventListener("click", async () => {
    if (!rec || store.load().vault) return;
    const st = store.load().attempts;
    if (st.lockedUntil > Date.now()) return void put(err, errorBox(`Too many attempts. Try again in ${Math.ceil((st.lockedUntil - Date.now()) / 1000)}s.`));
    btn.disabled = true;
    put(btn, h("span", { class: "spin", style: { borderTopColor: "var(--paper)" } }), "Unlocking…");
    await sleep(30);
    try {
      const seed = await open(rec, sentence.value);
      const publicKey = keyFromString(rec.publicKey);
      const signer = await signerFromSeed(seed, publicKey);
      seed.fill(0);
      if (!(await selfCheck(signer.sign, publicKey))) throw new Error("mismatch");
      // A name is only shown if the chain agrees this key controls it.
      let accountId: string | null = null;
      if (rec.accountId) {
        try {
          const k = await A.rpc.viewAccessKey(rec.accountId, rec.publicKey);
          accountId = k?.fullAccess ? rec.accountId : null;
        } catch {
          put(err, errorBox("Couldn't reach NEAR Testnet to verify your name. Check your connection and try again. Nothing was restored."));
          btn.textContent = "Restore wallet";
          btn.disabled = false;
          return;
        }
      }
      const restored = { ...rec, accountId };
      store.update((s) => {
        s.vault = restored;
        s.attempts = { fails: 0, lockedUntil: 0 };
      });
      A.setSession({ signer, publicKey, pkStr: rec.publicKey, accountId });
      A.go({ r: accountId ? "home" : "identity" });
    } catch (e) {
      if (e instanceof WrongSentence) store.update((s) => (s.attempts = registerFailure(s.attempts)));
      put(err, errorBox(e instanceof WrongSentence ? "That sentence doesn't match this backup." : "This backup couldn't be restored."));
      btn.textContent = "Restore wallet";
      btn.disabled = false;
    }
  });

  return h(
    "main",
    { class: "screen" },
    top(A, "Restore", { r: "create" }, null, false),
    h("h1", { class: "title" }, "Restore a wallet"),
    h("p", { class: "lede" }, "Use the encrypted backup file you saved from NEAT, and the sentence you chose when you made it."),
    h(
      "div",
      { class: "stack", style: { marginTop: "26px" } },
      h("div", null, h("label", { class: "btn sec", for: "bk", style: { cursor: "pointer" } }, icon("download"), "Choose backup file"), fileInput, fileLabel),
      h("label", { class: "field" }, h("span", { class: "lbl" }, "Personal sentence"), sentence),
      err
    ),
    h("div", { class: "grow" }),
    h("div", { class: "actions" }, btn)
  );
}

async function selfCheck(sign: (m: Uint8Array) => Promise<Uint8Array>, pub: Uint8Array) {
  const msg = utf8.enc("neat/selfcheck/" + Date.now());
  return verifySignature(pub, msg, await sign(msg));
}

// =============== Unlock ===============
export function unlockView(A: AppCtx): HTMLElement {
  const vault = store.load().vault;
  if (!vault) {
    queueMicrotask(() => A.go({ r: "create" }));
    return h("main", { class: "screen" });
  }
  const name = vault.accountId ? displayName(vault.accountId) : null;
  const input = h("input", { class: "input", type: "password", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": "Your personal sentence", "data-autofocus": "" }) as HTMLInputElement;
  const msg = h("div", { class: "hint", "aria-live": "polite" });
  const btn = h("button", { class: "btn", disabled: true }, "Unlock") as HTMLButtonElement;
  const form = h("div", { class: "stack" });
  let timer: any;

  const lockLeft = () => Math.max(0, store.load().attempts.lockedUntil - Date.now());
  const refresh = () => {
    const left = lockLeft();
    if (left > 0) {
      msg.className = "hint bad";
      msg.textContent = `Too many wrong attempts. Try again in ${Math.ceil(left / 1000)}s.`;
      btn.disabled = true;
      timer = setTimeout(refresh, 500);
    } else {
      if (msg.textContent?.startsWith("Too many")) msg.textContent = "";
      btn.disabled = input.value.length === 0;
    }
  };
  A.onLeave(() => clearTimeout(timer));
  input.addEventListener("input", refresh);

  const submit = async () => {
    if (btn.disabled) return;
    btn.disabled = true;
    input.disabled = true;
    put(btn, h("span", { class: "spin", style: { borderTopColor: "var(--paper)" } }), "Unlocking…");
    await sleep(30);
    try {
      const seed = await open(vault, input.value);
      const publicKey = keyFromString(vault.publicKey);
      const signer = await signerFromSeed(seed, publicKey);
      seed.fill(0);
      if (!(await selfCheck(signer.sign, publicKey))) throw new Error("This wallet's stored data is inconsistent.");
      store.update((s) => (s.attempts = { fails: 0, lockedUntil: 0 }));
      A.setSession({ signer, publicKey, pkStr: vault.publicKey, accountId: vault.accountId });
      A.go({ r: vault.accountId ? "home" : "identity" });
    } catch (e: any) {
      input.disabled = false;
      btn.textContent = "Unlock";
      if (e instanceof WrongSentence) {
        const next = store.update((s) => (s.attempts = registerFailure(s.attempts))).attempts;
        msg.className = "hint bad";
        msg.textContent = "That sentence doesn't match this wallet.";
        form.classList.remove("shake");
        void form.offsetWidth;
        form.classList.add("shake");
        input.value = "";
        input.focus();
        if (next.lockedUntil > Date.now()) refresh();
        else btn.disabled = true;
      } else {
        msg.className = "hint bad";
        msg.textContent = e?.message ?? "Couldn't unlock.";
        btn.disabled = false;
      }
    }
  };
  btn.addEventListener("click", submit);
  input.addEventListener("keydown", (e) => e.key === "Enter" && submit());
  refresh();

  form.append(h("label", { class: "field" }, h("span", { class: "sr" }, "Your personal sentence"), input), msg);

  return h(
    "main",
    { class: "screen" },
    h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", minHeight: "44px" } }, brand(), netChip()),
    h("div", { class: "watermark", "aria-hidden": "true" }, chevron()),
    h("div", { style: { marginTop: "72px" } }, h("div", { class: "eyebrow" }, "Locked"), h("h1", { class: "display", style: { marginTop: "12px" } }, name ?? "Your wallet", name ? h("span", { class: "sfx" }, ".testnet") : null)),
    h("p", { class: "lede" }, "Enter your personal sentence."),
    h("div", { style: { marginTop: "22px" } }, form),
    h("div", { class: "grow" }),
    h("div", { class: "actions" }, btn, h("button", { class: "btn ghost", onClick: () => forgotSheet(A) }, "Forgot your sentence?"))
  );
}

export function forgotSheet(A: AppCtx) {
  let close = () => {};
  const content = h(
    "div",
    { class: "stack" },
    h("h2", { class: "title", style: { fontSize: "24px" } }, "Forgot your sentence?"),
    h("div", { class: "prose" }, h("p", null, "NEAT can't reset or recover it. Your sentence and key never leave this device."), h("p", null, "If you have an encrypted backup, it's locked with the same sentence, so it won't help either."), h("p", null, h("b", null, "Last resort: "), "erase this wallet from this device. Any funds in it stay on NEAR Testnet but become unreachable. We never create a new wallet for you without you asking.")),
    h("div", { class: "actions" }, h("button", { class: "btn sec", onClick: () => close() }, "Keep trying"), h("button", { class: "btn danger", onClick: () => { close(); eraseFlow(A); } }, "Erase this wallet…"))
  );
  close = A.sheet(content, "Forgot your sentence");
}

export function eraseFlow(A: AppCtx) {
  const vault = store.load().vault;
  if (!vault) return;
  const word = vault.accountId ? displayName(vault.accountId) : "erase";
  const input = h("input", { class: "input", autocomplete: "off", autocapitalize: "none", spellcheck: "false", "aria-label": `Type ${word} to confirm` }) as HTMLInputElement;
  const go = h("button", { class: "btn danger", disabled: true }, "Erase wallet") as HTMLButtonElement;
  input.addEventListener("input", () => (go.disabled = input.value.trim().toLowerCase() !== word));
  let close = () => {};
  go.addEventListener("click", () => {
    close();
    try {
      localStorage.removeItem("neat.state.v1");
    } catch {}
    store.useStorage(null);
    store.update((s) => Object.assign(s, store.emptyState()));
    A.setSession(null);
    A.go({ r: "create" });
  });
  close = A.sheet(
    h(
      "div",
      { class: "stack" },
      h("h2", { class: "title", style: { fontSize: "24px" } }, "Erase this wallet?"),
      h("div", { class: "prose" }, h("p", null, "This removes the encrypted wallet and history from this device. ", h("b", null, "It can't be undone."), " Without a backup and your sentence, the funds in it are lost for good.")),
      h("button", { class: "btn sec", onClick: () => downloadBackup(vault, vault.accountId ? displayName(vault.accountId) : null) }, icon("download"), "Download encrypted backup first"),
      h("label", { class: "field" }, h("span", { class: "lbl" }, `Type “${word}” to confirm`), input),
      h("div", { class: "actions" }, go, h("button", { class: "btn sec", onClick: () => close() }, "Cancel"))
    ),
    "Erase wallet"
  );
}

// =============== Identity ===============
export function identityView(A: AppCtx): HTMLElement {
  const sess = A.session;
  if (!sess) {
    queueMicrotask(() => A.go({ r: "unlock" }));
    return h("main", { class: "screen" });
  }
  if (sess.accountId) {
    queueMicrotask(() => A.go({ r: "home" }));
    return h("main", { class: "screen" });
  }
  const root = h("main", { class: "screen" });
  const body = h("div", { class: "grow", style: { display: "flex", flexDirection: "column" } });
  root.append(h("div", { style: { display: "flex", justifyContent: "space-between", alignItems: "center", minHeight: "44px" } }, brand(), netChip(A.online)), body);

  // Only ever called once the network has shown this wallet's key on the account. The person goes straight to their
  // dashboard: no interim screen, no explorer link.
  const finalize = (accountId: string) => {
    store.update((s) => {
      if (s.vault) s.vault.accountId = accountId;
      delete s.pending;
    });
    sess.accountId = accountId;
    A.go({ r: "home" });
    A.toast(`${displayName(accountId)}.testnet is registered`);
  };

  const showWaiting = (label: string, txHash?: string, note?: string) => {
    put(body,
      h("div", { style: { marginTop: "56px" } }, h("div", { class: "eyebrow" }, "Registering"), h("h1", { class: "display", style: { marginTop: "12px" } }, label, h("span", { class: "sfx" }, ".testnet"))),
      h("div", { style: { marginTop: "22px" } }, spinnerLine(note ?? "Waiting for the network to confirm…")),
      txHash ? h("div", { class: "card", style: { marginTop: "22px" } }, h("div", { class: "eyebrow" }, "Submitted transaction"), h("div", { class: "mono", style: { margin: "8px 0 10px" } }, shortHash(txHash)), explorerLink(txHash)) : null,
      h("div", { class: "grow" })
    );
  };

  const showStuck = (label: string, tx?: Reg) => {
    put(body,
      h("div", { style: { marginTop: "56px" } }, h("div", { class: "eyebrow" }, "Not confirmed yet"), h("h1", { class: "display", style: { marginTop: "12px" } }, label, h("span", { class: "sfx" }, ".testnet"))),
      h("p", { class: "lede" }, "The request was sent, but the network hasn't shown this account yet. Nothing is registered until it does. Checking again won't send a second request."),
      tx ? h("div", { class: "card", style: { marginTop: "22px" } }, h("div", { class: "eyebrow" }, "Submitted transaction"), h("div", { class: "mono", style: { margin: "8px 0 10px" } }, shortHash(tx.hash)), explorerLink(tx.hash)) : null,
      h("div", { class: "grow" }),
      h(
        "div",
        { class: "actions" },
        h("button", { class: "btn", onClick: () => waitFor(label, tx, true) }, "Check again"),
        h("button", { class: "btn ghost", onClick: () => { store.update((s) => delete s.pending); showPicker(); } }, "Choose a different name")
      )
    );
  };

  const showFailed = (label: string, reason: string, nameTaken: boolean, tx?: Reg, note?: string) => {
    store.update((s) => delete s.pending); // it failed on the network; nothing is pending any more
    put(body,
      h("div", { style: { marginTop: "56px" } }, h("div", { class: "eyebrow" }, "Not registered"), h("h1", { class: "display", style: { marginTop: "12px" } }, label, h("span", { class: "sfx" }, ".testnet"))),
      h("div", { style: { marginTop: "18px" } }, errorBox(reason, note)),
      tx ? h("div", { class: "card", style: { marginTop: "18px" } }, h("div", { class: "eyebrow" }, "Failed transaction"), h("div", { class: "mono", style: { margin: "8px 0 10px" } }, shortHash(tx.hash)), explorerLink(tx.hash)) : null,
      h("div", { class: "grow" }),
      h("div", { class: "actions" }, h("button", { class: "btn", onClick: () => (nameTaken ? showPicker() : register(label)) }, nameTaken ? "Choose another name" : "Try again"), nameTaken ? null : h("button", { class: "btn ghost", onClick: () => showPicker(label) }, "Change name"))
    );
  };

  type Reg = { hash: string; signerId?: string };
  const waitFor = async (label: string, tx?: Reg, quick = false) => {
    showWaiting(label, tx?.hash);
    const id = nameToAccountId(label);
    const res = await awaitRegistration(A.rpc, id, sess.publicKey, tx, { timeoutMs: quick ? 20_000 : 60_000 });
    if (A.route.r !== "identity") return;
    if (res.state === "registered") finalize(id);
    else if (res.state === "failed") showFailed(label, res.reason, res.nameTaken, tx);
    else showStuck(label, tx);
  };

  const showPicker = (preset = "") => {
    const input = h("input", { class: "input", autocomplete: "off", autocapitalize: "none", autocorrect: "off", spellcheck: "false", inputmode: "text", maxlength: "32", "aria-label": "Choose your NEAT name", value: preset, "data-autofocus": "" }) as HTMLInputElement;
    const hint = h("div", { class: "hint", "aria-live": "polite" }, "Lowercase letters, numbers, - and _.");
    const go = h("button", { class: "btn", disabled: true }, "Continue") as HTMLButtonElement;
    let seq = 0, timer: any, available = false, mine = false;
    A.onLeave(() => clearTimeout(timer));

    const onInput = () => {
      const v = input.value.toLowerCase().replace(/\s+/g, "");
      if (v !== input.value) input.value = v;
      available = false;
      mine = false;
      go.disabled = true;
      go.textContent = "Continue";
      clearTimeout(timer);
      const local = validateNameLabel(v);
      if (!v) { hint.className = "hint"; hint.textContent = "Lowercase letters, numbers, - and _."; return; }
      if (!local.ok) { hint.className = "hint bad"; hint.textContent = local.reason; return; }
      hint.className = "hint"; hint.textContent = "Checking availability…";
      const my = ++seq;
      timer = setTimeout(async () => {
        const r = await checkAvailability(A.rpc, v, sess.publicKey);
        if (my !== seq) return;
        if (r.state === "available") { hint.className = "hint ok"; hint.textContent = `${v}.testnet is available.`; available = true; go.disabled = false; }
        else if (r.state === "yours") { hint.className = "hint ok"; hint.textContent = `${v}.testnet already belongs to this wallet's key.`; available = true; mine = true; go.textContent = "Use this name"; go.disabled = false; }
        else if (r.state === "taken") { hint.className = "hint bad"; hint.textContent = `${v}.testnet is taken.`; }
        else if (r.state === "unknown") { hint.className = "hint bad"; hint.textContent = r.reason; }
        else { hint.className = "hint bad"; hint.textContent = r.reason; }
      }, 380);
    };
    input.addEventListener("input", onInput);
    go.addEventListener("click", async () => {
      if (!available) return;
      const label = input.value;
      if (mine) {
        // Nothing to register: the account already exists and this wallet's key controls it. Show it only once the chain confirms that again.
        go.disabled = true;
        hint.className = "hint";
        hint.textContent = "Confirming on the network…";
        if (await confirmRegistered(A.rpc, nameToAccountId(label), sess.publicKey, { timeoutMs: 4000, intervalMs: 1000 })) return finalize(nameToAccountId(label));
        hint.className = "hint bad";
        hint.textContent = "The network didn't confirm this name for your key. Try again.";
        go.disabled = false;
        return;
      }
      confirmSheet(A, {
        title: `Register ${label}.testnet?`,
        body: ["This creates a real account on NEAR Testnet, controlled only by the key on this device.", "NEAT's testnet funder pays the creation cost and gives the new account a starting balance of testnet tokens. They have no real-world value.", "You can't change the name afterwards."],
        confirm: "Register name",
        onConfirm: () => register(label),
      });
    });
    put(body, 
      h("div", { style: { marginTop: "34px" } }, h("h1", { class: "title" }, "Choose your name"), h("p", { class: "lede" }, "This is how people pay you. It's your public NEAT identity on NEAR Testnet.")),
      h("div", { style: { marginTop: "26px" } }, h("label", { class: "field" }, h("span", { class: "lbl" }, "Name"), h("div", { class: "suffix-wrap" }, input, h("span", { class: "sfx" }, ".testnet"))), hint),
      h("div", { class: "grow" }),
      h("div", { class: "actions" }, go)
    );
    if (preset) onInput();
    input.focus();
  };

  const register = async (label: string) => {
    put(body, h("div", { style: { marginTop: "56px" } }, spinnerLine("Sending registration request…")));
    const res = await requestRegistration(label, sess.publicKey, CONFIG.register);
    if (!res.ok) {
      if (res.code === "taken") {
        // maybe an earlier attempt of ours already succeeded
        if (await confirmRegistered(A.rpc, nameToAccountId(label), sess.publicKey, { timeoutMs: 4000, intervalMs: 1000 })) return finalize(nameToAccountId(label));
      }
      return showFailed(label, res.message, res.code === "taken", undefined, res.detail);
    }
    store.update((s) => (s.pending = { label, txHash: res.txHash, signerId: res.signerId, at: Date.now() }));
    await waitFor(label, { hash: res.txHash, signerId: res.signerId });
  };

  const pending = store.load().pending;
  if (pending) void waitFor(pending.label, { hash: pending.txHash, signerId: pending.signerId }, true);
  else showPicker();
  return root;
}
