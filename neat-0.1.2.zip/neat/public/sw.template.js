// NEAT service worker: offline application SHELL only.
// It never caches or intercepts RPC, API or any cross-origin request, so balances, fees and
// transaction status always come live from the network. Offline, the app opens and says so.
const VERSION = "%VERSION%";
const SHELL = %SHELL%;

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (k !== VERSION) await caches.delete(k);
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  const url = new URL(req.url);
  if (req.method !== "GET" || url.origin !== self.location.origin) return;
  if (req.mode === "navigate") {
    e.respondWith(fetch(req).catch(() => caches.match("/index.html")));
    return;
  }
  // Only the application shell is ever served from the cache. Everything else (RPC, the registration API, an
  // index lookup, even if a deployment happens to serve them from this origin) goes straight to the network.
  if (!SHELL.includes(url.pathname)) return;
  e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); }
    return res;
  })));
});
