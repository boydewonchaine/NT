# NEAT: notes for working in this repo

NEAT is a QR-first, self-custodial payment PWA on **NEAR Testnet**. Zero runtime dependencies: vanilla TypeScript DOM, bundled by esbuild into `dist/`, plus one serverless function (`api/register.ts` → `src/server/register.ts`) that registers `name.testnet` accounts. `README.md` is the user-facing doc; this file is what you need to change code safely.

## Commands

```bash
npm run typecheck     # tsc -p tsconfig.json (strict, noUnusedLocals/Parameters). Keep it clean
npm test              # tsx --test tests/*.test.ts  (unit; no browser, no network)
npm run build         # node scripts/build.mjs → dist/   (NEAT_OUT=<dir> for another folder, relative to the repo)
npm run e2e           # builds dist-test/ against the mock chain, then runs 3 Playwright suites (needs `npx playwright install chromium`)
npm run live-check    # checks the REAL testnet (needs internet). `-- --spend` registers and pays for real (testnet only)
npm run funder-keygen # prints NEAT_FUNDER_ID / NEAT_FUNDER_KEY
```

Sandbox note: if `esbuild`, `playwright`, `tweetnacl` or `typescript` aren't installed normally, set `ESBUILD_PATH`, `PLAYWRIGHT_PATH`, `TWEETNACL_PATH`, `TYPESCRIPT_PATH` to their folders (the scripts and tests read these). The crypto-compat and hygiene suites *skip* when their tool is missing, so check the "skipped" count.

## Non-negotiable product rules (tests enforce most of them; don't weaken them)

1. No external wallet-connect onboarding. NEAT creates the wallet.
2. Send and receive only by QR. **No copy-address, copy-link, paste-address or paste-link anywhere**, and no sharing of text or URLs (only a QR *image*).
3. The identity is `name.testnet`, never a raw address.
4. **NEAR Testnet only.** No mainnet endpoint, suffix or network name in the code.
5. Never fabricate or assume a success: names, balances, quotes, transactions. A name is "registered" only when the chain shows the user's key on the account; a payment is "completed" only at `FINAL` + success + all receipts executed; "received" shows the amount the *network* reports.
6. No hardcoded fees. The network fee comes from `EXPERIMENTAL_protocol_config` × `gas_price`. People see ONE fee line, the "Stamp fee" (`stampFee` in `core/fees.ts`). Today it is the network fee alone: there is no NEAT fee, and never invent one. The owner has asked for a NEAT fee to be folded into that same line (network fee + NEAT fee); until its fraction, destination account and mechanism are decided (a NEAR transaction has one receiver, so it is a second transaction or a contract), it does not exist.
7. The personal sentence is an unlock credential, **not** the key. Keys come from the CSPRNG. Never store or transmit the sentence, the derived key or the private key; never log recovery material (nothing is logged at all; a test enforces it).
8. A failed unlock never silently creates a replacement wallet.
9. Sign locally; **persist the signed bytes before broadcasting**; only ever re-send identical bytes; never sign or submit offline.
10. No dead buttons, no emoji, no generic gradients, no fake install button.

## Architecture in one screen

- `src/core/` is UI-free and runs in Node and the browser. `vault` (KDF + AES-GCM, attempt backoff), `near` (account ids, Borsh, signing, Ed25519 via WebCrypto), `rpc` (JSON-RPC with failover and typed errors), `fees`, `pay` (sign → persist → broadcast → track), `identity` (name availability, registration client, on-chain confirmation), `history` (incoming discovery and request reconciliation), `payload` (signed payment-request QRs), `qr` / `qrdecode` (encoder, software decoder), `store` (the only module that touches browser storage).
- `src/ui/` is the app. The receipt (`receiptView` in `views-pay.ts`) is a small printed slip (`.slip`, 304 px wide, typewriter face from `--typewriter`, regular weight; only the names and header are bold) built from `ln()`, `stampTime()` and `statusStamp()` in `parts.ts`. Registration success goes straight to Home (`finalize` in `views-auth.ts`: no interim screen, no explorer link). `app.ts` holds `AppCtx` (routing, session, auto-lock, toasts, modal `sheet()`), `views-*.ts` build screens with `h()` from `dom.ts`, `parts.ts` has shared pieces, `styles.css` all styling (tokens in `:root`, dark theme tokenised).
- `src/server/register.ts` is framework-free; `api/register.ts` is the Vercel adapter (`api/tsconfig.json` makes it compile as CommonJS). POST registers a name; GET (`funderStatus`) is the readiness check: it registers nothing and returns only what is public on the chain.
- Funder problems each have their own `code` (`unconfigured`, `funder_config`, `funder_unfunded`, `funder_key`, `funder_empty`), a one-line `error` and a specific `detail` for whoever runs the deployment. Never collapse them into one "not configured" (the first deployment did, and nobody could tell what to fix), never guess a cause from the HTTP status alone (a bare 503 is not "not configured"), and never put a secret or any part of one in a reply. The client wording is in `requestRegistration` (`identity.ts`); the error screen is `showFailed` in `views-auth.ts`. `scripts/live-check.ts` reuses `readFunder` / `checkFunder`, so it says what the live site would say.
- `tests/mock-chain.ts` is a *test-only* simulated NEAR chain (real Borsh decoding and signature checks, real RPC response shapes). It proves self-consistency, **not** compatibility with the real network. `tests/e2e-server.ts` wraps it with the built app, the real `handleRegister` and a NearBlocks-shaped index.

## Conventions and traps

- DOM is built with `h(tag, props, ...children)`; `innerHTML` exists only in `dom.ts` (`svgFrom`). No `eval`, no `Function`, no `document.write`.
- Browser storage is touched only by `store.ts` (and the explicit erase flow). Key `neat.state.v1`. Corrupt state is preserved, never overwritten.
- Network is reached only through `rpc.ts`, `identity.ts` (registration), `history.ts` (index).
- Account ids shown to people are display names (`displayName`); the on-chain id is `${label}.testnet`.
- Payment index (NearBlocks) is **rationed**: free tier is ~6 calls/min and ~333/day. `AppCtx.refreshBalance()` watches the balance over RPC and calls `expectIncoming()` when it rises; background polling (`syncIncoming(..., { background: true })`) otherwise asks only every 5 minutes; 429 backs off 1, 2, 4… minutes up to 30. Don't add polling that bypasses `syncIncoming`.
- The index is only a *hint* (candidate hashes). Every displayed fact comes from the RPC `tx` result (`transferOf`).
- `singleUse(req)` (a request with an amount) is deduplicated by request id; an open QR (no amount) is a standing code and never is.
- Modals: use `A.sheet(content, label, { closeButton? })` (focus trap, Escape, inert background, returns `close`). Don't hand-roll overlays.
- Every screen has exactly one `h1` (the title text uses `top(A, title, back, right, heading)`), a `TITLES` entry in `app.ts`, and `data-autofocus` or the `h1` as the focus target.
- CSS: hover/active/focus backgrounds may only use audited surfaces (`--sunk`, `--raise`, …); `a11y.test.ts` fails otherwise. Tap targets 44px (hard minimum 24).
- `hygiene.test.ts` rejects the standalone words "copy" and "paste" in any string literal under `src/` and `api/` (including server messages): say "enter it again" instead. It also rejects a string that is exactly "cut", "copy" or "paste" (they are clipboard event names), so don't use them as class names (the receipt's dashed lines are `.rule`).
- Tests: `tsx` injects `__name`, which doesn't exist inside the browser; `prep(ctx)` in `tests/e2e-lib.mts` defines it. CSS uppercases eyebrow text and the receipt's labels and stamp, so match them with `/i` (a case-sensitive negative check on uppercased text passes vacuously). A finished registration is detected by waiting for `.home`. Use `exact: true` for short role names (Back, Send, Receive).
- Eval/CSP probes must run from timer callbacks: DevTools-evaluated code bypasses the page CSP.

## Before you call something done

`npm run typecheck && npm test && npm run build && npm run e2e` must all pass. A screen existing is not a feature working: if you change behaviour, add a test that exercises it against the mock chain, and if it touches real-network behaviour, say plainly that it is unverified until `npm run live-check -- --spend` has been run. Confirmed live so far (owner's Vercel deployment, 2026-11-09, reported with screenshots): registration through the funder, and one payment that reached FINAL with the network-reported amount. Not yet confirmed: the NearBlocks index, camera scanning on a phone.
