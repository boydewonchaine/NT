// Vercel serverless function.
//   POST /api/register { label, publicKey } → { txHash, accountId }
//   GET  /api/register                      → { ready, ... }  is registration set up? (nothing is registered; no secret is shown)
// Holds ONLY the funder key (env). Never receives any user secret. See README "Name registration".
import { funderStatus, handleRegister } from "../src/server/register";
import { DEFAULT_ENDPOINTS, Rpc } from "../src/core/rpc";

declare const process: { env: Record<string, string | undefined> };

export default async function handler(req: any, res: any) {
  res.setHeader("cache-control", "no-store");
  try {
    const endpoints = (process.env.NEAT_RPC ?? "").split(",").map((s) => s.trim()).filter(Boolean);
    const rpc = new Rpc({ endpoints: endpoints.length ? endpoints : DEFAULT_ENDPOINTS, apiKey: process.env.NEAT_RPC_KEY });
    const fwd = String(req.headers?.["x-forwarded-for"] ?? req.socket?.remoteAddress ?? "unknown");
    const ip = fwd.split(",")[0].trim();
    if (req.method === "GET") {
      const { status, body: out } = await funderStatus(process.env, rpc, ip);
      return res.status(status).json(out);
    }
    if (req.method !== "POST") return res.status(405).json({ error: "POST only" });
    let body = req.body;
    if (typeof body === "string") {
      try { body = JSON.parse(body); } catch { body = null; }
    }
    const { status, body: out } = await handleRegister(body, process.env, ip, rpc);
    res.status(status).json(out);
  } catch {
    // Always answer in JSON, so the app can say something specific instead of showing a platform error page.
    res.status(500).json({ code: "failed", error: "The registration service hit an unexpected error." });
  }
}
