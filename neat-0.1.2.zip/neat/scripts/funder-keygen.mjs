// Generates the key for NEAT's registration funder, with no dependencies beyond Node's own crypto.
//
//   node scripts/funder-keygen.mjs
//
// It prints three things:
//   NEAT_FUNDER_ID    a testnet "implicit" account id (the 64-hex form of the public key). Such an account comes into
//                     existence when it first receives NEAR, so nothing needs registering: send it NEAR from any
//                     testnet account that has some (a faucet may or may not accept this form of id).
//   NEAT_FUNDER_KEY   the secret key, in the form the registration function expects. Put it in your host's secret
//                     store (for example Vercel environment variables). Do not commit it, and do not put it in the app.
//   a reminder of how to fund the account.
//
// The key is generated here, locally, and is not sent anywhere. Run it on a machine you trust.

import { generateKeyPairSync } from "node:crypto";

const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function base58(bytes) {
  let n = 0n;
  for (const b of bytes) n = (n << 8n) | BigInt(b);
  let out = "";
  while (n > 0n) {
    out = ALPHABET[Number(n % 58n)] + out;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b !== 0) break;
    out = "1" + out;
  }
  return out;
}

const { privateKey, publicKey } = generateKeyPairSync("ed25519");
const seed = Buffer.from(privateKey.export({ format: "der", type: "pkcs8" })).subarray(-32);
const pub = Buffer.from(publicKey.export({ format: "der", type: "spki" })).subarray(-32);
if (seed.length !== 32 || pub.length !== 32) throw new Error("unexpected key encoding");

console.log(`NEAT_FUNDER_ID=${pub.toString("hex")}`);
console.log(`NEAT_FUNDER_KEY=ed25519:${base58(Buffer.concat([seed, pub]))}`);
console.error("");
console.error("Next:");
console.error("  1. Fund the account id above. It doesn't exist on the network until it first receives testnet NEAR: send it some from");
console.error("     any testnet account that has tokens (the faucet, https://docs.near.org/getting-started/faucet, may not accept 64-hex ids).");
console.error("  2. Add NEAT_FUNDER_ID and NEAT_FUNDER_KEY to your host's environment variables, then REDEPLOY (a running deployment");
console.error("     never sees variables added later).");
console.error("  3. Open https://<your-site>/api/register: it says \"ready\": true, or what is still wrong. It registers nothing.");
console.error("  (From a computer you can also check with:  NEAT_FUNDER_ID=... NEAT_FUNDER_KEY=... npx tsx scripts/live-check.ts)");
console.error("Keep the secret key private. Anyone who has it can spend the funder's testnet tokens.");
