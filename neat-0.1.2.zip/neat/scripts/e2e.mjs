#!/usr/bin/env node
// Runs the whole end-to-end battery: builds the test bundle (its RPC / index endpoints pointed at the local mock
// chain), then runs the three browser suites one after another. Needs Playwright with Chromium installed:
//   npm i -D playwright && npx playwright install chromium
// Env: E2E_OUT (where screenshots and result files go; default: <tmpdir>/neat-e2e), PLAYWRIGHT_PATH, ESBUILD_PATH.
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const env = { ...process.env, NEAT_OUT: "dist-test", NEAT_RPC: "http://127.0.0.1:4173/rpc", NEAT_INDEX: "http://127.0.0.1:4173/index" };
const run = (cmd, args, e = process.env) => spawnSync(cmd, args, { cwd: root, stdio: "inherit", env: e }).status ?? 1;

if (run(process.execPath, ["scripts/build.mjs"], env) !== 0) process.exit(1);

const local = process.env.TSX ?? join(root, "node_modules/.bin/tsx");
const only = process.argv.slice(2);
const suites = ["e2e.mts", "e2e-failures.mts", "e2e-platform.mts"].filter((s) => !only.length || only.some((o) => s.includes(o)));
let failed = 0;
for (const s of suites) {
  console.log(`\n=== ${s} ===`);
  const code = existsSync(local) ? run(local, ["tests/" + s]) : run("npx", ["--no-install", "tsx", "tests/" + s]);
  if (code !== 0) failed++;
}
console.log(failed ? `\n${failed} suite(s) FAILED` : "\nall end-to-end suites passed");
process.exit(failed ? 1 : 0);
