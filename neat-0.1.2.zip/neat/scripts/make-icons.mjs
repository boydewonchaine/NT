// Builds PWA icons from the traced NEAT chevron (the same path as public/logo.svg). Run: node scripts/make-icons.mjs
// The PNGs are committed, so this is only needed if you change the mark. It needs `npm i -D sharp` (or SHARP_PATH=<folder>).
import { createRequire } from "node:module";
const sharp = createRequire(import.meta.url)(process.env.SHARP_PATH ?? "sharp");
import { writeFileSync } from "node:fs";
const PATH = "M.1 0 .5 10.5 61.1 40.5 .8 66.4.4 78 76.1 44.8 76 37.1Z";
const icon = (size, glyphFrac, bg, fg) => {
  const gh = size * glyphFrac, s = gh / 78, gw = 76.1 * s;
  const x = (size - gw) / 2 + gw * 0.03, y = (size - gh) / 2; // optical nudge: chevron mass sits left of its bbox centre
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}"><rect width="${size}" height="${size}" fill="${bg}"/><g transform="translate(${x} ${y}) scale(${s})"><path fill="${fg}" d="${PATH}"/></g></svg>`;
};
const BG = "#eeeeee", FG = "#292a2f";
const jobs = [
  ["public/icons/icon-192.png", 192, 0.42],
  ["public/icons/icon-512.png", 512, 0.42],
  ["public/icons/maskable-512.png", 512, 0.32], // inside the 80% safe zone
  ["public/icons/apple-touch-icon.png", 180, 0.42],
];
for (const [file, size, frac] of jobs) await sharp(Buffer.from(icon(size, frac, BG, FG))).png().toFile(file);
writeFileSync("public/icons/icon.svg", icon(512, 0.42, BG, FG));
console.log("icons written");
