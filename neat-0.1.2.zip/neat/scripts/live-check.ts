// Live compatibility check: does NEAT's picture of NEAR Testnet match the real network?
//
// NEAT was developed and tested against a simulated chain (the build sandbox could not reach NEAR), so this
// script is how you verify the real thing in about a minute, from any machine with internet access:
//
//   npx tsx scripts/live-check.ts            read-only: RPC endpoints, CORS, fee schedule, payment index, funder account
//   npx tsx scripts/live-check.ts --spend    ALSO registers two throw-away names and sends a real testnet payment between
//                                             them through NEAT's own code (needs a funded funder; spends testnet tokens only,
//                                             and sends nearly all of them back to the funder at the end)
//
// Environment (all optional; defaults match the app):
//   NEAT_RPC             comma-separated RPC URLs to check (default: the app's built-in list)
//   NEAT_RPC_KEY         API key the registration function would send as `Authorization: Bearer`
//   NEAT_INDEX           payment index base URL (default https://api-testnet.nearblocks.io)
//   NEAT_ORIGIN          the origin your site will be served from, for the CORS checks (default https://neat.example)
//   NEAT_FUNDER_ID, NEAT_FUNDER_KEY, NEAT_STARTING_BALANCE   the registration funder (see README)
//   NEAT_LIVE_AMOUNT     NEAR to send in --spend mode (default 0.1)
//   NEAT_CHECK_ACCOUNT   an existing testnet account used for read-only probes (default `testnet`)
//
// Exit code is 1 if anything FAILED. WARN means "works, but read the message".

import { DEFAULT_ENDPOINTS, Rpc, RpcError } from "../src/core/rpc";
import { costsFromConfig, estimateTransferFee, maxSendable } from "../src/core/fees";
import { resetIndexState, setIndexBase, syncIncoming } from "../src/core/history";
import { awaitRegistration } from "../src/core/identity";
import { authorizeAndSend, refreshTx } from "../src/core/pay";
import { generateKeypair, keyToString, signerFromSeed } from "../src/core/near";
import { checkFunder, handleRegister, readFunder, startingBalance } from "../src/server/register";
import * as store from "../src/core/store";
import { formatFee, formatNear, parseNear } from "../src/core/units";
import { base58Encode, toHex } from "../src/core/encoding";

declare const process: { argv: string[]; env: Record<string, string | undefined>; exit(code: number): never };

export type Level = "pass" | "warn" | "fail" | "info";
export type LiveOptions = {
  rpcUrls: string[];
  rpcKey?: string;
  indexBase: string;
  origin: string;
  checkAccount: string;
  env: Record<string, string | undefined>;
  spend: boolean;
  amount: string;
  fetchImpl?: typeof fetch;
  sleep?: (ms: number) => Promise<void>;
};
export type Tally = { pass: number; warn: number; fail: number };

const hostOf = (u: string) => {
  try {
    return new URL(u).host;
  } catch {
    return u;
  }
};
const memStorage = () => {
  const m = new Map<string, string>();
  return { getItem: (k: string) => m.get(k) ?? null, setItem: (k: string, v: string) => void m.set(k, v) };
};
const print = (level: Level, text: string) => console.log(`${{ pass: "PASS", warn: "WARN", fail: "FAIL", info: "    " }[level]}  ${text}`);

export async function runLiveCheck(o: LiveOptions, emit: (level: Level, text: string) => void = print): Promise<Tally> {
  const f: typeof fetch = o.fetchImpl ?? ((...a) => fetch(...a));
  const sleep = o.sleep ?? ((ms: number) => new Promise<void>((r) => setTimeout(r, ms)));
  const tally: Tally = { pass: 0, warn: 0, fail: 0 };
  const say = (level: Level, text: string) => {
    if (level !== "info") tally[level]++;
    emit(level, text);
  };
  const explorer = (hash: string) => `https://testnet.nearblocks.io/txns/${hash}`;

  // ---------- 1. RPC endpoints, checked the way a browser will use them ----------
  const good: string[] = [];
  for (const url of o.rpcUrls) {
    const host = hostOf(url);
    const t0 = Date.now();
    let res: Response;
    try {
      res = await f(url, { method: "POST", headers: { "content-type": "application/json", origin: o.origin }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "status", params: [] }) });
    } catch (e: any) {
      say("fail", `${host}: unreachable (${e?.message ?? e})`);
      continue;
    }
    if (res.status === 401 || res.status === 403) {
      say("fail", `${host}: HTTP ${res.status}. This endpoint wants an API key. A key placed in the browser bundle is public, so use one restricted to your site's domain, or pick another provider.`);
      continue;
    }
    if (res.status === 429) {
      say("fail", `${host}: HTTP 429, rate limited. Pick a provider with a higher limit, or add an API key.`);
      continue;
    }
    if (!res.ok) {
      say("fail", `${host}: HTTP ${res.status}`);
      continue;
    }
    let st: any;
    try {
      st = (await res.json()).result;
    } catch {
      say("fail", `${host}: the reply was not JSON-RPC`);
      continue;
    }
    if (st?.chain_id !== "testnet") {
      say("fail", `${host}: chain_id is "${st?.chain_id}", not "testnet". NEAT is testnet-only.`);
      continue;
    }
    say("pass", `${host}: NEAR Testnet, block ${st.sync_info?.latest_block_height}, answered in ${Date.now() - t0} ms`);
    if (st.sync_info?.syncing === true) say("warn", `${host}: the node reports it is still syncing`);

    // a browser will not talk to an endpoint that does not allow its origin
    const acao = res.headers.get("access-control-allow-origin");
    let cors = acao === "*" || acao === o.origin;
    if (cors) {
      try {
        const pf = await f(url, { method: "OPTIONS", headers: { origin: o.origin, "access-control-request-method": "POST", "access-control-request-headers": "content-type" } });
        const allowed = (pf.headers.get("access-control-allow-headers") ?? "").toLowerCase();
        cors = pf.status >= 200 && pf.status < 300 && !!pf.headers.get("access-control-allow-origin") && (allowed.includes("content-type") || allowed.trim() === "*");
      } catch {
        cors = false;
      }
    }
    if (cors) {
      say("pass", `${host}: allows browser requests from ${o.origin} (CORS, including the preflight)`);
      good.push(url);
    } else {
      say("fail", `${host}: does not allow browser requests from ${o.origin} (CORS). The app could not use it from a page.`);
    }
  }
  if (!good.length) {
    say("fail", "No RPC endpoint passed, so the remaining checks were skipped. Set NEAT_RPC to endpoints from https://docs.near.org/api/rpc/providers");
    return tally;
  }

  const rpc = new Rpc({ endpoints: good, fetchImpl: f, timeoutMs: 20_000 }); // what the browser uses
  const srv = new Rpc({ endpoints: good, fetchImpl: f, timeoutMs: 20_000, apiKey: o.rpcKey }); // what /api/register uses

  // ---------- 2. the calls NEAT makes, and the shapes it reads ----------
  try {
    const b = await rpc.finalBlock();
    const age = Date.now() - b.timestampMs;
    say(age < 30_000 ? "pass" : "warn", `final block ${b.height} is ${Math.round(age / 1000)} s old`);
    const cfg = await rpc.protocolConfig();
    const k = costsFromConfig(cfg);
    say("pass", "fee schedule read from EXPERIMENTAL_protocol_config");
    say(k.ratio ? "pass" : "warn", k.ratio ? `balance-check margin read from the network (${k.ratio.num}/${k.ratio.den})` : "pessimistic_gas_price_inflation_ratio was not readable; NEAT falls back to 103/100 for its balance check only (never for the fee it shows)");
    const price = await rpc.gasPrice();
    say(price > 0n ? "pass" : "fail", `gas price ${price} yoctoNEAR per gas`);
    const probe = (await generateKeypair()).publicKey; // an implicit account that does not exist
    const toSelf = await estimateTransferFee(rpc, o.checkAccount, o.checkAccount);
    const toNew = await estimateTransferFee(rpc, o.checkAccount, toHex(probe));
    say("info", `estimated transfer fee: ${formatFee(toSelf.fee)} NEAR (to self), ${formatFee(toNew.fee)} NEAR (to a new implicit account). Compare with a recent transfer on testnet.nearblocks.io`);
    say(toSelf.fee > 0n && toNew.fee < 10n ** 22n ? "pass" : "warn", "the estimate is positive and under 0.01 NEAR, as a plain transfer should be");
    const ghost = await rpc.viewAccount(`neat-live-${toHex(probe).slice(0, 12)}.testnet`);
    say(ghost === null ? "pass" : "warn", "an account that does not exist is reported as absent (not as an error)");
    const nokey = await rpc.viewAccessKey(o.checkAccount, keyToString(probe));
    say(nokey === null ? "pass" : "warn", "a key that is not on an account is reported as absent (not as an error)");
    const fake = base58Encode(crypto.getRandomValues(new Uint8Array(32)));
    const unknown = await rpc.txStatus(fake, o.checkAccount).catch((e) => e);
    say(unknown === null ? "pass" : "warn", unknown === null ? "an unknown transaction hash is reported as unknown, not as a failure" : `an unknown transaction hash gave: ${String(unknown?.message ?? unknown)}`);
    try {
      await rpc.broadcast(Uint8Array.of(1, 2, 3));
      say("warn", "the node accepted a malformed transaction, which it should not");
    } catch (e: any) {
      const kind = e instanceof RpcError ? e.kind : "other";
      say(kind === "invalid_tx" || kind === "rpc" ? "pass" : "warn", `a malformed transaction is rejected by the node (classified as "${kind}")`);
    }
  } catch (e: any) {
    say("fail", `reading the network failed: ${e?.message ?? e}`);
  }

  // ---------- 3. the payment index (only ever a hint; every fact is re-read over RPC) ----------
  const base = o.indexBase.replace(/\/+$/, "");
  try {
    const res = await f(`${base}/v1/account/${encodeURIComponent(o.checkAccount)}/txns?page=1&per_page=5&order=desc`, { headers: { accept: "application/json", origin: o.origin } });
    if (res.status === 429) {
      say("warn", `${hostOf(base)}: HTTP 429. NearBlocks' free tier is small (about 6 calls a minute and 333 a day); NEAT rations its lookups, but this address is over the limit right now.`);
    } else if (!res.ok) {
      say("fail", `${hostOf(base)}: HTTP ${res.status}`);
    } else {
      const j: any = await res.json();
      const rows: any[] = Array.isArray(j?.txns) ? j.txns : [];
      say(rows.length ? "pass" : "warn", rows.length ? `${hostOf(base)}: returned ${rows.length} transactions in the shape NEAT reads` : `${hostOf(base)}: returned no transactions for ${o.checkAccount}`);
      const acao = res.headers.get("access-control-allow-origin");
      say(acao === "*" || acao === o.origin ? "pass" : "fail", acao === "*" || acao === o.origin ? `${hostOf(base)}: allows browser requests from ${o.origin}` : `${hostOf(base)}: does not allow browser requests from ${o.origin} (CORS), so incoming payments could not be discovered`);
      const row = rows.find((r) => typeof r?.transaction_hash === "string");
      if (row) {
        const sender = row.signer_account_id ?? row.predecessor_account_id;
        const known = typeof sender === "string" ? await rpc.txStatus(row.transaction_hash, sender).catch(() => undefined) : undefined;
        say(known ? "pass" : "warn", known ? "a hash listed by the index is found by the RPC `tx` method using the index's sender, so incoming payments can be verified on the network" : "the RPC could not find the first indexed transaction using the index's sender; incoming payments may not verify (NEAT then discards them rather than guess)");
      } else if (rows.length) {
        say("warn", "the index rows carry no `transaction_hash` NEAT can read");
      }
    }
  } catch (e: any) {
    say("fail", `${hostOf(base)}: unreachable (${e?.message ?? e})`);
  }

  // ---------- 4. the registration funder ----------
  // The same checks the registration function makes (src/server/register.ts), so this says what the live site would say.
  const cfg = o.env.NEAT_FUNDER_ID || o.env.NEAT_FUNDER_KEY ? await readFunder(o.env) : null;
  const fid = cfg?.ok ? cfg.funder.id : undefined;
  let funderOk = false;
  if (!cfg) {
    say("info", "NEAT_FUNDER_ID / NEAT_FUNDER_KEY are not set, so name registration is not checked (see README, \"Name registration\")");
  } else if (!cfg.ok) {
    say("fail", `${cfg.reply.body.error} ${cfg.reply.body.detail}`);
  } else {
    try {
      const st = await checkFunder(cfg.funder, o.env, srv);
      if (!st.ok) say("fail", `${st.reply.body.error} ${st.reply.body.detail}`);
      else {
        const per = st.deposit + 20n * 10n ** 21n; // starting balance + ~0.02 NEAR for gas
        const names = st.balance > 5n * 10n ** 22n ? (st.balance - 5n * 10n ** 22n) / per : 0n;
        say(names >= 2n ? "pass" : "warn", `funder ${cfg.funder.id} holds ${formatNear(st.balance, 4)} NEAR: enough for about ${names} more names at ${formatNear(st.deposit, 4)} NEAR each`);
        funderOk = true;
      }
    } catch (e: any) {
      say("fail", `could not check the funder: ${e?.message ?? e}`);
    }
  }

  // ---------- 5. (--spend) a real registration and payment through NEAT's own code ----------
  if (!o.spend) {
    say("info", "Read-only run. Add --spend (with a funded funder) to register two names and send a real testnet payment.");
    return tally;
  }
  if (!funderOk || !fid) {
    say("fail", "--spend needs a working funder (see the funder check above)");
    return tally;
  }
  say("info", `--spend: registering two throw-away names from ${fid} and sending ${o.amount} NEAR between them`);

  const settle = async (id: string) => {
    let cur = store.getTx(id)!;
    const t0 = Date.now();
    while (cur.status !== "completed" && cur.status !== "failed" && Date.now() - t0 < 120_000) {
      await sleep(2000);
      cur = (await refreshTx(rpc, id)).tx;
    }
    return cur;
  };

  const run = toHex(crypto.getRandomValues(new Uint8Array(3)));
  const people: { id: string; seed: Uint8Array; publicKey: Uint8Array }[] = [];
  for (const who of ["a", "b"]) {
    const kp = await generateKeypair();
    const label = `neat-live-${run}-${who}`;
    const reg = await handleRegister({ label, publicKey: keyToString(kp.publicKey) }, o.env, "live-check", srv);
    if (reg.status !== 200) {
      say("fail", `registering ${label}.testnet: ${String(reg.body.code ?? reg.status)}: ${String(reg.body.error ?? "")}`);
      return tally;
    }
    const id = `${label}.testnet`;
    const state = await awaitRegistration(rpc, id, kp.publicKey, { hash: String(reg.body.txHash), signerId: String(reg.body.signerId ?? fid) }, { timeoutMs: 90_000, intervalMs: 2000, sleep });
    if (state.state !== "registered") {
      say("fail", `${id} was not confirmed on-chain (${state.state}). ${explorer(String(reg.body.txHash))}`);
      return tally;
    }
    say("pass", `${id} is registered on-chain, controlled by its own key. ${explorer(String(reg.body.txHash))}`);
    people.push({ id, ...kp });
  }
  const [a, b] = people;
  const bal = async (id: string) => (await rpc.viewAccount(id))?.amount ?? 0n;
  const [a0, b0] = [await bal(a.id), await bal(b.id)];
  say(a0 === startingBalance(o.env) ? "pass" : "warn", `a new account starts with ${formatNear(a0, 6)} NEAR (starting balance ${formatNear(startingBalance(o.env), 6)})`);

  const amount = parseNear(o.amount);
  if (amount === null || amount <= 0n) {
    say("fail", `NEAT_LIVE_AMOUNT "${o.amount}" is not a valid amount`);
    return tally;
  }
  store.useStorage(memStorage());
  const est = await estimateTransferFee(rpc, a.id, b.id);
  const signer = await signerFromSeed(a.seed, a.publicKey);
  const sent = await authorizeAndSend({ rpc, signer, fromId: a.id, toId: b.id, amount, estimate: est });
  say("info", `submitted ${sent.id} (${sent.status}). ${explorer(sent.id)}`);
  const done = await settle(sent.id);
  if (done.status !== "completed") {
    say("fail", `the payment did not complete: ${done.status}${done.failure ? ` (${done.failure})` : ""}`);
  } else {
    say("pass", `payment completed with network finality ${done.finality}`);
    say(done.onchainAmount === amount.toString() ? "pass" : "fail", `the network reports ${formatNear(BigInt(done.onchainAmount ?? "0"), 6)} NEAR delivered (sent ${o.amount})`);
    const fee = BigInt(done.feeActual ?? "0");
    say("info", `network fee: estimated ${formatFee(est.fee)} NEAR, actual ${formatFee(fee)} NEAR`);
    say(fee > 0n && fee <= est.reserve ? "pass" : "warn", "the actual fee is within the amount the network holds up front");
    const [a1, b1] = [await bal(a.id), await bal(b.id)];
    say(b1 === b0 + amount ? "pass" : "fail", `the recipient's balance rose by exactly ${o.amount} NEAR`);
    say(a1 === a0 - amount - fee ? "pass" : "warn", "the sender's balance fell by the amount plus the actual fee");
  }

  // discover it the way the recipient's device would: through the index, then verified over RPC
  store.useStorage(memStorage());
  resetIndexState();
  setIndexBase(o.indexBase);
  const t0 = Date.now();
  let found = false;
  let blocked = false;
  while (Date.now() - t0 < 180_000) {
    const r = await syncIncoming(rpc, b.id, f, { force: true });
    if (store.getTx(sent.id)) {
      found = true;
      break;
    }
    if (!r.indexOk) {
      blocked = true;
      break;
    }
    await sleep(15_000);
  }
  if (found) say("pass", `the recipient's device discovered the payment through the index and verified it over RPC in ${Math.round((Date.now() - t0) / 1000)} s`);
  else say("warn", blocked ? "the index was unavailable or rate limited, so incoming discovery could not be checked" : "the index did not list the payment within 3 minutes (it can lag; the balance still updates immediately)");

  // hand the tokens back
  for (const p of [a, b]) {
    try {
      store.useStorage(memStorage());
      const back = await estimateTransferFee(rpc, p.id, fid);
      const amt = maxSendable(back);
      if (amt <= 0n) continue;
      const s = await signerFromSeed(p.seed, p.publicKey);
      const r = await authorizeAndSend({ rpc, signer: s, fromId: p.id, toId: fid, amount: amt, estimate: back });
      const fin = await settle(r.id);
      say(fin.status === "completed" ? "info" : "warn", fin.status === "completed" ? `returned ${formatNear(amt, 4)} NEAR from ${p.id} to the funder` : `returning funds from ${p.id} ended as ${fin.status}`);
    } catch (e: any) {
      say("warn", `could not return funds from ${p.id}: ${e?.message ?? e}`);
    }
  }
  return tally;
}

if (typeof process !== "undefined" && process.argv[1]?.endsWith("live-check.ts")) {
  const env = process.env;
  const urls = (env.NEAT_RPC ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  runLiveCheck({
    rpcUrls: urls.length ? urls : DEFAULT_ENDPOINTS,
    rpcKey: env.NEAT_RPC_KEY,
    indexBase: env.NEAT_INDEX || "https://api-testnet.nearblocks.io",
    origin: env.NEAT_ORIGIN || "https://neat.example",
    checkAccount: env.NEAT_CHECK_ACCOUNT || "testnet",
    env,
    spend: process.argv.includes("--spend"),
    amount: env.NEAT_LIVE_AMOUNT || "0.1",
  }).then(
    (tally) => {
      console.log(`\n${tally.pass} passed, ${tally.warn} warnings, ${tally.fail} failed`);
      process.exit(tally.fail ? 1 : 0);
    },
    (e) => {
      console.error("live-check crashed:", e);
      process.exit(2);
    }
  );
}
