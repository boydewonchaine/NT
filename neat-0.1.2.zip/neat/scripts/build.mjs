// Builds the static PWA into dist/. Zero runtime dependencies; esbuild is the only build tool.
//   NEAT_RPC       comma-separated JSON-RPC endpoints baked into the client (default: FastNEAR, then near.org)
//   NEAT_REGISTER  registration endpoint (default /api/register)
//   NEAT_INDEX     NearBlocks-compatible index base URL (default https://api-testnet.nearblocks.io)
//   ESBUILD_PATH   optional path to esbuild if it isn't installed normally
import { createHash } from "node:crypto";
import { cpSync, existsSync, mkdirSync, readFileSync, readdirSync, rmSync, writeFileSync } from "node:fs";
import { createRequire } from "node:module";
import { join } from "node:path";

const require = createRequire(import.meta.url);
let esbuild;
try { esbuild = require("esbuild"); } catch { esbuild = require(process.env.ESBUILD_PATH ?? "esbuild"); }

const root = new URL("..", import.meta.url).pathname;
const dist = join(root, process.env.NEAT_OUT || "dist");
const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const list = (v) => (v ?? "").split(",").map((s) => s.trim()).filter(Boolean);

const rpc = list(process.env.NEAT_RPC);
const register = process.env.NEAT_REGISTER || "";
const index = process.env.NEAT_INDEX || "";
const swEnabled = process.env.NEAT_SW !== "0";

rmSync(dist, { recursive: true, force: true });
mkdirSync(join(dist, "assets"), { recursive: true });

const result = await esbuild.build({
  entryPoints: { app: join(root, "src/ui/main.ts") },
  bundle: true,
  format: "esm",
  target: ["es2022", "safari16", "chrome110", "firefox115"],
  minify: true,
  sourcemap: false,
  outdir: join(dist, "assets"),
  entryNames: "[name]-[hash]",
  loader: { ".css": "css" },
  metafile: true,
  legalComments: "none",
  define: {
    __NEAT_RPC__: rpc.length ? JSON.stringify(rpc) : "undefined",
    __NEAT_REGISTER__: register ? JSON.stringify(register) : "undefined",
    __NEAT_INDEX__: index ? JSON.stringify(index) : "undefined",
    __NEAT_VERSION__: JSON.stringify(pkg.version),
    __NEAT_SW__: String(swEnabled),
  },
});

const outs = Object.keys(result.metafile.outputs).map((p) => p.split("/").pop());
const js = outs.find((f) => f.endsWith(".js"));
const css = outs.find((f) => f.endsWith(".css"));
if (!js || !css) throw new Error("bundle outputs missing");

// copy static files
cpSync(join(root, "public"), dist, { recursive: true, filter: (src) => !src.endsWith("sw.template.js") && !src.endsWith("index.html") });

// CSP: only what the app needs. connect-src lists exactly the RPC / index / registration origins.
const origin = (u) => { try { return new URL(u, "http://self").origin; } catch { return null; } };
const connect = new Set(["'self'"]);
for (const u of rpc.length ? rpc : ["https://rpc.testnet.fastnear.com", "https://rpc.testnet.near.org"]) connect.add(origin(u));
connect.add(origin(index || "https://api-testnet.nearblocks.io"));
if (register && !register.startsWith("/")) connect.add(origin(register));
const csp = [
  "default-src 'none'", "script-src 'self'", "style-src 'self'", "img-src 'self' data: blob:", "media-src 'self' blob:",
  `connect-src ${[...connect].filter(Boolean).join(" ")}`, "manifest-src 'self'", "worker-src 'self'",
  "base-uri 'none'", "form-action 'none'", "object-src 'none'",
].join("; ");

const html = readFileSync(join(root, "public/index.html"), "utf8").replace("%CSP%", csp).replace("%JS%", js).replace("%CSS%", css);
writeFileSync(join(dist, "index.html"), html);

// service worker: precache the shell (content-hashed assets make cache-first safe)
const shell = ["/", "/index.html", `/assets/${js}`, `/assets/${css}`, "/manifest.webmanifest", "/icons/icon.svg", "/icons/icon-192.png", "/icons/icon-512.png", "/icons/maskable-512.png", "/icons/apple-touch-icon.png", "/logo.svg"];
for (const f of shell) if (f !== "/" && !existsSync(join(dist, f))) throw new Error("missing shell file " + f);
const version = createHash("sha256").update(js + css + pkg.version).digest("hex").slice(0, 12);
writeFileSync(join(dist, "sw.js"), readFileSync(join(root, "public/sw.template.js"), "utf8").replace("%VERSION%", `neat-${version}`).replace("%SHELL%", JSON.stringify(shell)));

console.log(`built NEAT ${pkg.version} (${version})  js=${js}  css=${css}`);
console.log("connect-src:", [...connect].join(" "));
